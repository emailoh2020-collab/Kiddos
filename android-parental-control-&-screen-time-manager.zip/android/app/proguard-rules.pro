# SafeShield ProGuard / R8 Rules
-keepattributes JavascriptInterface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

-keep class com.safeshield.parentalcontrol.NativeBridge { *; }
-keep class com.safeshield.parentalcontrol.models.** { *; }
-keepclassmembers class com.safeshield.parentalcontrol.models.** { *; }

-dontwarn androidx.security.crypto.**
-keep class androidx.biometric.** { *; }
