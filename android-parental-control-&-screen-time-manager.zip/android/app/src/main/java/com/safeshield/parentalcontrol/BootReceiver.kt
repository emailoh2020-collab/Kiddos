package com.safeshield.parentalcontrol

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == "android.intent.action.QUICKBOOT_POWERON" ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            action == Intent.ACTION_LOCKED_BOOT_COMPLETED) {

            // 1. Enforce background WorkManager
            ScheduleWorker.enqueuePeriodicCheck(context)

            // 2. Start Foreground Monitoring Service immediately
            val serviceIntent = Intent(context, UsageMonitorService::class.java).apply {
                this.action = UsageMonitorService.ACTION_START_MONITORING
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }

            // 3. Check Lock and Kiosk State and reapply if required
            val lockManager = LockManager(context)
            if (lockManager.isKioskEnabled() || lockManager.isLocked()) {
                val launchIntent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP
                    putExtra("EXTRA_BOOT_KIOSK", true)
                }
                context.startActivity(launchIntent)
            }

            // 4. Notify Parent of Boot Protection
            val notificationHelper = NotificationHelper(context)
            notificationHelper.showNotification(
                "SafeShield Active",
                "Screen time and Smart Block protection restored after device startup.",
                "info"
            )
        }
    }
}
