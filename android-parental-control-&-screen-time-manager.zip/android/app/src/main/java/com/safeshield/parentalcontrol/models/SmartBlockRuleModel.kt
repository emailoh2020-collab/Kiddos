package com.safeshield.parentalcontrol.models

import kotlinx.serialization.Serializable

@Serializable
data class SmartBlockRuleModel(
    val id: String = "",
    val name: String = "",
    val icon: String = "🏫",
    val enabled: Boolean = true,
    val startTime: String = "08:00",
    val endTime: String = "14:00",
    val activeDays: List<String> = listOf("monday", "tuesday", "wednesday", "thursday", "friday"),
    val allowedApps: List<String> = emptyList(),
    val blockedApps: List<String> = emptyList(),
    val blockedCategories: List<String> = listOf("games", "social", "entertainment"),
    val allowedCategories: List<String> = listOf("educational", "utilities"),
    val exceptions: List<String> = emptyList(),
    val priority: Int = 5
)
