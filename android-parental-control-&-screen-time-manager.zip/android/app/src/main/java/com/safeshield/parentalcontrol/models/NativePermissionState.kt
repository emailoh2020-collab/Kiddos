package com.safeshield.parentalcontrol.models

import kotlinx.serialization.Serializable

@Serializable
data class NativePermissionState(
    val usageAccessGranted: Boolean = false,
    val overlayGranted: Boolean = false,
    val accessibilityEnabled: Boolean = false,
    val deviceAdminActive: Boolean = false,
    val deviceOwnerActive: Boolean = false,
    val monitoringServiceRunning: Boolean = false,
    val bootProtectionActive: Boolean = true,
    val smartBlockEngineRunning: Boolean = true
)
