package com.safeshield.parentalcontrol

import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import com.safeshield.parentalcontrol.models.AppUsageInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Calendar

class UsageMonitorService : Service() {

    companion object {
        const val ACTION_START_MONITORING = "com.safeshield.action.START_MONITORING"
        const val ACTION_STOP_MONITORING = "com.safeshield.action.STOP_MONITORING"
        const val ACTION_RESTART_MONITORING = "com.safeshield.action.RESTART_MONITORING"
        var isRunning = false
            private set
    }

    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.Default + serviceJob)
    private lateinit var notificationHelper: NotificationHelper
    private lateinit var lockManager: LockManager
    private lateinit var smartBlockEngine: SmartBlockEngine
    private lateinit var permissionManager: PermissionManager

    override fun onCreate() {
        super.onCreate()
        notificationHelper = NotificationHelper(this)
        lockManager = LockManager(this)
        smartBlockEngine = SmartBlockEngine()
        permissionManager = PermissionManager(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_MONITORING -> {
                stopMonitoring()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_RESTART_MONITORING -> {
                stopMonitoring()
                startMonitoring()
            }
            else -> {
                startMonitoring()
            }
        }
        return START_STICKY
    }

    private fun startMonitoring() {
        if (isRunning) return
        isRunning = true

        startForeground(
            NotificationHelper.NOTIFICATION_ID_STATUS,
            notificationHelper.buildForegroundNotification("Monitoring screen time and Smart Block schedules")
        )

        serviceScope.launch {
            while (isActive && isRunning) {
                try {
                    monitorActiveForegroundApp()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                delay(2000L) // 2-second check loop
            }
        }
    }

    private fun stopMonitoring() {
        isRunning = false
        stopForeground(true)
    }

    private fun monitorActiveForegroundApp() {
        if (!permissionManager.isUsageAccessGranted()) return

        val foregroundPackage = getForegroundPackageName() ?: return
        if (SmartBlockEngine.SYSTEM_EXEMPT_PACKAGES.contains(foregroundPackage)) return

        // Evaluate lock state
        if (lockManager.isLocked() && foregroundPackage != packageName) {
            lockManager.lockDevice("device_locked")
        }
    }

    private fun getForegroundPackageName(): String? {
        val usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val endTime = System.currentTimeMillis()
        val startTime = endTime - 10000

        val usageEvents = usageStatsManager.queryEvents(startTime, endTime)
        var lastEvent: UsageEvents.Event? = null
        val event = UsageEvents.Event()

        while (usageEvents.hasNextEvent()) {
            usageEvents.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED ||
                event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                lastEvent = UsageEvents.Event().apply {
                    // Copy event data
                }
            }
        }

        return lastEvent?.packageName
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        isRunning = false
        serviceJob.cancel()
        super.onDestroy()
    }
}
