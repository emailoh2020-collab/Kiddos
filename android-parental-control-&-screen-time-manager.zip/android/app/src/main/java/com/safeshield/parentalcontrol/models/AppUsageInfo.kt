package com.safeshield.parentalcontrol.models

import kotlinx.serialization.Serializable

@Serializable
data class AppUsageInfo(
    val packageName: String = "",
    val appName: String = "",
    val icon: String = "",
    val category: String = "utilities",
    val foregroundTimeMinutes: Long = 0,
    val dailyUsageMinutes: Long = 0,
    val weeklyUsageMinutes: Long = 0,
    val launchCount: Int = 0,
    val firstUsageTimestamp: Long = 0,
    val lastUsageTimestamp: Long = 0,
    val isAllowed: Boolean = true,
    val allowDuringLock: Boolean = false
)
