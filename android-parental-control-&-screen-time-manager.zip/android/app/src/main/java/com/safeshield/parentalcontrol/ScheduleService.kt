package com.safeshield.parentalcontrol

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

class ScheduleWorker(
    private val context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result {
        val lockManager = LockManager(context)
        val notificationHelper = NotificationHelper(context)

        // Ensure UsageMonitorService is running
        if (!UsageMonitorService.isRunning) {
            val intent = android.content.Intent(context, UsageMonitorService::class.java)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        return Result.success()
    }

    companion object {
        fun enqueuePeriodicCheck(context: Context) {
            val periodicWork = PeriodicWorkRequestBuilder<ScheduleWorker>(15, TimeUnit.MINUTES)
                .build()
            WorkManager.getInstance(context).enqueue(periodicWork)
        }
    }
}
