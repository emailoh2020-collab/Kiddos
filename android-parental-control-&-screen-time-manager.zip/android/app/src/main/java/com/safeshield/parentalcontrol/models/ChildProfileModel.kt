package com.safeshield.parentalcontrol.models

import kotlinx.serialization.Serializable

@Serializable
data class ChildProfileModel(
    val id: String = "",
    val name: String = "",
    val avatar: String = "👦",
    val age: Int = 10,
    val dailyLimitMinutes: Int = 120,
    val dailyFreeTimeAllowanceSeconds: Int = 10800,
    val sessionLimitMinutes: Int = 45
)
