package com.safeshield.parentalcontrol

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.safeshield.parentalcontrol.databinding.OverlayLockScreenBinding

class LockScreenActivity : AppCompatActivity() {

    private lateinit var binding: OverlayLockScreenBinding
    private lateinit var lockManager: LockManager
    private lateinit var biometricAuthHelper: BiometricAuthHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = OverlayLockScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        lockManager = LockManager(this)
        biometricAuthHelper = BiometricAuthHelper(this)

        configureWindowFlags()
        setupListeners()
        setupBackInterception()
    }

    private fun configureWindowFlags() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                        WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }
    }

    private fun setupListeners() {
        val reason = intent.getStringExtra("EXTRA_REASON") ?: "daily_limit_reached"
        binding.tvLockDescription.text = "This device is currently restricted ($reason). Enter Parent PIN to unlock."

        binding.btnUnlock.setOnClickListener {
            val pin = binding.etParentPin.text.toString().trim()
            if (pin.isEmpty()) {
                Toast.makeText(this, "Please enter your 4-digit PIN", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (lockManager.unlockDevice(pin)) {
                Toast.makeText(this, "Device Unlocked Successfully", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "Incorrect PIN. Try again.", Toast.LENGTH_SHORT).show()
                binding.etParentPin.setText("")
            }
        }

        if (biometricAuthHelper.isBiometricAvailable()) {
            binding.btnBiometricUnlock.visibility = View.VISIBLE
            binding.btnBiometricUnlock.setOnClickListener {
                biometricAuthHelper.promptBiometricAuthentication(
                    title = "Parent Unlock",
                    subtitle = "Verify biometric fingerprint or face ID to unlock",
                    onSuccess = {
                        lockManager.unlockDevice("1234") // Bypass lock
                        finish()
                    },
                    onError = { err ->
                        Toast.makeText(this, err, Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }

        binding.btnEmergency.setOnClickListener {
            val emergencyIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:911")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(emergencyIntent)
        }
    }

    private fun setupBackInterception() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Prevent exiting the lock screen via back button
                Toast.makeText(this@LockScreenActivity, "Device is locked by parental controls", Toast.LENGTH_SHORT).show()
            }
        })
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_HOME || keyCode == KeyEvent.KEYCODE_APP_SWITCH) {
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
