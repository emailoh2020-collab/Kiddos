package com.safeshield.parentalcontrol

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class DeviceAdminReceiver : DeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        Toast.makeText(context, "SafeShield Device Protection Activated", Toast.LENGTH_SHORT).show()
        val notificationHelper = NotificationHelper(context)
        notificationHelper.showNotification(
            "Device Protection Active",
            "SafeShield has been granted Device Administration privileges.",
            "success"
        )
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        Toast.makeText(context, "SafeShield Protection Disabled", Toast.LENGTH_LONG).show()
        val notificationHelper = NotificationHelper(context)
        notificationHelper.showNotification(
            "Protection Disabled",
            "Warning: Device Administrator permission was deactivated.",
            "warning"
        )
    }

    override fun onProfileProvisioningComplete(context: Context, intent: Intent) {
        super.onProfileProvisioningComplete(context, intent)
        Toast.makeText(context, "SafeShield Device Owner Provisioning Complete", Toast.LENGTH_LONG).show()
    }
}
