package com.safeshield.parentalcontrol

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
enum class NativeEventType {
    SMART_BLOCK_STARTED,
    SMART_BLOCK_ENDED,
    APPLICATION_BLOCKED,
    APPLICATION_ALLOWED,
    TIME_EXPIRED,
    EXTRA_TIME_GRANTED,
    LOCK_STARTED,
    LOCK_RELEASED,
    PARENT_AUTH_SUCCESS,
    PARENT_AUTH_FAILED,
    PERMISSION_DISABLED,
    SERVICE_STARTED,
    DEVICE_REBOOTED
}

@Serializable
data class NativeLogEntry(
    val id: String,
    val type: NativeEventType,
    val title: String,
    val details: String,
    val timestamp: Long,
    val packageName: String? = null
)

class NativeEventLogger(private val context: Context) {

    companion object {
        private const val PREFS_LOGS = "safeshield_event_logs"
        private const val KEY_LOG_ENTRIES = "log_entries_json"
        private const val MAX_LOG_ENTRIES = 200
    }

    private val json = Json { ignoreUnknownKeys = true }

    private val securePrefs by lazy {
        try {
            val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
            EncryptedSharedPreferences.create(
                PREFS_LOGS,
                masterKeyAlias,
                context,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            context.getSharedPreferences(PREFS_LOGS, Context.MODE_PRIVATE)
        }
    }

    fun log(type: NativeEventType, title: String, details: String, packageName: String? = null) {
        val entry = NativeLogEntry(
            id = "log_${System.currentTimeMillis()}_${(1000..9999).random()}",
            type = type,
            title = title,
            details = details,
            timestamp = System.currentTimeMillis(),
            packageName = packageName
        )

        val currentList = getLogs().toMutableList()
        currentList.add(0, entry) // Newest first

        val trimmedList = if (currentList.size > MAX_LOG_ENTRIES) {
            currentList.take(MAX_LOG_ENTRIES)
        } else {
            currentList
        }

        securePrefs.edit()
            .putString(KEY_LOG_ENTRIES, json.encodeToString(trimmedList))
            .apply()
    }

    fun getLogs(): List<NativeLogEntry> {
        val raw = securePrefs.getString(KEY_LOG_ENTRIES, null) ?: return emptyList()
        return try {
            json.decodeFromString(raw)
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun getLogsJson(): String {
        return securePrefs.getString(KEY_LOG_ENTRIES, "[]") ?: "[]"
    }

    fun clearLogs() {
        securePrefs.edit().remove(KEY_LOG_ENTRIES).apply()
    }
}
