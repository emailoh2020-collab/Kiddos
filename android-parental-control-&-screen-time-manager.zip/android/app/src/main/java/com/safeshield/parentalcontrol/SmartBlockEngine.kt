package com.safeshield.parentalcontrol

import com.safeshield.parentalcontrol.models.SmartBlockRuleModel
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.Calendar

@Serializable
enum class AccessDecision {
    ALLOW,
    BLOCK,
    LOCK_DEVICE,
    PARENT_AUTH_REQUIRED
}

@Serializable
data class AppCheckResult(
    val decision: AccessDecision,
    val reason: String,
    val ruleId: String? = null,
    val packageName: String,
    val mode: String? = null,
    val expiresAt: String? = null,
    val details: String
)

class SmartBlockEngine {

    companion object {
        val SYSTEM_EXEMPT_PACKAGES = setOf(
            "com.safeshield.parentalcontrol",
            "com.safeshield.parentalcontrol.debug",
            "com.android.phone",
            "com.android.server.telecom",
            "com.google.android.dialer",
            "com.android.dialer",
            "com.android.emergency",
            "com.android.settings",
            "com.android.systemui"
        )
    }

    private val json = Json { ignoreUnknownKeys = true }

    /**
     * Checks whether an application is permitted based on deterministic hierarchy:
     * 1. Emergency / System Restrictions
     * 2. Active Smart Block (Independent enforcement layer - never bypassed by Free Mode, Play Mode, or Extra Time)
     * 3. Active Usage Mode (Study Mode, School Mode, etc.)
     * 4. Daily time allowance & overall device lock
     * 5. Application-specific rules
     * 6. Extra Time evaluation
     */
    fun evaluateAppAccess(
        packageName: String,
        category: String,
        isDeviceLocked: Boolean,
        activeUsageModeAllowedApps: Set<String>?,
        smartBlockRules: List<SmartBlockRuleModel>,
        hasExtraTime: Boolean,
        isParentSessionActive: Boolean = false
    ): AppCheckResult {
        // 0. Parent Session Active
        if (isParentSessionActive && packageName == "com.safeshield.parentalcontrol") {
            return AppCheckResult(
                decision = AccessDecision.ALLOW,
                reason = "NORMAL_ALLOWED",
                packageName = packageName,
                details = "Parent administrative session is active"
            )
        }

        // 1. System & Emergency Whitelist
        if (SYSTEM_EXEMPT_PACKAGES.contains(packageName)) {
            return AppCheckResult(
                decision = AccessDecision.ALLOW,
                reason = "EMERGENCY_EXEMPT",
                packageName = packageName,
                details = "System critical package is always permitted"
            )
        }

        // 2. Smart Block Independent Schedules (Smart Block overrides Free Mode, Play Mode, and Extra Time)
        val activeSmartBlock = getActiveSmartBlockRule(smartBlockRules)
        if (activeSmartBlock != null) {
            // Check exceptions first
            if (activeSmartBlock.exceptions.contains(packageName)) {
                return AppCheckResult(
                    decision = AccessDecision.ALLOW,
                    reason = "NORMAL_ALLOWED",
                    ruleId = activeSmartBlock.id,
                    packageName = packageName,
                    mode = activeSmartBlock.name,
                    details = "Exempted by rule exception in ${activeSmartBlock.name}"
                )
            }

            // Explicitly allowed in this Smart Block mode
            if (activeSmartBlock.allowedApps.contains(packageName)) {
                return AppCheckResult(
                    decision = AccessDecision.ALLOW,
                    reason = "NORMAL_ALLOWED",
                    ruleId = activeSmartBlock.id,
                    packageName = packageName,
                    mode = activeSmartBlock.name,
                    details = "Explicitly allowed in ${activeSmartBlock.name}"
                )
            }

            // Explicitly blocked in this Smart Block mode
            if (activeSmartBlock.blockedApps.contains(packageName)) {
                return AppCheckResult(
                    decision = AccessDecision.BLOCK,
                    reason = "SMART_BLOCK",
                    ruleId = activeSmartBlock.id,
                    packageName = packageName,
                    mode = activeSmartBlock.name,
                    expiresAt = activeSmartBlock.endTime,
                    details = "Application explicitly blocked by Smart Block (${activeSmartBlock.name})"
                )
            }

            // Category blocked in this Smart Block mode
            if (activeSmartBlock.blockedCategories.contains(category)) {
                return AppCheckResult(
                    decision = AccessDecision.BLOCK,
                    reason = "SMART_BLOCK",
                    ruleId = activeSmartBlock.id,
                    packageName = packageName,
                    mode = activeSmartBlock.name,
                    expiresAt = activeSmartBlock.endTime,
                    details = "Category '$category' restricted during ${activeSmartBlock.name}"
                )
            }
        }

        // 3. Usage Mode Rule (e.g. Study Mode, School Mode)
        if (activeUsageModeAllowedApps != null && activeUsageModeAllowedApps.isNotEmpty()) {
            if (!activeUsageModeAllowedApps.contains(packageName)) {
                return AppCheckResult(
                    decision = AccessDecision.BLOCK,
                    reason = "USAGE_MODE_RESTRICTION",
                    packageName = packageName,
                    details = "Application is not in current mode allowlist"
                )
            }
        }

        // 4. Overall Device Lock State & Daily Allowance
        if (isDeviceLocked && !hasExtraTime) {
            return AppCheckResult(
                decision = AccessDecision.LOCK_DEVICE,
                reason = "DAILY_LIMIT_EXHAUSTED",
                packageName = packageName,
                details = "Daily screen time allowance exhausted or device locked"
            )
        }

        return AppCheckResult(
            decision = AccessDecision.ALLOW,
            reason = "NORMAL_ALLOWED",
            packageName = packageName,
            details = "Access permitted"
        )
    }

    fun evaluateAppAccessJson(
        packageName: String,
        category: String,
        isDeviceLocked: Boolean,
        activeUsageModeAllowedApps: Set<String>?,
        smartBlockRules: List<SmartBlockRuleModel>,
        hasExtraTime: Boolean,
        isParentSessionActive: Boolean = false
    ): String {
        val result = evaluateAppAccess(
            packageName,
            category,
            isDeviceLocked,
            activeUsageModeAllowedApps,
            smartBlockRules,
            hasExtraTime,
            isParentSessionActive
        )
        return json.encodeToString(result)
    }

    fun getActiveSmartBlockRule(rules: List<SmartBlockRuleModel>): SmartBlockRuleModel? {
        val now = Calendar.getInstance()
        val currentDay = getDayOfWeekString(now.get(Calendar.DAY_OF_WEEK))
        val currentMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)

        val activeRules = rules.filter { rule ->
            if (!rule.enabled) return@filter false
            if (!rule.activeDays.map { it.lowercase() }.contains(currentDay)) return@filter false

            val (startMin, endMin) = parseTimeRange(rule.startTime, rule.endTime)
            if (startMin <= endMin) {
                // Same day window (e.g. 08:00 to 14:00)
                currentMinutes in startMin until endMin
            } else {
                // Overnight window across midnight (e.g. 21:00 to 07:00)
                currentMinutes >= startMin || currentMinutes < endMin
            }
        }

        // Deterministic priority handling: Highest priority number wins
        return activeRules.maxByOrNull { it.priority }
    }

    private fun parseTimeRange(startStr: String, endStr: String): Pair<Int, Int> {
        val startParts = startStr.split(":").mapNotNull { it.toIntOrNull() }
        val endParts = endStr.split(":").mapNotNull { it.toIntOrNull() }

        val startMin = if (startParts.size >= 2) startParts[0] * 60 + startParts[1] else 0
        val endMin = if (endParts.size >= 2) endParts[0] * 60 + endParts[1] else 1440
        return Pair(startMin, endMin)
    }

    private fun getDayOfWeekString(dayInt: Int): String {
        return when (dayInt) {
            Calendar.MONDAY -> "monday"
            Calendar.TUESDAY -> "tuesday"
            Calendar.WEDNESDAY -> "wednesday"
            Calendar.THURSDAY -> "thursday"
            Calendar.FRIDAY -> "friday"
            Calendar.SATURDAY -> "saturday"
            Calendar.SUNDAY -> "sunday"
            else -> "monday"
        }
    }
}

