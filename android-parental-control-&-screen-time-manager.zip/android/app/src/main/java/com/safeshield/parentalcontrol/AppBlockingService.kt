package com.safeshield.parentalcontrol

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.view.accessibility.AccessibilityEvent
import com.safeshield.parentalcontrol.models.SmartBlockRuleModel
import kotlinx.serialization.json.Json

class AppBlockingService : AccessibilityService() {

    private lateinit var lockManager: LockManager
    private lateinit var smartBlockEngine: SmartBlockEngine
    private lateinit var eventLogger: NativeEventLogger
    private val json = Json { ignoreUnknownKeys = true }

    override fun onCreate() {
        super.onCreate()
        lockManager = LockManager(this)
        smartBlockEngine = SmartBlockEngine()
        eventLogger = NativeEventLogger(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val packageName = event.packageName?.toString() ?: return
            handlePackageTransition(packageName)
        }
    }

    private fun handlePackageTransition(targetPackage: String) {
        if (SmartBlockEngine.SYSTEM_EXEMPT_PACKAGES.contains(targetPackage)) return
        if (targetPackage == packageName || targetPackage == "$packageName.debug") return

        // 1. Check if device is locked
        if (lockManager.isLocked()) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            lockManager.lockDevice("daily_limit_reached")
            eventLogger.log(
                NativeEventType.APPLICATION_BLOCKED,
                "App Blocked during Lock",
                "Blocked $targetPackage because device is locked",
                targetPackage
            )
            return
        }

        // 2. Load synced rules from persistent secure storage
        val prefs = getSharedPreferences("safeshield_native_sync", Context.MODE_PRIVATE)
        val rulesJson = prefs.getString("smart_block_rules_json", "[]") ?: "[]"
        val smartBlockRules: List<SmartBlockRuleModel> = try {
            json.decodeFromString(rulesJson)
        } catch (e: Exception) {
            emptyList()
        }

        val hasExtraTime = prefs.getBoolean("has_extra_time", false)
        val currentModeAllowedApps = prefs.getStringSet("mode_allowed_apps", null)

        // 3. Centralized Rule Evaluator
        val decision = smartBlockEngine.evaluateAppAccess(
            packageName = targetPackage,
            category = "other",
            isDeviceLocked = lockManager.isLocked(),
            activeUsageModeAllowedApps = currentModeAllowedApps,
            smartBlockRules = smartBlockRules,
            hasExtraTime = hasExtraTime,
            isParentSessionActive = false
        )

        if (decision.decision == AccessDecision.BLOCK || decision.decision == AccessDecision.LOCK_DEVICE) {
            // Intercept immediately (<50ms) and bring SafeShield Lock Screen / Home
            performGlobalAction(GLOBAL_ACTION_HOME)
            lockManager.lockDevice(decision.details)
            eventLogger.log(
                NativeEventType.APPLICATION_BLOCKED,
                "Application Restricted",
                decision.details,
                targetPackage
            )
        } else {
            eventLogger.log(
                NativeEventType.APPLICATION_ALLOWED,
                "Application Allowed",
                "Access permitted for $targetPackage",
                targetPackage
            )
        }
    }

    override fun onInterrupt() {
        // Service interrupted
    }
}

