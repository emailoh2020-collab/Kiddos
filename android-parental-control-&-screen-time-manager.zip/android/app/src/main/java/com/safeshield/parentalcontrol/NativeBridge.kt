package com.safeshield.parentalcontrol

import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.webkit.JavascriptInterface
import androidx.fragment.app.FragmentActivity
import com.safeshield.parentalcontrol.models.AppUsageInfo
import com.safeshield.parentalcontrol.models.SmartBlockRuleModel
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.json.JSONObject
import java.util.Calendar

class NativeBridge(
    private val activity: FragmentActivity
) {

    private val context: Context = activity.applicationContext
    private val permissionManager = PermissionManager(context)
    private val lockManager = LockManager(context)
    private val notificationHelper = NotificationHelper(context)
    private val biometricAuthHelper = BiometricAuthHelper(activity)
    private val eventLogger = NativeEventLogger(context)
    private val smartBlockEngine = SmartBlockEngine()
    private val json = Json { ignoreUnknownKeys = true }

    // ==========================================
    // PERMISSIONS
    // ==========================================

    @JavascriptInterface
    fun isUsageAccessGranted(): Boolean {
        return try {
            permissionManager.isUsageAccessGranted()
        } catch (e: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun requestUsageAccess() {
        try {
            permissionManager.requestUsageAccess()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @JavascriptInterface
    fun isOverlayPermissionGranted(): Boolean {
        return try {
            permissionManager.isOverlayPermissionGranted()
        } catch (e: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun requestOverlayPermission() {
        try {
            permissionManager.requestOverlayPermission()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @JavascriptInterface
    fun isAccessibilityServiceEnabled(): Boolean {
        return try {
            permissionManager.isAccessibilityServiceEnabled()
        } catch (e: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun openAccessibilitySettings() {
        try {
            permissionManager.openAccessibilitySettings()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @JavascriptInterface
    fun isDeviceAdminEnabled(): Boolean {
        return try {
            permissionManager.isDeviceAdminEnabled()
        } catch (e: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun requestDeviceAdmin() {
        try {
            permissionManager.requestDeviceAdmin()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @JavascriptInterface
    fun isDeviceOwner(): Boolean {
        return try {
            permissionManager.isDeviceOwner()
        } catch (e: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun getDeviceOwnerStatus(): String {
        return try {
            permissionManager.getDeviceOwnerStatus()
        } catch (e: Exception) {
            "Error checking Device Owner: ${e.message}"
        }
    }

    @JavascriptInterface
    fun isIgnoringBatteryOptimizations(): Boolean {
        return true
    }

    @JavascriptInterface
    fun requestIgnoreBatteryOptimizations() {
        // Unnecessary special permission removed for policy compliance. SafeShield operates without exempting battery optimization.
    }

    @JavascriptInterface
    fun getNativePermissions(): String {
        return try {
            val state = permissionManager.getFullPermissionState(UsageMonitorService.isRunning)
            json.encodeToString(state)
        } catch (e: Exception) {
            """{"usageAccessGranted":false,"overlayGranted":false,"accessibilityEnabled":false,"deviceAdminActive":false,"deviceOwnerActive":false,"monitoringServiceRunning":false,"bootProtectionActive":false,"smartBlockEngineRunning":false}"""
        }
    }

    // ==========================================
    // APPLICATIONS & USAGE STATS (TARGETED VISIBILITY)
    // ==========================================

    @JavascriptInterface
    fun getInstalledApplications(): String {
        return try {
            val pm = context.packageManager
            val launcherIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolveInfos = pm.queryIntentActivities(launcherIntent, 0)
            val appList = mutableListOf<AppUsageInfo>()
            val seenPackages = mutableSetOf<String>()

            for (resolveInfo in resolveInfos) {
                val pkgName = resolveInfo.activityInfo.packageName
                if (pkgName == context.packageName) continue // Skip self
                if (seenPackages.contains(pkgName)) continue
                seenPackages.add(pkgName)

                val appInfo = resolveInfo.activityInfo.applicationInfo
                val name = resolveInfo.loadLabel(pm).toString()
                val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                val category = if (isSystem) "system" else "utilities"

                appList.add(
                    AppUsageInfo(
                        packageName = pkgName,
                        appName = name,
                        icon = "Smartphone",
                        category = category,
                        isAllowed = true,
                        allowDuringLock = false
                    )
                )
            }

            appList.sortBy { it.appName.lowercase() }
            json.encodeToString(appList)
        } catch (e: Exception) {
            "[]"
        }
    }

    @JavascriptInterface
    fun getForegroundApplication(): String {
        return context.packageName
    }

    @JavascriptInterface
    fun getTodayUsage(): String {
        return try {
            val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val startTime = cal.timeInMillis
            val endTime = System.currentTimeMillis()

            val stats = usageStatsManager.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY,
                startTime,
                endTime
            )

            val resultMap = mutableMapOf<String, Long>()
            for (stat in stats) {
                if (stat.totalTimeInForeground > 0) {
                    resultMap[stat.packageName] = stat.totalTimeInForeground / (1000 * 60) // minutes
                }
            }

            json.encodeToString(resultMap)
        } catch (e: Exception) {
            "{}"
        }
    }

    @JavascriptInterface
    fun getWeeklyUsage(): String {
        return try {
            val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val startTime = System.currentTimeMillis() - (7L * 24 * 60 * 60 * 1000)
            val endTime = System.currentTimeMillis()

            val stats = usageStatsManager.queryUsageStats(
                UsageStatsManager.INTERVAL_WEEKLY,
                startTime,
                endTime
            )

            val resultMap = mutableMapOf<String, Long>()
            for (stat in stats) {
                if (stat.totalTimeInForeground > 0) {
                    resultMap[stat.packageName] = stat.totalTimeInForeground / (1000 * 60)
                }
            }

            json.encodeToString(resultMap)
        } catch (e: Exception) {
            "{}"
        }
    }

    @JavascriptInterface
    fun getBatteryStatus(): String {
        return try {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            """{"batteryLevelPercent": $level, "isCharging": false, "powerSaveMode": false, "apps": []}"""
        } catch (e: Exception) {
            """{"batteryLevelPercent": 100, "isCharging": false, "powerSaveMode": false, "apps": []}"""
        }
    }

    // ==========================================
    // LOCK & RESTRICTIONS
    // ==========================================

    @JavascriptInterface
    fun lockDevice(reason: String): Boolean {
        val safeReason = if (reason.isNullOrBlank()) "daily_limit_reached" else reason
        activity.runOnUiThread {
            lockManager.lockDevice(safeReason)
            eventLogger.log(
                NativeEventType.LOCK_STARTED,
                "Device Locked",
                "Device locked: $safeReason"
            )
        }
        return true
    }

    @JavascriptInterface
    fun unlockDevice(pin: String): Boolean {
        val success = lockManager.unlockDevice(pin)
        if (success) {
            eventLogger.log(
                NativeEventType.LOCK_RELEASED,
                "Device Unlocked",
                "Lock released via PIN verification"
            )
        } else {
            eventLogger.log(
                NativeEventType.PARENT_AUTH_FAILED,
                "PIN Verification Failed",
                "Incorrect PIN entry attempt"
            )
        }
        return success
    }

    // ==========================================
    // KIOSK / LOCK TASK CONTROL & PIN
    // ==========================================

    @JavascriptInterface
    fun startLockTaskMode(): Boolean {
        activity.runOnUiThread {
            val started = lockManager.startLockTaskMode(activity)
            if (started) {
                eventLogger.log(
                    NativeEventType.LOCK_STARTED,
                    "Kiosk Activated",
                    "Device entered official Android Lock Task Mode"
                )
            }
        }
        return true
    }

    @JavascriptInterface
    fun stopLockTaskMode(pin: String): Boolean {
        val verified = lockManager.verifyPin(pin)
        if (verified) {
            activity.runOnUiThread {
                lockManager.stopLockTaskMode(activity, pin)
                eventLogger.log(
                    NativeEventType.LOCK_RELEASED,
                    "Kiosk Exited",
                    "Parent verified PIN and stopped Lock Task Mode"
                )
            }
        } else {
            eventLogger.log(
                NativeEventType.PARENT_AUTH_FAILED,
                "Kiosk Exit Failed",
                "Invalid parent PIN entered to exit kiosk mode"
            )
        }
        return verified
    }

    @JavascriptInterface
    fun isInLockTaskMode(): Boolean {
        return lockManager.isInLockTaskMode(activity)
    }

    @JavascriptInterface
    fun isKioskEnabled(): Boolean {
        return lockManager.isKioskEnabled()
    }

    @JavascriptInterface
    fun setParentPin(newPin: String): Boolean {
        val success = lockManager.setParentPin(newPin)
        if (success) {
            eventLogger.log(
                NativeEventType.PARENT_AUTH_SUCCESS,
                "PIN Created",
                "Parent PIN saved to encrypted hardware keystore"
            )
        }
        return success
    }

    @JavascriptInterface
    fun changeParentPin(oldPin: String, newPin: String): Boolean {
        val success = lockManager.changeParentPin(oldPin, newPin)
        if (success) {
            eventLogger.log(
                NativeEventType.PARENT_AUTH_SUCCESS,
                "PIN Changed",
                "Parent PIN updated with validation"
            )
        } else {
            eventLogger.log(
                NativeEventType.PARENT_AUTH_FAILED,
                "PIN Change Failed",
                "Invalid previous PIN"
            )
        }
        return success
    }

    @JavascriptInterface
    fun verifyParentPin(pin: String): Boolean {
        return lockManager.verifyPin(pin)
    }

    @JavascriptInterface
    fun getDeviceOwnerSetupInstructions(): String {
        return lockManager.getDeviceOwnerSetupInstructions()
    }

    @JavascriptInterface
    fun blockApplication(packageName: String) {
        notificationHelper.showNotification(
            "App Restricted",
            "$packageName has been blocked by parental controls.",
            "warning"
        )
        eventLogger.log(
            NativeEventType.APPLICATION_BLOCKED,
            "App Blocked",
            "Application $packageName restricted",
            packageName
        )
    }

    @JavascriptInterface
    fun allowApplication(packageName: String) {
        eventLogger.log(
            NativeEventType.APPLICATION_ALLOWED,
            "App Allowed",
            "Application $packageName allowed",
            packageName
        )
    }

    @JavascriptInterface
    fun startMonitoring() {
        val intent = Intent(context, UsageMonitorService::class.java).apply {
            action = UsageMonitorService.ACTION_START_MONITORING
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
        eventLogger.log(
            NativeEventType.SERVICE_STARTED,
            "Service Started",
            "UsageMonitorService foreground service started"
        )
    }

    @JavascriptInterface
    fun stopMonitoring() {
        val intent = Intent(context, UsageMonitorService::class.java).apply {
            action = UsageMonitorService.ACTION_STOP_MONITORING
        }
        context.startService(intent)
    }

    @JavascriptInterface
    fun restartMonitoringService() {
        val intent = Intent(context, UsageMonitorService::class.java).apply {
            action = UsageMonitorService.ACTION_RESTART_MONITORING
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    @JavascriptInterface
    fun setCurrentMode(mode: String) {
        val safeMode = if (mode.isNullOrBlank()) "normal" else mode
        notificationHelper.showNotification(
            "Mode Activated",
            "Switched to $safeMode mode.",
            "info"
        )
    }

    @JavascriptInterface
    fun showNativeNotification(title: String, message: String, type: String) {
        notificationHelper.showNotification(
            if (title.isNullOrBlank()) "SafeShield Alert" else title,
            if (message.isNullOrBlank()) "Screen time updated." else message,
            if (type.isNullOrBlank()) "info" else type
        )
    }

    @JavascriptInterface
    fun requestExtraTime(minutes: Int) {
        val safeMinutes = if (minutes <= 0) 15 else minutes
        notificationHelper.showNotification(
            "Extra Time Granted",
            "+$safeMinutes minutes added for today.",
            "success"
        )
        eventLogger.log(
            NativeEventType.EXTRA_TIME_GRANTED,
            "Extra Time Granted",
            "+$safeMinutes minutes allocated to child account"
        )
    }

    @JavascriptInterface
    fun authenticateBiometric(title: String, subtitle: String): Boolean {
        var isSuccess = false
        activity.runOnUiThread {
            biometricAuthHelper.promptBiometricAuthentication(
                title = if (title.isNullOrBlank()) "Parent Authentication" else title,
                subtitle = if (subtitle.isNullOrBlank()) "Verify biometric identity" else subtitle,
                onSuccess = {
                    isSuccess = true
                    eventLogger.log(
                        NativeEventType.PARENT_AUTH_SUCCESS,
                        "Biometric Success",
                        "Parent identity verified via biometric prompt"
                    )
                },
                onError = { err ->
                    isSuccess = false
                    eventLogger.log(
                        NativeEventType.PARENT_AUTH_FAILED,
                        "Biometric Failed",
                        err
                    )
                }
            )
        }
        return true
    }

    @JavascriptInterface
    fun syncStateToNative(stateJson: String) {
        try {
            if (stateJson.isNullOrBlank()) return
            val prefs = context.getSharedPreferences("safeshield_native_sync", Context.MODE_PRIVATE)
            val root = JSONObject(stateJson)

            val editor = prefs.edit()

            if (root.has("smartBlockModes")) {
                editor.putString("smart_block_rules_json", root.getJSONArray("smartBlockModes").toString())
            }
            if (root.has("hasExtraTime")) {
                editor.putBoolean("has_extra_time", root.getBoolean("hasExtraTime"))
            }
            if (root.has("remainingDailySeconds")) {
                editor.putLong("remaining_daily_seconds", root.getLong("remainingDailySeconds"))
            }
            if (root.has("currentMode")) {
                editor.putString("current_mode", root.getString("currentMode"))
            }

            editor.apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @JavascriptInterface
    fun getNativeEventLogs(): String {
        return eventLogger.getLogsJson()
    }

    @JavascriptInterface
    fun clearNativeEventLogs() {
        eventLogger.clearLogs()
    }

    @JavascriptInterface
    fun evaluateAppAccess(packageName: String, category: String): String {
        val prefs = context.getSharedPreferences("safeshield_native_sync", Context.MODE_PRIVATE)
        val rulesJson = prefs.getString("smart_block_rules_json", "[]") ?: "[]"
        val smartBlockRules: List<SmartBlockRuleModel> = try {
            json.decodeFromString(rulesJson)
        } catch (e: Exception) {
            emptyList()
        }

        val hasExtraTime = prefs.getBoolean("has_extra_time", false)
        val currentModeAllowedApps = prefs.getStringSet("mode_allowed_apps", null)

        return smartBlockEngine.evaluateAppAccessJson(
            packageName = packageName,
            category = if (category.isNullOrBlank()) "other" else category,
            isDeviceLocked = lockManager.isLocked(),
            activeUsageModeAllowedApps = currentModeAllowedApps,
            smartBlockRules = smartBlockRules,
            hasExtraTime = hasExtraTime,
            isParentSessionActive = false
        )
    }
}

