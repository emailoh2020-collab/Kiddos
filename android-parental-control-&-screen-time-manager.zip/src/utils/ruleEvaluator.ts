import { AppInfo, ChildProfile, ParentalControlMode, SmartBlockMode, UsageMode } from '../types';
import { getEffectiveActiveSmartBlock, isModeActiveAt } from './smartBlockEngine';

export type RuleDecision = 'ALLOW' | 'BLOCK' | 'LOCK_DEVICE' | 'PARENT_AUTH_REQUIRED';

export interface RuleEvaluationResult {
  decision: RuleDecision;
  reason: 'EMERGENCY_EXEMPT' | 'SMART_BLOCK' | 'USAGE_MODE_RESTRICTION' | 'DAILY_LIMIT_EXHAUSTED' | 'APP_BLOCKED' | 'NORMAL_ALLOWED';
  ruleId?: string;
  packageName: string;
  appName?: string;
  mode?: string;
  expiresAt?: string;
  details: string;
}

/**
 * System-critical packages that are NEVER blocked under any circumstance.
 */
export const SYSTEM_CRITICAL_PACKAGES = new Set([
  'com.safeshield.parentalcontrol',
  'com.safeshield.parentalcontrol.debug',
  'com.android.phone',
  'com.android.server.telecom',
  'com.google.android.dialer',
  'com.android.dialer',
  'com.android.emergency',
  'com.android.settings',
  'com.android.systemui'
]);

export interface RuleEvaluationContext {
  packageName: string;
  appName?: string;
  category?: string;
  isDeviceLocked: boolean;
  lockReason?: string | null;
  remainingDailySeconds: number;
  hasExtraTime: boolean;
  extraTimeExpiresAt?: number;
  activeSmartBlockModes: SmartBlockMode[];
  activeUsageMode?: UsageMode;
  parentSessionActive: boolean;
  allApps: AppInfo[];
  currentTime?: Date;
}

/**
 * Centralized deterministic rule evaluator for SafeShield.
 * Strictly adheres to rule priority:
 * 1. Emergency / system restrictions
 * 2. Active Smart Block (Independent enforcement layer - never overridden by Free/Play Mode or Extra Time)
 * 3. Active Usage Mode (Play, Study, School, Sleep, etc.)
 * 4. Daily time allowance & countdown
 * 5. Application-specific rules (Custom parent allow/block list)
 * 6. Extra Time evaluation
 */
export function evaluateApplicationAccess(ctx: RuleEvaluationContext): RuleEvaluationResult {
  const {
    packageName,
    appName = packageName,
    category = 'other',
    isDeviceLocked,
    remainingDailySeconds,
    hasExtraTime,
    extraTimeExpiresAt,
    activeSmartBlockModes,
    activeUsageMode,
    parentSessionActive,
    allApps,
    currentTime = new Date()
  } = ctx;

  // 0. If Parent Session is active (Parent is currently configuring settings), allow parent access
  if (parentSessionActive && packageName === 'com.safeshield.parentalcontrol') {
    return {
      decision: 'ALLOW',
      reason: 'NORMAL_ALLOWED',
      packageName,
      appName,
      details: 'Parent administrative session is active'
    };
  }

  // 1. Emergency & System Whitelist (Priority 1)
  if (SYSTEM_CRITICAL_PACKAGES.has(packageName)) {
    return {
      decision: 'ALLOW',
      reason: 'EMERGENCY_EXEMPT',
      packageName,
      appName,
      details: 'System-critical and emergency service packages are always permitted'
    };
  }

  // Find app record from catalog
  const appRecord = allApps.find((a) => a.packageName === packageName);
  const effectiveCategory = appRecord?.category || category;

  // 2. Active Smart Block (Priority 2 - Independent Enforcement Layer)
  // Smart Block schedules CANNOT be bypassed by Free Mode, Play Mode, or Extra Time.
  const activeSmartBlock = getEffectiveActiveSmartBlock(activeSmartBlockModes, currentTime);
  if (activeSmartBlock) {
    // Check specific exceptions first (e.g. Chess allowed during Study Time)
    if (activeSmartBlock.exceptions?.includes(packageName)) {
      return {
        decision: 'ALLOW',
        reason: 'NORMAL_ALLOWED',
        ruleId: activeSmartBlock.id,
        packageName,
        appName,
        mode: activeSmartBlock.name,
        details: `Exempted by rule exception in ${activeSmartBlock.name}`
      };
    }

    // Check if explicitly blocked in this Smart Block mode
    if (activeSmartBlock.blockedApps?.includes(packageName)) {
      return {
        decision: 'BLOCK',
        reason: 'SMART_BLOCK',
        ruleId: activeSmartBlock.id,
        packageName,
        appName,
        mode: activeSmartBlock.name,
        expiresAt: activeSmartBlock.endTime,
        details: `Explicitly restricted by ${activeSmartBlock.name} schedule (${activeSmartBlock.startTime} - ${activeSmartBlock.endTime})`
      };
    }

    // Check if category is blocked in this Smart Block mode
    if (activeSmartBlock.blockedCategories?.includes(effectiveCategory as any)) {
      // Check if it was explicitly added to allowedApps as an override
      const explicitlyAllowedInSmartBlock = activeSmartBlock.allowedApps?.includes(packageName);
      if (!explicitlyAllowedInSmartBlock) {
        return {
          decision: 'BLOCK',
          reason: 'SMART_BLOCK',
          ruleId: activeSmartBlock.id,
          packageName,
          appName,
          mode: activeSmartBlock.name,
          expiresAt: activeSmartBlock.endTime,
          details: `Category '${effectiveCategory}' restricted during ${activeSmartBlock.name} (${activeSmartBlock.startTime} - ${activeSmartBlock.endTime})`
        };
      }
    }
  }

  // 3. Active Usage Mode (Priority 3 - Study Mode, School Mode, etc.)
  if (activeUsageMode && activeUsageMode.id !== 'normal' && activeUsageMode.id !== 'free') {
    if (activeUsageMode.allowedApps && activeUsageMode.allowedApps.length > 0) {
      if (!activeUsageMode.allowedApps.includes(packageName)) {
        return {
          decision: 'BLOCK',
          reason: 'USAGE_MODE_RESTRICTION',
          packageName,
          appName,
          mode: activeUsageMode.name,
          details: `App is not included in ${activeUsageMode.name} allowlist`
        };
      }
    }
  }

  // 4. Daily Time Allowance & Lock Mode (Priority 4)
  if (isDeviceLocked || (remainingDailySeconds <= 0 && !hasExtraTime)) {
    // Check if the app is marked 'allowDuringLock' (e.g. Phone, Safe Clock)
    if (appRecord?.allowDuringLock) {
      return {
        decision: 'ALLOW',
        reason: 'NORMAL_ALLOWED',
        packageName,
        appName,
        details: 'Essential application permitted during Lock Mode'
      };
    }

    return {
      decision: 'LOCK_DEVICE',
      reason: 'DAILY_LIMIT_EXHAUSTED',
      packageName,
      appName,
      details: 'Daily screen time allowance has expired or device is locked'
    };
  }

  // 5. Application-Specific Custom Rules (Priority 5)
  if (appRecord && !appRecord.isAllowed) {
    return {
      decision: 'BLOCK',
      reason: 'APP_BLOCKED',
      packageName,
      appName,
      details: 'Permanently blocked by parent settings'
    };
  }

  // 6. Access Permitted
  return {
    decision: 'ALLOW',
    reason: 'NORMAL_ALLOWED',
    packageName,
    appName,
    details: 'Access permitted within daily limits'
  };
}
