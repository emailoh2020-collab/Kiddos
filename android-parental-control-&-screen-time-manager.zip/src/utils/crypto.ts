// Secure PIN hashing using Web Crypto API (SHA-256 with Salt)

export async function generateSalt(): Promise<string> {
  const array = new Uint8Array(16);
  crypto.getRandomValues(array);
  return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
}

export async function hashPin(pin: string, salt: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(pin + salt + 'ANDROID_PARENTAL_CONTROL_SECRET_V2');
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

export async function verifyPin(pin: string, storedHash: string, salt: string): Promise<boolean> {
  if (!storedHash || !salt) return false;
  const computedHash = await hashPin(pin, salt);
  return computedHash === storedHash;
}

// Calculate delay in seconds after repeated failed attempts
export function getFailedAttemptDelaySeconds(attempts: number): number {
  if (attempts < 3) return 0;
  if (attempts === 3) return 30; // 30 seconds
  if (attempts === 4) return 60; // 1 minute
  if (attempts === 5) return 120; // 2 minutes
  return 300; // 5 minutes for 6+ attempts
}
