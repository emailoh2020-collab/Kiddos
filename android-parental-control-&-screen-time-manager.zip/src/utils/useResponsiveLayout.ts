import { useState, useEffect } from 'react';

export type WindowSizeClass = 'compact' | 'medium' | 'expanded';
export type ScreenOrientation = 'portrait' | 'landscape';

export interface ResponsiveLayoutInfo {
  width: number;
  height: number;
  sizeClass: WindowSizeClass;
  isCompact: boolean;   // < 600px (Smartphones)
  isMedium: boolean;    // 600px - 840px (Foldables, Small Tablets, Landscape Phones)
  isExpanded: boolean;  // > 840px (Tablets, Large Screens)
  isTablet: boolean;    // >= 600px
  orientation: ScreenOrientation;
}

export function useResponsiveLayout(): ResponsiveLayoutInfo {
  const [layout, setLayout] = useState<ResponsiveLayoutInfo>(() => {
    if (typeof window === 'undefined') {
      return {
        width: 1024,
        height: 768,
        sizeClass: 'expanded',
        isCompact: false,
        isMedium: false,
        isExpanded: true,
        isTablet: true,
        orientation: 'landscape',
      };
    }

    const width = window.innerWidth;
    const height = window.innerHeight;
    const sizeClass: WindowSizeClass = width < 600 ? 'compact' : width <= 840 ? 'medium' : 'expanded';
    const orientation: ScreenOrientation = width >= height ? 'landscape' : 'portrait';

    return {
      width,
      height,
      sizeClass,
      isCompact: sizeClass === 'compact',
      isMedium: sizeClass === 'medium',
      isExpanded: sizeClass === 'expanded',
      isTablet: width >= 600,
      orientation,
    };
  });

  useEffect(() => {
    const handleResize = () => {
      const width = window.innerWidth;
      const height = window.innerHeight;
      const sizeClass: WindowSizeClass = width < 600 ? 'compact' : width <= 840 ? 'medium' : 'expanded';
      const orientation: ScreenOrientation = width >= height ? 'landscape' : 'portrait';

      setLayout({
        width,
        height,
        sizeClass,
        isCompact: sizeClass === 'compact',
        isMedium: sizeClass === 'medium',
        isExpanded: sizeClass === 'expanded',
        isTablet: width >= 600,
        orientation,
      });
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleResize);
    };
  }, []);

  return layout;
}
