import { DayOfWeek, UsagePeriod, WeeklySchedule } from '../types';

export function getCurrentDayOfWeek(): DayOfWeek {
  const days: DayOfWeek[] = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  const todayIndex = new Date().getDay();
  return days[todayIndex];
}

export function formatTimeHHMM(date: Date = new Date()): string {
  const hours = date.getHours().toString().padStart(2, '0');
  const minutes = date.getMinutes().toString().padStart(2, '0');
  return `${hours}:${minutes}`;
}

export function parseHHMMToMinutes(hhmm: string): number {
  const [h, m] = hhmm.split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

export function formatSecondsToDigital(seconds: number): string {
  if (seconds < 0) seconds = 0;
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
}

export function formatMinutesToReadable(minutes: number): string {
  if (minutes < 60) return `${minutes}m`;
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return m > 0 ? `${h}h ${m}m` : `${h}h`;
}

// Check if current time falls within any allowed period for today
export function isCurrentTimeScheduledAllowed(schedule: WeeklySchedule, now: Date = new Date()): boolean {
  const currentDay = getCurrentDayOfWeek();
  const periods = schedule[currentDay] || [];
  const currentMinutes = now.getHours() * 60 + now.getMinutes();

  const enabledPeriods = periods.filter(p => p.enabled);
  if (enabledPeriods.length === 0) return true; // Default to open if no period set, or controlled by limits

  return enabledPeriods.some(period => {
    const startM = parseHHMMToMinutes(period.startTime);
    const endM = parseHHMMToMinutes(period.endTime);
    if (startM <= endM) {
      return currentMinutes >= startM && currentMinutes <= endM;
    } else {
      // Overnight period e.g., 22:00 to 06:00
      return currentMinutes >= startM || currentMinutes <= endM;
    }
  });
}

// Find the next upcoming scheduled usage period
export function getNextAllowedPeriod(schedule: WeeklySchedule, now: Date = new Date()): { day: string; startTime: string; diffText: string } | null {
  const daysOrder: DayOfWeek[] = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
  const todayIndex = daysOrder.indexOf(getCurrentDayOfWeek());
  const currentMinutes = now.getHours() * 60 + now.getMinutes();

  for (let i = 0; i < 7; i++) {
    const dayIndex = (todayIndex + i) % 7;
    const dayName = daysOrder[dayIndex];
    const periods = (schedule[dayName] || []).filter(p => p.enabled).sort((a, b) => parseHHMMToMinutes(a.startTime) - parseHHMMToMinutes(b.startTime));

    for (const period of periods) {
      const startM = parseHHMMToMinutes(period.startTime);
      if (i === 0 && startM > currentMinutes) {
        const diffM = startM - currentMinutes;
        return {
          day: 'Today',
          startTime: period.startTime,
          diffText: formatMinutesToReadable(diffM),
        };
      } else if (i > 0) {
        const daysLabel = dayName.charAt(0).toUpperCase() + dayName.slice(1);
        const diffM = (i * 24 * 60) + startM - currentMinutes;
        return {
          day: daysLabel,
          startTime: period.startTime,
          diffText: formatMinutesToReadable(diffM),
        };
      }
    }
  }

  return { day: 'Tomorrow', startTime: '16:00', diffText: '4h 00m' };
}
