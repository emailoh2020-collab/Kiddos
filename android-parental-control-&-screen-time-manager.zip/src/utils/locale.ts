import { Language } from '../types';

/**
 * Format minutes into localized string with correct pluralization rules
 * English: 1 minute, 2 minutes, 5 minutes
 * Arabic: دقيقة واحدة, دقيقتان, 5 دقائق, 15 دقيقة
 */
export function formatMinutes(minutes: number, lang: Language): string {
  if (lang === 'ar') {
    if (minutes === 1) return 'دقيقة واحدة';
    if (minutes === 2) return 'دقيقتان';
    if (minutes >= 3 && minutes <= 10) return `${minutes} دقائق`;
    return `${minutes} دقيقة`;
  } else {
    return minutes === 1 ? '1 minute' : `${minutes} minutes`;
  }
}

/**
 * Format time using locale-aware formatting APIs
 */
export function formatTime(timeInput: Date | number | string, lang: Language): string {
  const date = timeInput instanceof Date ? timeInput : new Date(timeInput);
  if (isNaN(date.getTime())) return String(timeInput);

  const locale = lang === 'ar' ? 'ar-SA' : 'en-US';
  return date.toLocaleTimeString(locale, {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });
}

/**
 * Format date using locale-aware formatting APIs
 */
export function formatDate(dateInput: Date | number | string, lang: Language): string {
  const date = dateInput instanceof Date ? dateInput : new Date(dateInput);
  if (isNaN(date.getTime())) return String(dateInput);

  const locale = lang === 'ar' ? 'ar-SA' : 'en-US';
  return date.toLocaleDateString(locale, {
    weekday: 'short',
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

/**
 * Format numbers according to locale
 */
export function formatNumber(num: number, lang: Language): string {
  const locale = lang === 'ar' ? 'ar-EG' : 'en-US';
  return new Intl.NumberFormat(locale).format(num);
}

/**
 * Format child name to show only the first 5 letters
 */
export function formatChildName(name: string): string {
  if (!name) return '';
  return name.slice(0, 5);
}

