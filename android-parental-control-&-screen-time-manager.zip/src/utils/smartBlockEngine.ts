import { AppCategory, AppInfo, DayOfWeek, SmartBlockMode } from '../types';

export const DAYS_OF_WEEK: DayOfWeek[] = [
  'monday',
  'tuesday',
  'wednesday',
  'thursday',
  'friday',
  'saturday',
  'sunday',
];

export const WEEKDAYS: DayOfWeek[] = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'];
export const WEEKENDS: DayOfWeek[] = ['saturday', 'sunday'];
export const EVERY_DAY: DayOfWeek[] = [...DAYS_OF_WEEK];

export const DEFAULT_SMART_BLOCK_MODES: SmartBlockMode[] = [
  {
    id: 'smart-mode-school',
    name: 'School Time',
    description: 'Classroom focus hours. Games, social media, and entertainment apps are blocked.',
    icon: '🏫',
    enabled: true,
    startTime: '07:00',
    endTime: '14:00',
    activeDays: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'],
    blockedCategories: ['games', 'social', 'entertainment'],
    allowedCategories: ['educational', 'utilities'],
    allowedApps: ['com.example.calculator', 'com.example.dictionary', 'com.google.android.apps.classroom', 'com.google.android.apps.docs'],
    blockedApps: ['com.roblox.client', 'com.zhiliaoapp.musically', 'com.instagram.android'],
    exceptions: [],
    priority: 3,
    createdAt: Date.now() - 86400000 * 10,
    updatedAt: Date.now() - 86400000 * 10,
  },
  {
    id: 'smart-mode-study',
    name: 'Study Time',
    description: 'Homework and focus period. Educational reading, math, and reference apps permitted.',
    icon: '📚',
    enabled: true,
    startTime: '14:00',
    endTime: '16:00',
    activeDays: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'],
    blockedCategories: ['games', 'social', 'entertainment'],
    allowedCategories: ['educational', 'utilities'],
    allowedApps: ['com.example.calculator', 'com.example.dictionary', 'com.google.android.apps.docs', 'com.duolingo', 'com.khanacademy.android'],
    blockedApps: ['com.roblox.client', 'com.zhiliaoapp.musically', 'com.instagram.android', 'com.google.android.youtube'],
    exceptions: ['com.chess'], // Chess allowed as mind puzzle exception
    priority: 4,
    createdAt: Date.now() - 86400000 * 9,
    updatedAt: Date.now() - 86400000 * 9,
  },
  {
    id: 'smart-mode-play',
    name: 'Play Time',
    description: 'Afternoon leisure and recreation window. Games, educational, and creative apps active.',
    icon: '🎮',
    enabled: true,
    startTime: '16:00',
    endTime: '19:00',
    activeDays: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'],
    blockedCategories: ['social'],
    allowedCategories: ['games', 'educational', 'entertainment', 'utilities'],
    allowedApps: [],
    blockedApps: [],
    exceptions: [],
    priority: 2,
    createdAt: Date.now() - 86400000 * 8,
    updatedAt: Date.now() - 86400000 * 8,
  },
  {
    id: 'smart-mode-family',
    name: 'Family Time',
    description: 'Dinner and family evening connection. Device apps paused except essential dialer.',
    icon: '🍽',
    enabled: true,
    startTime: '19:00',
    endTime: '20:30',
    activeDays: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'],
    blockedCategories: ['games', 'social', 'entertainment', 'educational'],
    allowedCategories: ['utilities'],
    allowedApps: ['com.google.android.dialer'],
    blockedApps: [],
    exceptions: [],
    priority: 5,
    createdAt: Date.now() - 86400000 * 7,
    updatedAt: Date.now() - 86400000 * 7,
  },
  {
    id: 'smart-mode-bedtime',
    name: 'Bedtime',
    description: 'Wind-down and overnight sleep protection spanning midnight. All distractions locked.',
    icon: '🌙',
    enabled: true,
    startTime: '20:30',
    endTime: '07:00', // Overnight schedule!
    activeDays: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'],
    blockedCategories: ['games', 'social', 'entertainment', 'educational', 'utilities'],
    allowedCategories: [],
    allowedApps: ['com.example.clock', 'com.google.android.dialer'],
    blockedApps: [],
    exceptions: [],
    priority: 6,
    createdAt: Date.now() - 86400000 * 6,
    updatedAt: Date.now() - 86400000 * 6,
  },
];

/**
 * Converts "HH:MM" string to minutes from midnight (0..1439).
 */
export function timeStringToMinutes(timeStr: string): number {
  if (!timeStr || !timeStr.includes(':')) return 0;
  const [h, m] = timeStr.split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

/**
 * Converts minutes from midnight into 24-hour "HH:MM" string.
 */
export function minutesToTimeString(totalMinutes: number): string {
  const normalized = ((totalMinutes % 1440) + 1440) % 1440;
  const h = Math.floor(normalized / 60);
  const m = normalized % 60;
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
}

/**
 * Gets DayOfWeek from standard Date object using device local time.
 */
export function getLocalDayOfWeek(date: Date = new Date()): DayOfWeek {
  const dayIndex = date.getDay(); // 0 = Sunday, 1 = Monday ... 6 = Saturday
  const mapping: DayOfWeek[] = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  return mapping[dayIndex];
}

/**
 * Gets the previous day of week.
 */
export function getPreviousDay(day: DayOfWeek): DayOfWeek {
  const idx = DAYS_OF_WEEK.indexOf(day);
  if (idx === -1) return 'sunday';
  return DAYS_OF_WEEK[(idx - 1 + DAYS_OF_WEEK.length) % DAYS_OF_WEEK.length];
}

/**
 * Evaluates whether a SmartBlockMode is active at a given date/time (defaults to current device local time).
 * Fully supports overnight schedules that cross midnight (e.g. 20:30 -> 07:00).
 */
export function isModeActiveAt(mode: SmartBlockMode, date: Date = new Date()): boolean {
  if (!mode.enabled) return false;

  const currentDay = getLocalDayOfWeek(date);
  const currentMinutes = date.getHours() * 60 + date.getMinutes();
  const startMinutes = timeStringToMinutes(mode.startTime);
  const endMinutes = timeStringToMinutes(mode.endTime);

  // Same-day schedule (e.g., 08:00 to 14:00, 14:00 to 16:00)
  if (startMinutes <= endMinutes) {
    if (!mode.activeDays.includes(currentDay)) {
      return false;
    }
    return currentMinutes >= startMinutes && currentMinutes < endMinutes;
  }

  // Overnight schedule across midnight (e.g., 20:30 to 07:00)
  // Evening portion on day X (>= 20:30)
  if (currentMinutes >= startMinutes) {
    return mode.activeDays.includes(currentDay);
  }

  // Morning portion on day X+1 (< 07:00) -> started yesterday evening!
  if (currentMinutes < endMinutes) {
    const prevDay = getPreviousDay(currentDay);
    return mode.activeDays.includes(prevDay);
  }

  return false;
}

/**
 * Returns all active Smart Block modes sorted by priority descending (highest priority first).
 */
export function getActiveSmartBlockModes(modes: SmartBlockMode[], date: Date = new Date()): SmartBlockMode[] {
  return modes
    .filter((m) => isModeActiveAt(m, date))
    .sort((a, b) => (b.priority || 0) - (a.priority || 0));
}

/**
 * Returns the effective active Smart Block mode (highest priority), or null if none is active.
 */
export function getEffectiveActiveSmartBlock(modes: SmartBlockMode[], date: Date = new Date()): SmartBlockMode | null {
  const activeList = getActiveSmartBlockModes(modes, date);
  return activeList.length > 0 ? activeList[0] : null;
}

export interface SmartBlockTransitionInfo {
  nextMode: SmartBlockMode | null;
  transitionTime: string;
  transitionDay: DayOfWeek;
  minutesUntil: number;
  isEndingCurrent: boolean;
}

/**
 * Computes the next scheduled Smart Block transition (either ending the current rule or starting an upcoming rule).
 */
export function getNextSmartBlockTransition(
  modes: SmartBlockMode[],
  date: Date = new Date()
): SmartBlockTransitionInfo | null {
  const enabledModes = modes.filter((m) => m.enabled);
  if (enabledModes.length === 0) return null;

  const currentActive = getEffectiveActiveSmartBlock(modes, date);
  const currentMinutes = date.getHours() * 60 + date.getMinutes();
  const currentDay = getLocalDayOfWeek(date);

  // If currently in an active mode, look for its end time or a higher priority takeover
  if (currentActive) {
    const endMinutes = timeStringToMinutes(currentActive.endTime);
    let minutesUntilEnd = 0;
    if (endMinutes > currentMinutes) {
      minutesUntilEnd = endMinutes - currentMinutes;
    } else {
      // Overnight end time next morning
      minutesUntilEnd = 1440 - currentMinutes + endMinutes;
    }

    // Check if any other mode starts earlier than this end time
    let earliestOtherStart: { mode: SmartBlockMode; minsUntil: number } | null = null;

    // Scan the next 24 hours (step by 5 minutes for precise event capture)
    for (let offset = 5; offset <= Math.min(minutesUntilEnd, 1440); offset += 5) {
      const checkDate = new Date(date.getTime() + offset * 60000);
      const activeAtCheck = getEffectiveActiveSmartBlock(modes, checkDate);
      if (activeAtCheck && activeAtCheck.id !== currentActive.id) {
        earliestOtherStart = { mode: activeAtCheck, minsUntil: offset };
        break;
      }
    }

    if (earliestOtherStart) {
      const transitionDate = new Date(date.getTime() + earliestOtherStart.minsUntil * 60000);
      return {
        nextMode: earliestOtherStart.mode,
        transitionTime: minutesToTimeString(transitionDate.getHours() * 60 + transitionDate.getMinutes()),
        transitionDay: getLocalDayOfWeek(transitionDate),
        minutesUntil: earliestOtherStart.minsUntil,
        isEndingCurrent: false,
      };
    }

    const transitionDate = new Date(date.getTime() + minutesUntilEnd * 60000);
    return {
      nextMode: null,
      transitionTime: currentActive.endTime,
      transitionDay: getLocalDayOfWeek(transitionDate),
      minutesUntil: minutesUntilEnd,
      isEndingCurrent: true,
    };
  }

  // If no rule is currently active, find the earliest upcoming rule start over next 7 days
  let earliestStart: { mode: SmartBlockMode; minsUntil: number } | null = null;

  for (let offset = 1; offset <= 7 * 1440; offset += 5) {
    const checkDate = new Date(date.getTime() + offset * 60000);
    const activeAtCheck = getEffectiveActiveSmartBlock(modes, checkDate);
    if (activeAtCheck) {
      earliestStart = { mode: activeAtCheck, minsUntil: offset };
      break;
    }
  }

  if (earliestStart) {
    const transitionDate = new Date(date.getTime() + earliestStart.minsUntil * 60000);
    return {
      nextMode: earliestStart.mode,
      transitionTime: earliestStart.mode.startTime,
      transitionDay: getLocalDayOfWeek(transitionDate),
      minutesUntil: earliestStart.minsUntil,
      isEndingCurrent: false,
    };
  }

  return null;
}

export interface ScheduleOverlap {
  modeA: SmartBlockMode;
  modeB: SmartBlockMode;
  overlappingDays: DayOfWeek[];
  overlapTimeRange: string;
}

/**
 * Detects overlapping time windows among enabled Smart Block modes on any day of the week.
 */
export function detectScheduleOverlaps(modes: SmartBlockMode[]): ScheduleOverlap[] {
  const enabledModes = modes.filter((m) => m.enabled);
  const overlaps: ScheduleOverlap[] = [];

  for (let i = 0; i < enabledModes.length; i++) {
    for (let j = i + 1; j < enabledModes.length; j++) {
      const modeA = enabledModes[i];
      const modeB = enabledModes[j];

      // Find shared active days (including overnight rollover)
      const sharedDays = modeA.activeDays.filter((d) => modeB.activeDays.includes(d));
      if (sharedDays.length === 0) continue;

      // Check for minute overlap across standard 24-hour simulation on a shared day
      let hasOverlap = false;
      let overlapStartMin = -1;
      let overlapEndMin = -1;

      for (let min = 0; min < 1440; min += 15) {
        // Construct a mock date for this minute on a reference day
        const mockDate = new Date(2026, 0, 5, Math.floor(min / 60), min % 60, 0); // Jan 5 2026 is Monday
        // Check if both modes activate
        const aActive = isModeActiveOnDay(modeA, 'monday', min);
        const bActive = isModeActiveOnDay(modeB, 'monday', min);

        if (aActive && bActive) {
          hasOverlap = true;
          if (overlapStartMin === -1) overlapStartMin = min;
          overlapEndMin = min + 15;
        }
      }

      if (hasOverlap) {
        overlaps.push({
          modeA,
          modeB,
          overlappingDays: sharedDays,
          overlapTimeRange: `${minutesToTimeString(overlapStartMin)} - ${minutesToTimeString(overlapEndMin)}`,
        });
      }
    }
  }

  return overlaps;
}

function isModeActiveOnDay(mode: SmartBlockMode, day: DayOfWeek, minuteOfDay: number): boolean {
  if (!mode.enabled) return false;
  const startMinutes = timeStringToMinutes(mode.startTime);
  const endMinutes = timeStringToMinutes(mode.endTime);

  if (startMinutes <= endMinutes) {
    return mode.activeDays.includes(day) && minuteOfDay >= startMinutes && minuteOfDay < endMinutes;
  }

  // Overnight
  if (minuteOfDay >= startMinutes) {
    return mode.activeDays.includes(day);
  }
  if (minuteOfDay < endMinutes) {
    const prev = getPreviousDay(day);
    return mode.activeDays.includes(prev);
  }
  return false;
}

export interface AppAccessSmartBlockDecision {
  isBlocked: boolean;
  reason?: string;
  ruleApplied?: 'explicit_app_block' | 'app_exception' | 'category_block' | 'whitelist_block' | 'category_allowed' | 'app_allowed' | 'default';
  activeModeName?: string;
  activeModeIcon?: string;
  availableAgainTime?: string;
}

/**
 * Deterministic application access evaluation during Smart Block.
 * Order of evaluation:
 * 1. If no Smart Block mode is active -> NOT BLOCKED
 * 2. Explicit App Block in active mode -> BLOCKED
 * 3. App Exception in active mode (e.g. Chess allowed during Study Time) -> NOT BLOCKED
 * 4. Category Block in active mode -> BLOCKED
 * 5. Explicit App Whitelist if defined -> ALLOWED if present, BLOCKED if strict whitelist
 * 6. Category Allowed in active mode -> NOT BLOCKED
 * 7. Default -> NOT BLOCKED (falls through to Usage Mode / standard app permissions)
 */
export function evaluateAppAccessInSmartBlock(
  app: AppInfo,
  activeMode: SmartBlockMode | null
): AppAccessSmartBlockDecision {
  if (!activeMode || !activeMode.enabled) {
    return { isBlocked: false, ruleApplied: 'default' };
  }

  const baseResult = {
    activeModeName: activeMode.name,
    activeModeIcon: activeMode.icon,
    availableAgainTime: activeMode.endTime,
  };

  // 1. Explicit Application Block
  if (activeMode.blockedApps && activeMode.blockedApps.includes(app.packageName)) {
    return {
      ...baseResult,
      isBlocked: true,
      reason: `${activeMode.name}: Application explicitly blocked`,
      ruleApplied: 'explicit_app_block',
    };
  }

  // 2. Application Exception (Exempted from category blocks)
  if (activeMode.exceptions && activeMode.exceptions.includes(app.packageName)) {
    return {
      ...baseResult,
      isBlocked: false,
      reason: `${activeMode.name}: Application exception granted`,
      ruleApplied: 'app_exception',
    };
  }

  // 3. Category Block
  if (activeMode.blockedCategories && activeMode.blockedCategories.includes(app.category)) {
    return {
      ...baseResult,
      isBlocked: true,
      reason: `${activeMode.name}: ${app.category.charAt(0).toUpperCase() + app.category.slice(1)} category blocked`,
      ruleApplied: 'category_block',
    };
  }

  // 4. Strict Whitelist Check: If mode has allowedApps defined and allowedCategories is empty, any non-listed app is blocked
  if (
    activeMode.allowedApps &&
    activeMode.allowedApps.length > 0 &&
    (!activeMode.allowedCategories || activeMode.allowedCategories.length === 0)
  ) {
    if (activeMode.allowedApps.includes(app.packageName)) {
      return {
        ...baseResult,
        isBlocked: false,
        reason: `${activeMode.name}: Application in allowed whitelist`,
        ruleApplied: 'app_allowed',
      };
    } else {
      return {
        ...baseResult,
        isBlocked: true,
        reason: `${activeMode.name}: Only specific allowed applications permitted`,
        ruleApplied: 'whitelist_block',
      };
    }
  }

  // 5. Explicit Category Allowed
  if (activeMode.allowedCategories && activeMode.allowedCategories.includes(app.category)) {
    return {
      ...baseResult,
      isBlocked: false,
      reason: `${activeMode.name}: Category allowed`,
      ruleApplied: 'category_allowed',
    };
  }

  // 6. Explicit App Allowed
  if (activeMode.allowedApps && activeMode.allowedApps.includes(app.packageName)) {
    return {
      ...baseResult,
      isBlocked: false,
      reason: `${activeMode.name}: Application allowed`,
      ruleApplied: 'app_allowed',
    };
  }

  return {
    ...baseResult,
    isBlocked: false,
    ruleApplied: 'default',
  };
}
