import { AppInfo, AppSettings, ChildProfile, EmergencyContact, EventLogItem, EventType, Language, SessionState, SmartBlockConfig, SmartBlockMode, UsageMode, VerificationRecord, WeeklySchedule, WebFilterConfig, AppBatteryUsage } from '../types';
import { INITIAL_APPS } from '../data/mockApps';
import { generateSalt, hashPin } from './crypto';
import { DEFAULT_SMART_BLOCK_MODES } from './smartBlockEngine';

const STORAGE_KEY_SETTINGS = 'pc_settings_v2';
const STORAGE_KEY_CHILD = 'pc_child_v2';
const STORAGE_KEY_SCHEDULE = 'pc_schedule_v2';
const STORAGE_KEY_APPS = 'pc_apps_v2';
const STORAGE_KEY_SESSION = 'pc_session_v2';
const STORAGE_KEY_EVENTS = 'pc_events_v2';
const STORAGE_KEY_VERIFICATIONS = 'pc_verifications_v2';

export const DEFAULT_SMART_BLOCK_CONFIG: SmartBlockConfig = {
  enabled: true,
  preset: 'school_hours',
  startTime: '08:00',
  endTime: '15:00',
  activeDays: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'],
  restrictedCategories: ['games', 'social', 'entertainment'],
  exemptEducational: true,
};

export const DEFAULT_WEB_FILTER_CONFIG: WebFilterConfig = {
  enabled: true,
  blockedCategories: ['adult', 'gambling', 'phishing', 'violence'],
  customBlockedUrls: [
    { id: 'url-1', urlPattern: 'badcontent.com', category: 'adult', isBlocked: true, notes: 'Inappropriate adult content' },
    { id: 'url-2', urlPattern: 'gambling-bet.net', category: 'gambling', isBlocked: true, notes: 'Gambling & casino' },
    { id: 'url-3', urlPattern: 'phishing-login.com', category: 'phishing', isBlocked: true, notes: 'Malicious phishing' },
  ],
  safeSearchEnabled: true,
};

export const DEFAULT_BATTERY_USAGE: AppBatteryUsage[] = [
  { packageName: 'com.zhiliaoapp.musically', appName: 'TikTok', icon: '🎵', foregroundBatteryPercent: 18.2, backgroundBatteryPercent: 12.5, totalBatteryPercent: 30.7, powerConsumptionMah: 1150, status: 'excessive' },
  { packageName: 'com.google.android.youtube', appName: 'YouTube', icon: '📺', foregroundBatteryPercent: 15.0, backgroundBatteryPercent: 8.3, totalBatteryPercent: 23.3, powerConsumptionMah: 890, status: 'high_background' },
  { packageName: 'com.instagram.android', appName: 'Instagram', icon: '📸', foregroundBatteryPercent: 10.4, backgroundBatteryPercent: 6.2, totalBatteryPercent: 16.6, powerConsumptionMah: 620, status: 'high_background' },
  { packageName: 'com.roblox.client', appName: 'Roblox', icon: '🎮', foregroundBatteryPercent: 12.1, backgroundBatteryPercent: 1.2, totalBatteryPercent: 13.3, powerConsumptionMah: 510, status: 'normal' },
  { packageName: 'com.whatsapp', appName: 'WhatsApp', icon: '💬', foregroundBatteryPercent: 4.2, backgroundBatteryPercent: 3.8, totalBatteryPercent: 8.0, powerConsumptionMah: 310, status: 'normal' },
  { packageName: 'com.google.android.apps.docs', appName: 'Google Docs', icon: '📄', foregroundBatteryPercent: 2.1, backgroundBatteryPercent: 0.4, totalBatteryPercent: 2.5, powerConsumptionMah: 95, status: 'normal' },
];

export const DEFAULT_USAGE_MODES: UsageMode[] = [
  {
    id: 'normal',
    name: 'Normal Mode',
    description: 'Default access with standard allowed apps.',
    icon: '🏠',
    isBuiltIn: true,
    allowedApps: [], // Interpreted as "all apps that have isAllowed = true"
  },
  {
    id: 'study',
    name: 'Study Mode',
    description: 'Focus on educational and school apps.',
    icon: '📚',
    isBuiltIn: true,
    allowedApps: ['com.example.calculator', 'com.example.dictionary', 'com.google.android.apps.classroom', 'com.duolingo'],
  },
  {
    id: 'gaming',
    name: 'Gaming Mode',
    description: 'Access to approved games and entertainment.',
    icon: '🎮',
    isBuiltIn: true,
    allowedApps: ['com.mojang.minecraftpe', 'com.roblox.client'],
  },
  {
    id: 'video',
    name: 'Video Mode',
    description: 'Watch allowed videos and movies.',
    icon: '🎬',
    isBuiltIn: true,
    allowedApps: ['com.google.android.youtube', 'com.netflix.mediaclient'],
  }
];

// Initial default schedule

export const DEFAULT_SCHEDULE: WeeklySchedule = {
  monday: [{ id: 'm1', startTime: '16:00', endTime: '18:00', enabled: true }],
  tuesday: [{ id: 't1', startTime: '16:00', endTime: '18:00', enabled: true }],
  wednesday: [{ id: 'w1', startTime: '16:00', endTime: '18:00', enabled: true }],
  thursday: [{ id: 'th1', startTime: '16:00', endTime: '18:00', enabled: true }],
  friday: [{ id: 'f1', startTime: '16:00', endTime: '20:00', enabled: true }],
  saturday: [
    { id: 's1', startTime: '08:00', endTime: '10:00', enabled: true },
    { id: 's2', startTime: '16:00', endTime: '18:00', enabled: true },
    { id: 's3', startTime: '20:00', endTime: '21:00', enabled: true },
  ],
  sunday: [
    { id: 'su1', startTime: '09:00', endTime: '11:00', enabled: true },
    { id: 'su2', startTime: '16:00', endTime: '18:00', enabled: true },
  ],
};

export const DEFAULT_CHILD: ChildProfile = {
  id: 'child_1',
  name: 'Adam',
  avatar: '👦',
  age: 10,
  dailyLimitMinutes: 120, // 2 hours for scheduled mode
  dailyFreeTimeAllowanceSeconds: 10800, // 3 hours (10800 seconds) for Free Mode
  sessionLimitMinutes: 45, // 45 mins
};

export const DEFAULT_CHILDREN_LIST: ChildProfile[] = [
  DEFAULT_CHILD,
  {
    id: 'child_2',
    name: 'Sarah',
    avatar: '👧',
    age: 8,
    dailyLimitMinutes: 90, // 1.5 hours
    dailyFreeTimeAllowanceSeconds: 7200, // 2 hours (7200 seconds) for Free Mode
    sessionLimitMinutes: 30,
  },
  {
    id: 'child_3',
    name: 'Leo',
    avatar: '🚀',
    age: 12,
    dailyLimitMinutes: 180, // 3 hours
    dailyFreeTimeAllowanceSeconds: 14400, // 4 hours (14400 seconds) for Free Mode
    sessionLimitMinutes: 60,
  },
];

export const DEFAULT_EMERGENCY_CONTACTS: EmergencyContact[] = [
  { id: 'e1', name: 'Mom (Sarah)', phone: '+1 (555) 019-2831', relation: 'Mother' },
  { id: 'e2', name: 'Dad (Michael)', phone: '+1 (555) 019-4822', relation: 'Father' },
  { id: 'e3', name: 'Emergency Services', phone: '911', relation: 'Emergency' },
];

export async function getStoredSettings(): Promise<AppSettings> {
  const raw = localStorage.getItem(STORAGE_KEY_SETTINGS);
  if (raw) {
    try {
      const parsed = JSON.parse(raw);
      return {
        ...parsed,
        controlMode: parsed.controlMode ?? 'free',
        parentSessionTimeoutMinutes: parsed.parentSessionTimeoutMinutes ?? 5,
        flagSecureEnabled: parsed.flagSecureEnabled ?? true,
        smartBlock: parsed.smartBlock ?? DEFAULT_SMART_BLOCK_CONFIG,
        smartBlockModes: parsed.smartBlockModes && parsed.smartBlockModes.length > 0 ? parsed.smartBlockModes : DEFAULT_SMART_BLOCK_MODES,
        webFilter: parsed.webFilter ?? DEFAULT_WEB_FILTER_CONFIG,
        batteryMonitor: parsed.batteryMonitor ?? DEFAULT_BATTERY_USAGE,
        usageModes: parsed.usageModes && parsed.usageModes.length > 0 ? parsed.usageModes : DEFAULT_USAGE_MODES,
      };
    } catch (e) {
      console.error('Failed to parse stored settings:', e);
    }
  }

  // Detect browser/device language on first launch
  const browserLang = (typeof navigator !== 'undefined' && (navigator.language || (navigator as any).userLanguage || ''))
    .toLowerCase();
  const defaultLang: Language = browserLang.startsWith('ar') ? 'ar' : 'en';

  // Create initial default PIN '1234' securely
  const defaultSalt = await generateSalt();
  const defaultHash = await hashPin('1234', defaultSalt);

  const initialSettings: AppSettings = {
    language: defaultLang,
    controlMode: 'free',
    parentPinHash: defaultHash,
    parentPinSalt: defaultSalt,
    failedPinAttempts: 0,
    pinLockoutUntil: 0,
    parentSessionTimeoutMinutes: 5,
    flagSecureEnabled: true,
    requireVerificationForExtraTime: true,
    timeManipulationProtection: true,
    deviceOwnerEnabled: true,
    accessibilityEnabled: true,
    usageAccessEnabled: true,
    emergencyContacts: DEFAULT_EMERGENCY_CONTACTS,
    verificationRetentionDays: 30,
    smartBlock: DEFAULT_SMART_BLOCK_CONFIG,
    smartBlockModes: DEFAULT_SMART_BLOCK_MODES,
    webFilter: DEFAULT_WEB_FILTER_CONFIG,
    batteryMonitor: DEFAULT_BATTERY_USAGE,
    usageModes: DEFAULT_USAGE_MODES,
  };

  localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(initialSettings));
  return initialSettings;
}

export function saveSettings(settings: AppSettings): void {
  localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(settings));
}

const STORAGE_KEY_CHILDREN_LIST = 'pc_children_list_v2';
const STORAGE_KEY_ACTIVE_CHILD_ID = 'pc_active_child_id_v2';

export function getStoredChildrenList(): ChildProfile[] {
  const raw = localStorage.getItem(STORAGE_KEY_CHILDREN_LIST);
  if (raw) {
    try {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.map((c: any) => ({
          ...c,
          dailyFreeTimeAllowanceSeconds: c.dailyFreeTimeAllowanceSeconds ?? 10800,
          dailyLimitMinutes: c.dailyLimitMinutes ?? 120,
          sessionLimitMinutes: c.sessionLimitMinutes ?? 45,
        }));
      }
    } catch (e) {}
  }
  localStorage.setItem(STORAGE_KEY_CHILDREN_LIST, JSON.stringify(DEFAULT_CHILDREN_LIST));
  return DEFAULT_CHILDREN_LIST;
}

export function saveChildrenList(list: ChildProfile[]): void {
  localStorage.setItem(STORAGE_KEY_CHILDREN_LIST, JSON.stringify(list));
}

export function getStoredActiveChildId(): string {
  const raw = localStorage.getItem(STORAGE_KEY_ACTIVE_CHILD_ID);
  if (raw) {
    return raw;
  }
  const defaultId = DEFAULT_CHILDREN_LIST[0].id;
  localStorage.setItem(STORAGE_KEY_ACTIVE_CHILD_ID, defaultId);
  return defaultId;
}

export function saveActiveChildId(id: string): void {
  localStorage.setItem(STORAGE_KEY_ACTIVE_CHILD_ID, id);
}

export function getStoredChild(): ChildProfile {
  const children = getStoredChildrenList();
  const activeId = getStoredActiveChildId();
  const found = children.find(c => c.id === activeId);
  if (found) {
    return found;
  }
  if (children.length > 0) {
    return children[0];
  }
  return DEFAULT_CHILD;
}

export function saveChild(child: ChildProfile): void {
  localStorage.setItem(STORAGE_KEY_CHILD, JSON.stringify(child));
  const children = getStoredChildrenList();
  const index = children.findIndex(c => c.id === child.id);
  if (index >= 0) {
    children[index] = child;
  } else {
    children.push(child);
  }
  saveChildrenList(children);
}

export function getStoredSchedule(): WeeklySchedule {
  const raw = localStorage.getItem(STORAGE_KEY_SCHEDULE);
  if (raw) {
    try {
      return JSON.parse(raw);
    } catch (e) {}
  }
  localStorage.setItem(STORAGE_KEY_SCHEDULE, JSON.stringify(DEFAULT_SCHEDULE));
  return DEFAULT_SCHEDULE;
}

export function saveSchedule(schedule: WeeklySchedule): void {
  localStorage.setItem(STORAGE_KEY_SCHEDULE, JSON.stringify(schedule));
}

export function getStoredApps(): AppInfo[] {
  const raw = localStorage.getItem(STORAGE_KEY_APPS);
  if (raw) {
    try {
      return JSON.parse(raw);
    } catch (e) {}
  }
  localStorage.setItem(STORAGE_KEY_APPS, JSON.stringify(INITIAL_APPS));
  return INITIAL_APPS;
}

export function saveApps(apps: AppInfo[]): void {
  localStorage.setItem(STORAGE_KEY_APPS, JSON.stringify(apps));
}

export function getStoredSessionState(childId?: string): SessionState {
  const activeId = childId || getStoredActiveChildId();
  const key = `${STORAGE_KEY_SESSION}_${activeId}`;
  const raw = localStorage.getItem(key);
  const todayStr = new Date().toISOString().split('T')[0];

  if (raw) {
    try {
      const parsed = JSON.parse(raw);
      return {
        ...parsed,
        freeModeUsedSecondsToday: parsed.freeModeUsedSecondsToday ?? 0,
        lastResetDateStr: parsed.lastResetDateStr ?? todayStr,
        extraTimeEndTimestamp: parsed.extraTimeEndTimestamp ?? null,
        extraTimeConsumed: parsed.extraTimeConsumed ?? false,
        activeUsageModeId: parsed.activeUsageModeId ?? 'normal',
      };
    } catch (e) {}
  }

  const initialSession: SessionState = {
    isActive: true,
    sessionStartTime: Date.now(),
    elapsedTodayMinutes: 0,
    freeModeUsedSecondsToday: 0,
    lastResetDateStr: todayStr,
    activeSessionDurationMinutes: 0,
    extraTimeMinutes: 0,
    extraTimeGrantedAt: null,
    extraTimeEndTimestamp: null,
    extraTimeConsumed: false,
    isLocked: false,
    lockReason: null,
    lastHeartbeatTimestamp: Date.now(),
    activeUsageModeId: 'normal',
  };
  localStorage.setItem(key, JSON.stringify(initialSession));
  return initialSession;
}

export function saveSessionState(session: SessionState, childId?: string): void {
  const activeId = childId || getStoredActiveChildId();
  const key = `${STORAGE_KEY_SESSION}_${activeId}`;
  localStorage.setItem(key, JSON.stringify(session));
}

export function getStoredEventLogs(): EventLogItem[] {
  const raw = localStorage.getItem(STORAGE_KEY_EVENTS);
  if (raw) {
    try {
      return JSON.parse(raw);
    } catch (e) {}
  }

  const initialLogs: EventLogItem[] = [
    {
      id: 'log_1',
      timestamp: Date.now() - 3600000 * 2,
      type: 'session_started',
      description: 'Scheduled usage session started automatically',
      childName: 'Adam',
    },
    {
      id: 'log_2',
      timestamp: Date.now() - 3600000 * 1.5,
      type: 'blocked_app_attempt',
      description: 'Blocked launch attempt: YouTube (com.google.android.youtube)',
      childName: 'Adam',
    },
    {
      id: 'log_3',
      timestamp: Date.now() - 3600000,
      type: 'pin_success',
      description: 'Parent PIN authenticated successfully',
      childName: 'Adam',
    },
  ];

  localStorage.setItem(STORAGE_KEY_EVENTS, JSON.stringify(initialLogs));
  return initialLogs;
}

export function addEventLog(type: EventType, description: string, childName: string = 'Adam', details?: Record<string, any>): void {
  const logs = getStoredEventLogs();
  const newItem: EventLogItem = {
    id: `log_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
    timestamp: Date.now(),
    type,
    description,
    childName,
    details,
  };
  const updated = [newItem, ...logs].slice(0, 200); // keep max 200 logs
  localStorage.setItem(STORAGE_KEY_EVENTS, JSON.stringify(updated));
}

export function getStoredVerifications(): VerificationRecord[] {
  const raw = localStorage.getItem(STORAGE_KEY_VERIFICATIONS);
  if (raw) {
    try {
      return JSON.parse(raw);
    } catch (e) {}
  }
  return [];
}

export function addVerificationRecord(photoUrl: string, reason: string, childName: string = 'Adam'): void {
  const records = getStoredVerifications();
  const newRec: VerificationRecord = {
    id: `verif_${Date.now()}`,
    timestamp: Date.now(),
    childId: 'child_1',
    childName,
    photoUrl,
    reason,
  };
  const updated = [newRec, ...records];
  localStorage.setItem(STORAGE_KEY_VERIFICATIONS, JSON.stringify(updated));
  addEventLog('verification_photo_taken', `Verification photo taken for: ${reason}`, childName);
}

export function clearAllChildData(): void {
  localStorage.removeItem(STORAGE_KEY_SESSION);
  localStorage.removeItem(STORAGE_KEY_EVENTS);
  localStorage.removeItem(STORAGE_KEY_VERIFICATIONS);
  localStorage.removeItem(STORAGE_KEY_APPS);
}
