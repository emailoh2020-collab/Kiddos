import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { translations } from '../../data/translations';
import { useResponsiveLayout } from '../../utils/useResponsiveLayout';
import { AppIcon } from '../common/AppIcon';
import { BarChart3, Calendar, PieChart as PieIcon, TrendingUp, Clock } from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
} from 'recharts';

export const StatisticsDashboard: React.FC = () => {
  const { apps, language } = useApp();
  const t = translations[language];
  const { isTablet } = useResponsiveLayout();

  const [dateFilter, setDateFilter] = useState<'today' | 'yesterday' | '7days' | '30days'>('today');

  // Chart data 1: Daily Hourly Usage Breakdown
  const hourlyData = [
    { hour: '08:00', minutes: 15 },
    { hour: '10:00', minutes: 5 },
    { hour: '12:00', minutes: 20 },
    { hour: '14:00', minutes: 10 },
    { hour: '16:00', minutes: 45 },
    { hour: '18:00', minutes: 30 },
    { hour: '20:00', minutes: 25 },
  ];

  // Chart data 2: Weekly Screen Time Trend
  const weeklyTrendData = [
    { day: 'Mon', minutes: 110 },
    { day: 'Tue', minutes: 105 },
    { day: 'Wed', minutes: 120 },
    { day: 'Thu', minutes: 90 },
    { day: 'Fri', minutes: 140 },
    { day: 'Sat', minutes: 175 },
    { day: 'Sun', minutes: 160 },
  ];

  // Chart data 3: App Usage Distribution
  const pieColors = ['#3b82f6', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6', '#64748b'];
  const appPieData = apps
    .filter((a) => a.totalUsageMinutes > 0)
    .map((a) => ({ name: a.appName, value: a.totalUsageMinutes }));

  return (
    <div className="space-y-3.5 sm:space-y-4">
      {/* Header & Date Filter */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl sm:rounded-3xl p-3.5 sm:p-4 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center space-x-2.5 rtl:space-x-reverse min-w-0">
          <AppIcon icon={BarChart3} size="sm" colorScheme="amber" shape="rounded" />
          <div className="min-w-0">
            <h2 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white">
              {t.statistics}
            </h2>
            <p className="text-[11px] text-slate-500 font-medium mt-0.5">
              Detailed breakdown of daily, weekly, and application-specific screen time metrics.
            </p>
          </div>
        </div>

        {/* Filter Dropdown */}
        <div className="flex items-center space-x-2 rtl:space-x-reverse shrink-0">
          <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0 aspect-square" />
          <select
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value as any)}
            className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 dark:text-white font-bold focus:outline-none focus:border-blue-500 min-h-[34px]"
          >
            <option value="today">Today</option>
            <option value="yesterday">Yesterday</option>
            <option value="7days">Last 7 Days</option>
            <option value="30days">Last 30 Days</option>
          </select>
        </div>
      </div>

      {/* Grid: Charts (Adaptive layout) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3.5 sm:gap-4">
        {/* Weekly Trend Chart */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl sm:rounded-3xl p-3.5 sm:p-4 shadow-2xs">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-blue-600 shrink-0 aspect-square" />
              <span>Weekly Usage Trend</span>
            </h3>
            <span className="text-[10px] text-slate-400 font-medium">Minutes/day</span>
          </div>

          <div className="h-48 sm:h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={weeklyTrendData}>
                <defs>
                  <linearGradient id="colorTrend" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563eb" stopOpacity={0.8} />
                    <stop offset="95%" stopColor="#2563eb" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="day" stroke="#94a3b8" fontSize={10} />
                <YAxis stroke="#94a3b8" fontSize={10} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderColor: '#e2e8f0',
                    borderRadius: '12px',
                    boxShadow: '0 2px 4px -1px rgb(0 0 0 / 0.1)',
                    fontSize: '11px',
                  }}
                  itemStyle={{ color: '#2563eb', fontWeight: 'bold' }}
                />
                <Area
                  type="monotone"
                  dataKey="minutes"
                  stroke="#2563eb"
                  fillOpacity={1}
                  fill="url(#colorTrend)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Hourly Distribution */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl sm:rounded-3xl p-3.5 sm:p-4 shadow-2xs">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-emerald-600 shrink-0 aspect-square" />
              <span>Hourly Usage Heatmap</span>
            </h3>
            <span className="text-[10px] text-slate-400 font-medium">Today's usage</span>
          </div>

          <div className="h-48 sm:h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={hourlyData}>
                <XAxis dataKey="hour" stroke="#94a3b8" fontSize={10} />
                <YAxis stroke="#94a3b8" fontSize={10} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderColor: '#e2e8f0',
                    borderRadius: '12px',
                    boxShadow: '0 2px 4px -1px rgb(0 0 0 / 0.1)',
                    fontSize: '11px',
                  }}
                  itemStyle={{ color: '#059669', fontWeight: 'bold' }}
                />
                <Bar dataKey="minutes" fill="#10b981" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* App Usage Distribution Pie Chart */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl sm:rounded-3xl p-3.5 sm:p-4 shadow-2xs lg:col-span-2">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
              <PieIcon className="w-3.5 h-3.5 text-amber-600 shrink-0 aspect-square" />
              <span>Application Screen Time Share</span>
            </h3>
            <span className="text-[10px] text-slate-400 font-medium">Accumulated usage</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 items-center gap-4">
            <div className="h-48 sm:h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={appPieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={45}
                    outerRadius={70}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {appPieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={pieColors[index % pieColors.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#ffffff',
                      borderColor: '#e2e8f0',
                      borderRadius: '12px',
                      boxShadow: '0 2px 4px -1px rgb(0 0 0 / 0.1)',
                      fontSize: '11px',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>

            {/* Legend Breakdown */}
            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              {appPieData.map((item, idx) => (
                <div
                  key={item.name}
                  className="flex items-center justify-between text-xs p-2 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200/80 dark:border-slate-700"
                >
                  <div className="flex items-center space-x-2 rtl:space-x-reverse min-w-0">
                    <span
                      className="w-2.5 h-2.5 rounded-full shrink-0 aspect-square"
                      style={{ backgroundColor: pieColors[idx % pieColors.length] }}
                    />
                    <span className="text-slate-700 dark:text-slate-200 font-bold truncate max-w-[160px]">
                      {item.name}
                    </span>
                  </div>
                  <span className="font-extrabold text-blue-600 dark:text-blue-400 shrink-0 text-xs">
                    {item.value}m
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
