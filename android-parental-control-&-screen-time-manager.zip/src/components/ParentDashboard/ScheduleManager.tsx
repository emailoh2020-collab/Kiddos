import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { DayOfWeek, UsagePeriod, WeeklySchedule } from '../../types';
import { translations } from '../../data/translations';
import { useResponsiveLayout } from '../../utils/useResponsiveLayout';
import { AppIcon } from '../common/AppIcon';
import { Calendar, Plus, Trash2, Copy, Check, Clock, Power } from 'lucide-react';

const DAYS_ORDER: DayOfWeek[] = [
  'monday',
  'tuesday',
  'wednesday',
  'thursday',
  'friday',
  'saturday',
  'sunday',
];

export const ScheduleManager: React.FC = () => {
  const { schedule, updateSchedule, language } = useApp();
  const t = translations[language];
  const { isTablet } = useResponsiveLayout();

  const [selectedDay, setSelectedDay] = useState<DayOfWeek>('monday');
  const [newStartTime, setNewStartTime] = useState('16:00');
  const [newEndTime, setNewEndTime] = useState('18:00');
  const [copiedMsg, setCopiedMsg] = useState(false);

  const currentPeriods = schedule[selectedDay] || [];

  const handleAddPeriod = () => {
    const newPeriod: UsagePeriod = {
      id: `p_${Date.now()}`,
      startTime: newStartTime,
      endTime: newEndTime,
      enabled: true,
    };
    const updatedDay = [...currentPeriods, newPeriod];
    const updatedSchedule: WeeklySchedule = {
      ...schedule,
      [selectedDay]: updatedDay,
    };
    updateSchedule(updatedSchedule);
  };

  const handleTogglePeriod = (periodId: string) => {
    const updatedDay = currentPeriods.map((p) =>
      p.id === periodId ? { ...p, enabled: !p.enabled } : p
    );
    updateSchedule({ ...schedule, [selectedDay]: updatedDay });
  };

  const handleDeletePeriod = (periodId: string) => {
    const updatedDay = currentPeriods.filter((p) => p.id !== periodId);
    updateSchedule({ ...schedule, [selectedDay]: updatedDay });
  };

  const handleCopyDayScheduleToAll = () => {
    const dayToCopy = schedule[selectedDay];
    const newSchedule: WeeklySchedule = { ...schedule };
    DAYS_ORDER.forEach((d) => {
      newSchedule[d] = dayToCopy.map((p) => ({
        ...p,
        id: `p_${d}_${Math.random().toString(36).substr(2, 4)}`,
      }));
    });
    updateSchedule(newSchedule);
    setCopiedMsg(true);
    setTimeout(() => setCopiedMsg(false), 2500);
  };

  return (
    <div className="space-y-3.5 sm:space-y-4">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl sm:rounded-3xl p-3.5 sm:p-4.5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center space-x-2.5 rtl:space-x-reverse min-w-0">
          <AppIcon icon={Calendar} size="sm" colorScheme="blue" shape="rounded" />
          <div className="min-w-0">
            <h2 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white">
              {t.schedule}
            </h2>
            <p className="text-[11px] text-slate-500 font-medium mt-0.5">
              Configure multiple usage windows per day. Lock Mode activates outside these hours.
            </p>
          </div>
        </div>

        <button
          onClick={handleCopyDayScheduleToAll}
          className="px-3 py-2 bg-slate-900 dark:bg-slate-800 hover:bg-slate-800 dark:hover:bg-slate-700 text-white text-xs font-bold rounded-xl transition flex items-center justify-center space-x-1.5 rtl:space-x-reverse shadow-2xs shrink-0 min-h-[36px]"
        >
          {copiedMsg ? (
            <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0 aspect-square" />
          ) : (
            <Copy className="w-3.5 h-3.5 text-blue-400 shrink-0 aspect-square" />
          )}
          <span>
            {copiedMsg ? 'Copied to all days!' : `Copy ${selectedDay.toUpperCase()} to All Days`}
          </span>
        </button>
      </div>

      {/* Day Selectors Tabs (Responsive flex wrap / grid) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-1.5 sm:gap-2">
        {DAYS_ORDER.map((d) => {
          const count = (schedule[d] || []).filter((p) => p.enabled).length;
          const isSelected = selectedDay === d;
          return (
            <button
              key={d}
              onClick={() => setSelectedDay(d)}
              className={`p-2 sm:p-2.5 rounded-xl border text-center transition flex flex-col items-center justify-center min-h-[52px] ${
                isSelected
                  ? 'bg-blue-600 border-blue-600 text-white shadow-2xs'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
              }`}
            >
              <span className="text-xs font-extrabold uppercase tracking-wider">{d.slice(0, 3)}</span>
              <span
                className={`text-[9px] mt-0.5 font-bold px-1.5 py-0.5 rounded-md ${
                  isSelected
                    ? 'bg-blue-700 text-blue-100'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                }`}
              >
                {count} {count === 1 ? 'window' : 'windows'}
              </span>
            </button>
          );
        })}
      </div>

      {/* Day Details & Period Manager */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3.5 sm:gap-4">
        {/* Active Periods List */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl sm:rounded-3xl p-3.5 sm:p-4.5 shadow-xs">
          <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-white mb-3 capitalize flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-blue-600 shrink-0 aspect-square" />
            <span>{selectedDay} Usage Windows</span>
          </h3>

          {currentPeriods.length === 0 ? (
            <div className="p-6 text-center bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-dashed border-slate-200 dark:border-slate-700">
              <p className="text-xs text-slate-500 font-medium">
                No usage windows configured for {selectedDay}.
              </p>
              <p className="text-[10px] text-slate-400 mt-0.5">
                Device will remain locked on this day unless windows are added.
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {currentPeriods.map((period) => (
                <div
                  key={period.id}
                  className={`p-2.5 sm:p-3 rounded-xl border transition flex items-center justify-between ${
                    period.enabled
                      ? 'bg-slate-50/80 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white'
                      : 'bg-slate-100/50 dark:bg-slate-800/30 border-slate-200 dark:border-slate-800 text-slate-400'
                  }`}
                >
                  <div className="flex items-center space-x-2.5 rtl:space-x-reverse min-w-0">
                    <button
                      onClick={() => handleTogglePeriod(period.id)}
                      className={`p-1.5 rounded-lg border transition shrink-0 aspect-square min-w-[32px] min-h-[32px] flex items-center justify-center ${
                        period.enabled
                          ? 'bg-emerald-50 text-emerald-600 border-emerald-200 dark:bg-emerald-950/40 dark:border-emerald-800'
                          : 'bg-slate-200 dark:bg-slate-700 text-slate-400 border-slate-300'
                      }`}
                      title={period.enabled ? 'Disable Window' : 'Enable Window'}
                    >
                      <Power className="w-3.5 h-3.5 shrink-0 aspect-square" />
                    </button>
                    <div>
                      <div className="text-xs font-mono font-bold text-slate-900 dark:text-white">
                        {period.startTime} → {period.endTime}
                      </div>
                      <span className="text-[9px] text-slate-500 font-medium">
                        {period.enabled ? 'Active schedule window' : 'Disabled window'}
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => handleDeletePeriod(period.id)}
                    className="p-1.5 text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-slate-800 rounded-lg transition aspect-square min-w-[32px] min-h-[32px] flex items-center justify-center shrink-0"
                    title="Delete Window"
                  >
                    <Trash2 className="w-3.5 h-3.5 shrink-0 aspect-square" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Add Window Form */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl sm:rounded-3xl p-3.5 sm:p-4.5 shadow-xs flex flex-col justify-between">
          <div>
            <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-white mb-0.5">
              Add New Window
            </h3>
            <p className="text-[11px] text-slate-500 font-medium mb-3">
              Add play period for <span className="capitalize font-bold">{selectedDay}</span>
            </p>

            <div className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">Start Time</label>
                <input
                  type="time"
                  value={newStartTime}
                  onChange={(e) => setNewStartTime(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5 text-xs font-bold text-slate-800 dark:text-white focus:outline-none focus:border-blue-500 min-h-[36px]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">End Time</label>
                <input
                  type="time"
                  value={newEndTime}
                  onChange={(e) => setNewEndTime(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5 text-xs font-bold text-slate-800 dark:text-white focus:outline-none focus:border-blue-500 min-h-[36px]"
                />
              </div>
            </div>
          </div>

          <button
            onClick={handleAddPeriod}
            className="w-full mt-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-2xs transition flex items-center justify-center space-x-1.5 rtl:space-x-reverse min-h-[38px]"
          >
            <Plus className="w-3.5 h-3.5 shrink-0 aspect-square" />
            <span>Add Window to {selectedDay}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
