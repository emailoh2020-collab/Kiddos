import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { translations } from '../../data/translations';
import { AppCategory } from '../../types';
import { useResponsiveLayout } from '../../utils/useResponsiveLayout';
import { AppIcon } from '../common/AppIcon';
import {
  Layers,
  Search,
  CheckCircle,
  Ban,
  ShieldCheck,
  Filter,
  Sparkles,
  Gamepad2,
  MessageSquare,
  Film,
  Wrench,
  GraduationCap,
  Sliders,
} from 'lucide-react';

export const AppManager: React.FC = () => {
  const {
    apps,
    updateAppStatus,
    language,
    smartBlockModes,
    activeSmartBlockMode,
    isSmartBlockActiveNow,
    isAppRestrictedBySmartBlock,
    setActiveTab,
  } = useApp();
  const t = translations[language];
  const { isTablet } = useResponsiveLayout();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterTab, setFilterTab] = useState<
    'all' | 'allowed' | 'blocked' | 'smart_blocked' | 'lock' | 'educational'
  >('all');

  const categoriesList: { key: AppCategory; label: string; icon: any; color: string }[] = [
    { key: 'games', label: 'Games', icon: Gamepad2, color: 'purple' },
    { key: 'social', label: 'Social Media', icon: MessageSquare, color: 'blue' },
    { key: 'entertainment', label: 'Entertainment / Video', icon: Film, color: 'amber' },
    { key: 'utilities', label: 'Utilities', icon: Wrench, color: 'slate' },
    { key: 'educational', label: 'Educational', icon: GraduationCap, color: 'emerald' },
  ];

  const filteredApps = apps.filter((app) => {
    const matchesSearch =
      app.appName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.packageName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.category.toLowerCase().includes(searchTerm.toLowerCase());

    if (!matchesSearch) return false;
    if (filterTab === 'allowed') return app.isAllowed;
    if (filterTab === 'blocked') return !app.isAllowed;
    if (filterTab === 'smart_blocked') return isAppRestrictedBySmartBlock(app);
    if (filterTab === 'lock') return app.allowDuringLock;
    if (filterTab === 'educational') return app.category === 'educational';
    return true;
  });

  const smartBlockedCount = apps.filter((a) => isAppRestrictedBySmartBlock(a)).length;
  const enabledModesCount = smartBlockModes.filter((m) => m.enabled).length;

  return (
    <div className="space-y-3.5 sm:space-y-4">
      {/* Header & Search */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl sm:rounded-3xl p-3.5 sm:p-4.5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center space-x-2.5 rtl:space-x-reverse min-w-0">
          <AppIcon icon={Layers} size="sm" colorScheme="blue" shape="rounded" />
          <div className="min-w-0">
            <div className="flex items-center space-x-1.5 rtl:space-x-reverse flex-wrap gap-1">
              <h2 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white">
                {t.apps}
              </h2>
              {enabledModesCount > 0 && (
                <span
                  className={`text-[9px] font-extrabold px-2 py-0.5 rounded-full flex items-center space-x-1 rtl:space-x-reverse ${
                    isSmartBlockActiveNow
                      ? 'bg-amber-100 text-amber-800 border border-amber-300 animate-pulse'
                      : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                  }`}
                >
                  <Sparkles className="w-2.5 h-2.5 shrink-0 aspect-square" />
                  <span>
                    {isSmartBlockActiveNow
                      ? `${activeSmartBlockMode?.icon || ''} ${activeSmartBlockMode?.name || t.smartBlockActive}`
                      : t.smartBlockInactive}
                  </span>
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-500 font-medium mt-0.5">
              Control permitted applications and restrict distraction categories during study hours.
            </p>
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative w-full md:w-64 shrink-0">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 rtl:left-auto rtl:right-3 top-2.5 shrink-0 aspect-square" />
          <input
            type="text"
            placeholder={t.searchApps}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl pl-9 rtl:pl-3 rtl:pr-9 pr-3 py-2 text-xs text-slate-800 dark:text-white font-medium focus:outline-none focus:border-blue-500 min-h-[38px]"
          />
        </div>
      </div>

      {/* Smart Block 2.0 Multi-Schedule Hub Card */}
      <div className="bg-gradient-to-br from-indigo-900 via-slate-900 to-indigo-950 text-white rounded-2xl sm:rounded-3xl border border-indigo-800/60 p-4 sm:p-5 shadow-xs relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-indigo-800/50">
          <div className="flex items-center space-x-3 rtl:space-x-reverse min-w-0">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center text-xl shrink-0">
              {activeSmartBlockMode ? activeSmartBlockMode.icon : '✨'}
            </div>
            <div className="min-w-0">
              <div className="flex items-center space-x-2 rtl:space-x-reverse flex-wrap gap-1">
                <h3 className="text-xs sm:text-sm font-black text-white">
                  Smart Block 2.0 Engine
                </h3>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-indigo-500/30 text-indigo-200 border border-indigo-400/30 uppercase tracking-wide">
                  {enabledModesCount} Schedules Configured
                </span>
              </div>
              <p className="text-[11px] text-slate-300 font-medium mt-0.5">
                {activeSmartBlockMode
                  ? `Active Now: ${activeSmartBlockMode.icon} ${activeSmartBlockMode.name} (${activeSmartBlockMode.startTime} - ${activeSmartBlockMode.endTime})`
                  : 'Multi-schedule automatic restriction engine operating by local time.'}
              </p>
            </div>
          </div>

          <button
            onClick={() => setActiveTab('smart_block')}
            className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white text-xs font-black rounded-xl shadow-xs transition flex items-center space-x-1.5 rtl:space-x-reverse shrink-0 min-h-[38px]"
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Manage All Smart Block Rules</span>
          </button>
        </div>

        {/* Quick Mode Previews */}
        <div className="pt-3 grid grid-cols-2 sm:grid-cols-4 gap-2">
          {smartBlockModes.slice(0, 4).map((m) => (
            <div
              key={m.id}
              className={`p-2.5 rounded-xl border text-xs ${
                activeSmartBlockMode?.id === m.id
                  ? 'bg-amber-500/20 border-amber-400/50 text-amber-200'
                  : m.enabled
                  ? 'bg-slate-800/70 border-slate-700/70 text-slate-300'
                  : 'bg-slate-900/40 border-slate-800/40 opacity-50 text-slate-500'
              }`}
            >
              <div className="font-extrabold flex items-center gap-1.5 truncate">
                <span>{m.icon}</span>
                <span className="truncate">{m.name}</span>
              </div>
              <div className="text-[10px] font-mono opacity-80 mt-0.5">
                {m.startTime} - {m.endTime}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Filter Tabs (Responsive Scrollable / Wrap) */}
      <div className="flex flex-wrap gap-1.5">
        {[
          { id: 'all', label: `${t.allApps} (${apps.length})` },
          {
            id: 'smart_blocked',
            label: `${t.smartBlockFilter} (${smartBlockedCount})`,
            icon: Sparkles,
          },
          {
            id: 'allowed',
            label: `${t.allowedOnly} (${apps.filter((a) => a.isAllowed).length})`,
          },
          {
            id: 'blocked',
            label: `${t.blockedOnly} (${apps.filter((a) => !a.isAllowed).length})`,
          },
          {
            id: 'educational',
            label: `Educational (${apps.filter((a) => a.category === 'educational').length})`,
            icon: GraduationCap,
          },
          {
            id: 'lock',
            label: `${t.lockModeAllowed} (${apps.filter((a) => a.allowDuringLock).length})`,
          },
        ].map((tab) => {
          const isSelected = filterTab === tab.id;
          const TabIcon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setFilterTab(tab.id as any)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition flex items-center space-x-1.5 rtl:space-x-reverse min-h-[34px] ${
                isSelected
                  ? 'bg-blue-600 text-white border-blue-600 shadow-2xs'
                  : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50'
              }`}
            >
              {TabIcon && <TabIcon className="w-3 h-3 shrink-0 aspect-square" />}
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* App List Grid (Adaptive columns: 1 col on phone, 2 cols on tablet portrait, 3 cols on tablet landscape) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-3.5">
        {filteredApps.map((app) => {
          const isRestrictedBySmart = isAppRestrictedBySmartBlock(app);

          return (
            <div
              key={app.packageName}
              className={`p-3.5 sm:p-4 rounded-2xl border transition flex flex-col justify-between ${
                isRestrictedBySmart
                  ? 'bg-amber-50/70 dark:bg-amber-950/30 border-amber-300 dark:border-amber-800 shadow-2xs'
                  : app.isAllowed
                  ? 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-xs'
                  : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200/80 dark:border-slate-700/80 opacity-90'
              }`}
            >
              <div>
                <div className="flex items-start justify-between mb-2.5">
                  <div className="flex items-center space-x-2.5 rtl:space-x-reverse min-w-0">
                    <AppIcon
                      icon={app.icon}
                      text={app.appName.charAt(0)}
                      size="sm"
                      colorScheme={
                        app.category === 'educational'
                          ? 'emerald'
                          : isRestrictedBySmart
                          ? 'amber'
                          : app.isAllowed
                          ? 'blue'
                          : 'red'
                      }
                      shape="rounded"
                    />
                    <div className="min-w-0">
                      <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-white leading-tight truncate">
                        {app.appName}
                      </h3>
                      <p className="text-[9px] text-slate-400 font-mono mt-0.5 truncate max-w-[130px]">
                        {app.packageName}
                      </p>
                    </div>
                  </div>

                  <span
                    className={`text-[8px] font-extrabold px-1.5 py-0.5 rounded-full border shrink-0 uppercase ${
                      app.category === 'educational'
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : app.category === 'games'
                        ? 'bg-purple-50 text-purple-700 border-purple-200'
                        : app.category === 'social'
                        ? 'bg-sky-50 text-sky-700 border-sky-200'
                        : 'bg-slate-50 text-slate-700 border-slate-200'
                    }`}
                  >
                    {app.category}
                  </span>
                </div>

                {/* Smart Block Alert Badge */}
                {isRestrictedBySmart && (
                  <div className="text-[10px] font-extrabold px-2 py-0.5 rounded-lg mb-2.5 flex items-center space-x-1 rtl:space-x-reverse bg-amber-100 text-amber-900 border border-amber-300">
                    <Sparkles className="w-3 h-3 shrink-0 aspect-square" />
                    <span className="truncate">
                      {activeSmartBlockMode
                        ? `${activeSmartBlockMode.icon} Restricted by ${activeSmartBlockMode.name}`
                        : t.smartBlockRestrictedNow}
                    </span>
                  </div>
                )}

                {/* Usage stats */}
                <div className="grid grid-cols-2 gap-1.5 text-[10px] text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/60 p-2 rounded-lg mb-3 border border-slate-200/60 dark:border-slate-700">
                  <div>
                    <span className="text-slate-400 block text-[9px] font-bold">
                      {t.usageTime}
                    </span>
                    <span className="font-bold text-blue-600">{app.totalUsageMinutes} mins</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[9px] font-bold">
                      {t.launchCount}
                    </span>
                    <span className="font-bold text-slate-800 dark:text-white">
                      {app.launchCount} times
                    </span>
                  </div>
                </div>
              </div>

              {/* Controls */}
              <div className="space-y-1.5 pt-1.5 border-t border-slate-100 dark:border-slate-800">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300">
                    Status
                  </span>
                  <button
                    onClick={() =>
                      updateAppStatus(app.packageName, !app.isAllowed, app.allowDuringLock)
                    }
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition min-h-[30px] ${
                      app.isAllowed
                        ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                        : 'bg-red-600 hover:bg-red-700 text-white'
                    }`}
                  >
                    {app.isAllowed ? 'Allowed' : 'Blocked'}
                  </button>
                </div>

                <div className="flex items-center justify-between min-h-[30px]">
                  <span className="text-[11px] text-slate-500 font-medium">{t.allowInLock}</span>
                  <input
                    type="checkbox"
                    checked={app.allowDuringLock}
                    onChange={(e) =>
                      updateAppStatus(app.packageName, app.isAllowed, e.target.checked)
                    }
                    className="w-3.5 h-3.5 accent-blue-600 rounded cursor-pointer aspect-square"
                  />
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
