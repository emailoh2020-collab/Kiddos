import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { translations } from '../../data/translations';
import { AppCategory, AppInfo, DayOfWeek, SmartBlockMode } from '../../types';
import {
  DAYS_OF_WEEK,
  WEEKDAYS,
  WEEKENDS,
  EVERY_DAY,
  getLocalDayOfWeek,
  timeStringToMinutes,
  minutesToTimeString,
} from '../../utils/smartBlockEngine';
import {
  Clock,
  Plus,
  Edit2,
  Trash2,
  Copy,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  Sparkles,
  ChevronRight,
  Shield,
  Layers,
  ArrowRight,
  X,
  Info,
  Sliders,
  Eye,
  Check,
} from 'lucide-react';
import { AppIcon } from '../common/AppIcon';

interface SmartBlockManagerProps {
  onNavigate?: (tab: string) => void;
}

const PRESET_TEMPLATES = [
  {
    name: 'School Time',
    icon: '🏫',
    description: 'Classroom focus. Social media, games, and entertainment locked.',
    startTime: '07:30',
    endTime: '14:00',
    activeDays: WEEKDAYS,
    blockedCategories: ['games', 'social', 'entertainment'] as AppCategory[],
    allowedCategories: ['educational', 'utilities'] as AppCategory[],
    priority: 3,
  },
  {
    name: 'Study Time',
    icon: '📚',
    description: 'Homework & study window. Educational and reference apps permitted.',
    startTime: '14:30',
    endTime: '16:30',
    activeDays: WEEKDAYS,
    blockedCategories: ['games', 'social', 'entertainment'] as AppCategory[],
    allowedCategories: ['educational', 'utilities'] as AppCategory[],
    priority: 4,
  },
  {
    name: 'Play Time',
    icon: '🎮',
    description: 'Recreation & gaming window for free play.',
    startTime: '16:30',
    endTime: '19:00',
    activeDays: EVERY_DAY,
    blockedCategories: ['social'] as AppCategory[],
    allowedCategories: ['games', 'educational', 'entertainment', 'utilities'] as AppCategory[],
    priority: 2,
  },
  {
    name: 'Family Time',
    icon: '🍽',
    description: 'Dinner and family evening connection. Device apps paused.',
    startTime: '19:00',
    endTime: '20:30',
    activeDays: EVERY_DAY,
    blockedCategories: ['games', 'social', 'entertainment', 'educational'] as AppCategory[],
    allowedCategories: ['utilities'] as AppCategory[],
    priority: 5,
  },
  {
    name: 'Bedtime',
    icon: '🌙',
    description: 'Wind-down and overnight sleep protection spanning midnight.',
    startTime: '20:30',
    endTime: '07:00',
    activeDays: EVERY_DAY,
    blockedCategories: ['games', 'social', 'entertainment', 'educational', 'utilities'] as AppCategory[],
    allowedCategories: [] as AppCategory[],
    priority: 6,
  },
  {
    name: 'Sleep Time',
    icon: '😴',
    description: 'Deep night lock. Device restricted until morning alarm.',
    startTime: '21:30',
    endTime: '06:30',
    activeDays: EVERY_DAY,
    blockedCategories: ['games', 'social', 'entertainment', 'educational', 'utilities'] as AppCategory[],
    allowedCategories: [] as AppCategory[],
    priority: 7,
  },
  {
    name: 'Travel Time',
    icon: '🚌',
    description: 'Commute and travel window. Audio and navigation apps allowed.',
    startTime: '06:45',
    endTime: '07:30',
    activeDays: WEEKDAYS,
    blockedCategories: ['games', 'social'] as AppCategory[],
    allowedCategories: ['entertainment', 'utilities', 'educational'] as AppCategory[],
    priority: 3,
  },
  {
    name: 'Weekend Schedule',
    icon: '🛌',
    description: 'Relaxed weekend schedule with extended recreational hours.',
    startTime: '10:00',
    endTime: '18:00',
    activeDays: WEEKENDS,
    blockedCategories: [] as AppCategory[],
    allowedCategories: ['games', 'educational', 'entertainment', 'utilities'] as AppCategory[],
    priority: 1,
  },
];

const EMOJI_OPTIONS = ['🏫', '📚', '🎮', '🍽', '🌙', '😴', '🚌', '🛌', '⚙', '🎨', '🧩', '🏊', '🚴', '📖', '⏰', '🛡'];
const ALL_CATEGORIES: AppCategory[] = ['games', 'social', 'entertainment', 'educational', 'utilities'];

export const SmartBlockManager: React.FC<SmartBlockManagerProps> = ({ onNavigate }) => {
  const {
    language,
    smartBlockModes,
    activeSmartBlockMode,
    isSmartBlockActiveNow,
    nextSmartBlockTransition,
    overlappingSchedules,
    createSmartBlockMode,
    updateSmartBlockMode,
    deleteSmartBlockMode,
    duplicateSmartBlockMode,
    toggleSmartBlockMode,
    apps,
  } = useApp();

  const t = translations[language] || translations.en;
  const currentDay = getLocalDayOfWeek();

  const [activeView, setActiveView] = useState<'rules' | 'timeline' | 'weekly'>('rules');
  const [selectedTimelineDay, setSelectedTimelineDay] = useState<DayOfWeek>(currentDay);
  const [editingMode, setEditingMode] = useState<SmartBlockMode | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);

  // Form State for Modal
  const [formName, setFormName] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formIcon, setFormIcon] = useState('📚');
  const [formStartTime, setFormStartTime] = useState('08:00');
  const [formEndTime, setFormEndTime] = useState('15:00');
  const [formActiveDays, setFormActiveDays] = useState<DayOfWeek[]>(WEEKDAYS);
  const [formBlockedCategories, setFormBlockedCategories] = useState<AppCategory[]>(['games', 'social', 'entertainment']);
  const [formAllowedCategories, setFormAllowedCategories] = useState<AppCategory[]>(['educational', 'utilities']);
  const [formBlockedApps, setFormBlockedApps] = useState<string[]>([]);
  const [formAllowedApps, setFormAllowedApps] = useState<string[]>([]);
  const [formExceptions, setFormExceptions] = useState<string[]>([]);
  const [formPriority, setFormPriority] = useState<number>(3);
  const [formEnabled, setFormEnabled] = useState(true);

  const openCreateModal = (presetTemplate?: (typeof PRESET_TEMPLATES)[0]) => {
    if (presetTemplate) {
      setFormName(presetTemplate.name);
      setFormDescription(presetTemplate.description);
      setFormIcon(presetTemplate.icon);
      setFormStartTime(presetTemplate.startTime);
      setFormEndTime(presetTemplate.endTime);
      setFormActiveDays(presetTemplate.activeDays);
      setFormBlockedCategories(presetTemplate.blockedCategories);
      setFormAllowedCategories(presetTemplate.allowedCategories);
      setFormPriority(presetTemplate.priority);
      setFormBlockedApps([]);
      setFormAllowedApps([]);
      setFormExceptions([]);
      setFormEnabled(true);
    } else {
      setFormName('Custom Schedule');
      setFormDescription('Custom time-based restriction period.');
      setFormIcon('⚙');
      setFormStartTime('09:00');
      setFormEndTime('12:00');
      setFormActiveDays(WEEKDAYS);
      setFormBlockedCategories(['games', 'social']);
      setFormAllowedCategories(['educational', 'utilities']);
      setFormPriority(3);
      setFormBlockedApps([]);
      setFormAllowedApps([]);
      setFormExceptions([]);
      setFormEnabled(true);
    }
    setEditingMode(null);
    setIsCreating(true);
  };

  const openEditModal = (mode: SmartBlockMode) => {
    setEditingMode(mode);
    setFormName(mode.name);
    setFormDescription(mode.description || '');
    setFormIcon(mode.icon || '📚');
    setFormStartTime(mode.startTime);
    setFormEndTime(mode.endTime);
    setFormActiveDays(mode.activeDays || WEEKDAYS);
    setFormBlockedCategories(mode.blockedCategories || []);
    setFormAllowedCategories(mode.allowedCategories || []);
    setFormBlockedApps(mode.blockedApps || []);
    setFormAllowedApps(mode.allowedApps || []);
    setFormExceptions(mode.exceptions || []);
    setFormPriority(mode.priority || 3);
    setFormEnabled(mode.enabled ?? true);
    setIsCreating(false);
  };

  const handleSaveForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) return;

    if (editingMode) {
      updateSmartBlockMode({
        ...editingMode,
        name: formName.trim(),
        description: formDescription.trim(),
        icon: formIcon,
        startTime: formStartTime,
        endTime: formEndTime,
        activeDays: formActiveDays,
        blockedCategories: formBlockedCategories,
        allowedCategories: formAllowedCategories,
        blockedApps: formBlockedApps,
        allowedApps: formAllowedApps,
        exceptions: formExceptions,
        priority: formPriority,
        enabled: formEnabled,
      });
      setEditingMode(null);
    } else {
      createSmartBlockMode({
        name: formName.trim(),
        description: formDescription.trim(),
        icon: formIcon,
        startTime: formStartTime,
        endTime: formEndTime,
        activeDays: formActiveDays,
        blockedCategories: formBlockedCategories,
        allowedCategories: formAllowedCategories,
        blockedApps: formBlockedApps,
        allowedApps: formAllowedApps,
        exceptions: formExceptions,
        priority: formPriority,
        enabled: formEnabled,
      });
      setIsCreating(false);
    }
  };

  const isOvernight = timeStringToMinutes(formStartTime) > timeStringToMinutes(formEndTime);

  // Toggle day in active days array
  const toggleDay = (day: DayOfWeek) => {
    if (formActiveDays.includes(day)) {
      if (formActiveDays.length > 1) {
        setFormActiveDays(formActiveDays.filter((d) => d !== day));
      }
    } else {
      setFormActiveDays([...formActiveDays, day]);
    }
  };

  // Toggle blocked category
  const toggleBlockedCategory = (cat: AppCategory) => {
    if (formBlockedCategories.includes(cat)) {
      setFormBlockedCategories(formBlockedCategories.filter((c) => c !== cat));
    } else {
      setFormBlockedCategories([...formBlockedCategories, cat]);
      // Remove from allowed if present
      setFormAllowedCategories(formAllowedCategories.filter((c) => c !== cat));
    }
  };

  // Toggle allowed category
  const toggleAllowedCategory = (cat: AppCategory) => {
    if (formAllowedCategories.includes(cat)) {
      setFormAllowedCategories(formAllowedCategories.filter((c) => c !== cat));
    } else {
      setFormAllowedCategories([...formAllowedCategories, cat]);
      // Remove from blocked if present
      setFormBlockedCategories(formBlockedCategories.filter((c) => c !== cat));
    }
  };

  // Toggle app exception
  const toggleAppException = (pkg: string) => {
    if (formExceptions.includes(pkg)) {
      setFormExceptions(formExceptions.filter((p) => p !== pkg));
    } else {
      setFormExceptions([...formExceptions, pkg]);
    }
  };

  // Toggle blocked app
  const toggleBlockedApp = (pkg: string) => {
    if (formBlockedApps.includes(pkg)) {
      setFormBlockedApps(formBlockedApps.filter((p) => p !== pkg));
    } else {
      setFormBlockedApps([...formBlockedApps, pkg]);
    }
  };

  const enabledCount = smartBlockModes.filter((m) => m.enabled).length;

  return (
    <div className="space-y-4">
      {/* Header Banner & Live Active Mode Status */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-2xl p-4 sm:p-5 border border-indigo-900/60 shadow-xs relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/30 text-indigo-300 text-[10px] font-black uppercase tracking-wider border border-indigo-400/30">
                Smart Block 2.0 Engine
              </span>
              <span className="text-[11px] font-bold text-slate-300">
                {enabledCount} {t.activeRulesCount || 'Active Schedules'}
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-black tracking-tight text-white flex items-center gap-2">
              <span>{t.smartBlockModesTitle || 'Smart Block Schedules'}</span>
            </h2>
            <p className="text-xs text-slate-300 max-w-xl">
              Automated, multi-schedule restriction engine operating according to local date and time. Operates independently from daily screen time allowances.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2.5 shrink-0">
            {/* Active Status Badge */}
            <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-2.5 px-3.5 flex items-center gap-2.5">
              <div className="text-2xl">{activeSmartBlockMode ? activeSmartBlockMode.icon : '✨'}</div>
              <div>
                <div className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">
                  Current Status
                </div>
                <div className="text-xs font-black text-white">
                  {activeSmartBlockMode ? (
                    <span className="text-amber-300 flex items-center gap-1">
                      {activeSmartBlockMode.name} (Active)
                    </span>
                  ) : (
                    <span className="text-emerald-300 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> No Active Rule
                    </span>
                  )}
                </div>
                {nextSmartBlockTransition && (
                  <div className="text-[10px] text-slate-300 mt-0.5">
                    {nextSmartBlockTransition.isEndingCurrent
                      ? `Ends at ${nextSmartBlockTransition.transitionTime}`
                      : `Next: ${nextSmartBlockTransition.nextMode?.name || 'Rule'} at ${nextSmartBlockTransition.transitionTime}`}
                  </div>
                )}
              </div>
            </div>

            <button
              onClick={() => openCreateModal()}
              className="px-3.5 py-2.5 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white text-xs font-black rounded-xl shadow-xs transition flex items-center gap-1.5 shrink-0 min-h-[40px]"
            >
              <Plus className="w-4 h-4" />
              <span>{t.createSmartBlockRule || 'New Schedule Rule'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Overlapping Schedule Banner (if any) */}
      {overlappingSchedules.length > 0 && (
        <div className="bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/50 rounded-2xl p-3.5 sm:p-4 text-amber-900 dark:text-amber-200">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <div className="min-w-0 flex-1">
              <h4 className="text-xs sm:text-sm font-extrabold flex items-center gap-1.5">
                {t.overlapWarning || 'Schedule Overlap Detected'} ({overlappingSchedules.length})
              </h4>
              <p className="text-[11px] text-amber-800 dark:text-amber-300 mt-0.5">
                Some enabled rules share overlapping time windows. The rule with the <span className="font-black underline">higher priority</span> automatically takes precedence during overlapping intervals.
              </p>
              <div className="mt-2 space-y-1">
                {overlappingSchedules.map((ov, idx) => (
                  <div
                    key={idx}
                    className="text-[11px] font-medium bg-amber-100/70 dark:bg-amber-900/40 px-2.5 py-1 rounded-lg flex items-center justify-between flex-wrap gap-1"
                  >
                    <span>
                      {ov.modeA.icon} <strong>{ov.modeA.name}</strong> (Priority {ov.modeA.priority}) overlaps with{' '}
                      {ov.modeB.icon} <strong>{ov.modeB.name}</strong> (Priority {ov.modeB.priority})
                    </span>
                    <span className="text-[10px] font-bold text-amber-700 dark:text-amber-400">
                      Precedence:{' '}
                      {ov.modeA.priority >= ov.modeB.priority ? ov.modeA.name : ov.modeB.name} wins
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* View Switcher Tabs */}
      <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-2.5 flex-wrap gap-2">
        <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
          <button
            onClick={() => setActiveView('rules')}
            className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition flex items-center gap-1.5 ${
              activeView === 'rules'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-2xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Rules & Cards ({smartBlockModes.length})</span>
          </button>
          <button
            onClick={() => setActiveView('timeline')}
            className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition flex items-center gap-1.5 ${
              activeView === 'timeline'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-2xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>{t.timelineSchedule || '24-Hour Timeline'}</span>
          </button>
          <button
            onClick={() => setActiveView('weekly')}
            className={`px-3 py-1.5 rounded-lg text-xs font-extrabold transition flex items-center gap-1.5 ${
              activeView === 'weekly'
                ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-2xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>{t.weeklyScheduleView || 'Weekly Matrix'}</span>
          </button>
        </div>

        {/* Quick Presets Dropdown / Buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto py-1 max-w-full">
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider shrink-0">Quick Add:</span>
          {PRESET_TEMPLATES.slice(0, 4).map((p, idx) => (
            <button
              key={idx}
              onClick={() => openCreateModal(p)}
              className="px-2 py-1 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-[11px] font-bold rounded-lg transition shrink-0 flex items-center gap-1"
            >
              <span>{p.icon}</span>
              <span>{p.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* VIEW 1: RULES & CARDS */}
      {activeView === 'rules' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {smartBlockModes.map((mode) => {
            const isActive = activeSmartBlockMode?.id === mode.id;
            const crossesMidnight = timeStringToMinutes(mode.startTime) > timeStringToMinutes(mode.endTime);

            return (
              <div
                key={mode.id}
                className={`bg-white dark:bg-slate-900 rounded-2xl border transition-all relative overflow-hidden p-3.5 sm:p-4.5 ${
                  isActive
                    ? 'border-amber-400 dark:border-amber-500 shadow-md ring-2 ring-amber-400/20'
                    : mode.enabled
                    ? 'border-slate-200 dark:border-slate-800 hover:border-indigo-300'
                    : 'border-slate-200/60 dark:border-slate-800/60 opacity-60 bg-slate-50/50'
                }`}
              >
                {isActive && (
                  <div className="absolute top-0 right-0 bg-amber-500 text-slate-950 font-black text-[9px] uppercase tracking-wider px-2 py-0.5 rounded-bl-lg flex items-center gap-1 shadow-2xs">
                    <Sparkles className="w-3 h-3" /> Active Now
                  </div>
                )}

                <div className="flex items-start justify-between gap-2.5 pb-2.5 border-b border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-100 dark:border-indigo-900/50 flex items-center justify-center text-xl shrink-0">
                      {mode.icon || '📚'}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-sm font-extrabold text-slate-900 dark:text-white truncate">
                          {mode.name}
                        </h3>
                        <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                          Priority {mode.priority || 1}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 font-medium truncate mt-0.5">
                        {mode.description || 'Custom time-based restriction'}
                      </p>
                    </div>
                  </div>

                  {/* Enable Toggle */}
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => toggleSmartBlockMode(mode.id, !mode.enabled)}
                      className={`w-10 h-5.5 flex items-center rounded-full p-0.5 transition-colors duration-200 ${
                        mode.enabled ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-700'
                      }`}
                    >
                      <div
                        className={`bg-white w-4.5 h-4.5 rounded-full shadow-md transform transition-transform duration-200 aspect-square ${
                          mode.enabled ? (language === 'ar' ? '-translate-x-4.5' : 'translate-x-4.5') : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>
                </div>

                {/* Time & Days Details */}
                <div className="py-2.5 space-y-2 text-xs">
                  <div className="flex items-center justify-between text-slate-700 dark:text-slate-300">
                    <div className="flex items-center gap-1.5 font-mono font-bold text-slate-900 dark:text-white text-xs">
                      <Clock className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                      <span>
                        {mode.startTime} — {mode.endTime}
                      </span>
                      {crossesMidnight && (
                        <span className="text-[9px] font-sans font-bold px-1.5 py-0.2 rounded bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300">
                          Overnight
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-500 font-medium">
                      {mode.activeDays.length === 7
                        ? 'Everyday'
                        : mode.activeDays.length === 5 && mode.activeDays.every((d) => WEEKDAYS.includes(d))
                        ? 'Weekdays'
                        : `${mode.activeDays.length} days / week`}
                    </div>
                  </div>

                  {/* Days of Week Chips */}
                  <div className="flex items-center gap-1">
                    {DAYS_OF_WEEK.map((d) => {
                      const isActiveDay = mode.activeDays.includes(d);
                      return (
                        <span
                          key={d}
                          className={`w-5.5 h-5.5 rounded text-[9px] font-bold flex items-center justify-center uppercase ${
                            isActiveDay
                              ? 'bg-indigo-600 text-white shadow-2xs'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
                          }`}
                        >
                          {d.substring(0, 1)}
                        </span>
                      );
                    })}
                  </div>

                  {/* Category Restrictions summary */}
                  <div className="space-y-1 pt-1">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Blocked:</span>
                      {mode.blockedCategories.length > 0 ? (
                        mode.blockedCategories.map((cat) => (
                          <span
                            key={cat}
                            className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-red-50 dark:bg-red-950/60 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-900/40"
                          >
                            {cat}
                          </span>
                        ))
                      ) : (
                        <span className="text-[10px] text-slate-400 font-medium">None</span>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Allowed:</span>
                      {mode.allowedCategories.length > 0 ? (
                        mode.allowedCategories.map((cat) => (
                          <span
                            key={cat}
                            className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-900/40"
                          >
                            {cat}
                          </span>
                        ))
                      ) : (
                        <span className="text-[10px] text-slate-400 font-medium">None</span>
                      )}
                    </div>

                    {mode.exceptions && mode.exceptions.length > 0 && (
                      <div className="text-[10px] text-indigo-600 dark:text-indigo-400 font-medium">
                        ✨ {mode.exceptions.length} App Exception(s) exempted from category lock
                      </div>
                    )}
                  </div>
                </div>

                {/* Card Actions Footer */}
                <div className="mt-2 pt-2.5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-1">
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => openEditModal(mode)}
                      className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 hover:text-indigo-600 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-lg transition flex items-center gap-1 min-h-[30px]"
                    >
                      <Edit2 className="w-3 h-3" />
                      <span>{t.edit}</span>
                    </button>
                    <button
                      onClick={() => duplicateSmartBlockMode(mode.id)}
                      className="p-1.5 text-slate-500 hover:text-slate-900 dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                      title={t.duplicateSmartBlockRule || 'Duplicate Rule'}
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <button
                    onClick={() => setShowDeleteConfirm(mode.id)}
                    className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/40 transition"
                    title={t.delete}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* VIEW 2: 24-HOUR TIMELINE VISUALIZER */}
      {activeView === 'timeline' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 sm:p-5 space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-indigo-500" />
                <span>24-Hour Schedule Timeline</span>
              </h3>
              <p className="text-xs text-slate-500">
                Visual representation of all active time rules throughout the day.
              </p>
            </div>

            {/* Day Selector for Timeline */}
            <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
              {DAYS_OF_WEEK.map((day) => (
                <button
                  key={day}
                  onClick={() => setSelectedTimelineDay(day)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold uppercase transition ${
                    selectedTimelineDay === day
                      ? 'bg-indigo-600 text-white shadow-2xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  {day.substring(0, 3)}
                </button>
              ))}
            </div>
          </div>

          {/* Timeline Bar (00:00 to 24:00) */}
          <div className="space-y-2 pt-2">
            {/* Hour Markers */}
            <div className="grid grid-cols-12 text-[10px] font-mono text-slate-400 text-center">
              <span>00:00</span>
              <span>02:00</span>
              <span>04:00</span>
              <span>06:00</span>
              <span>08:00</span>
              <span>10:00</span>
              <span>12:00</span>
              <span>14:00</span>
              <span>16:00</span>
              <span>18:00</span>
              <span>20:00</span>
              <span>22:00</span>
            </div>

            {/* Visual Bar Canvas */}
            <div className="relative h-14 bg-slate-100 dark:bg-slate-800 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 flex items-center">
              {/* Render Blocks for Enabled Modes on Selected Day */}
              {smartBlockModes
                .filter((m) => m.enabled && m.activeDays.includes(selectedTimelineDay))
                .sort((a, b) => a.priority - b.priority)
                .map((mode) => {
                  const startMin = timeStringToMinutes(mode.startTime);
                  const endMin = timeStringToMinutes(mode.endTime);
                  const isOver = startMin > endMin;

                  const leftPct = (startMin / 1440) * 100;
                  const widthPct = isOver ? ((1440 - startMin) / 1440) * 100 : ((endMin - startMin) / 1440) * 100;

                  return (
                    <div
                      key={mode.id}
                      className="absolute top-1 bottom-1 rounded-lg bg-indigo-600 text-white px-2 flex items-center justify-between text-[11px] font-bold overflow-hidden shadow-xs border border-indigo-400/40"
                      style={{
                        left: `${leftPct}%`,
                        width: `${Math.max(widthPct, 4)}%`,
                      }}
                      title={`${mode.name} (${mode.startTime} - ${mode.endTime})`}
                    >
                      <span className="truncate flex items-center gap-1">
                        <span>{mode.icon}</span>
                        <span className="hidden sm:inline">{mode.name}</span>
                      </span>
                      <span className="text-[9px] font-mono opacity-80 shrink-0">{mode.startTime}</span>
                    </div>
                  );
                })}

              {/* Current Time Indicator Marker (if selected day is today) */}
              {selectedTimelineDay === currentDay && (
                <div
                  className="absolute top-0 bottom-0 w-1 bg-red-500 z-20 shadow-md"
                  style={{
                    left: `${((new Date().getHours() * 60 + new Date().getMinutes()) / 1440) * 100}%`,
                  }}
                  title="Current Local Time"
                >
                  <div className="w-3 h-3 bg-red-500 rounded-full -top-1 -left-1 absolute" />
                </div>
              )}
            </div>

            <div className="flex items-center justify-between text-xs text-slate-500 font-medium pt-1">
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded bg-indigo-600 inline-block" /> Scheduled Rule Window
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 rounded bg-red-500 inline-block" /> Current Time Marker
                </span>
              </div>
              <span>Local Device Time</span>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 3: WEEKLY SCHEDULE MATRIX */}
      {activeView === 'weekly' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 sm:p-5 space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div>
              <h3 className="text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-indigo-500" />
                <span>Weekly Schedule Matrix</span>
              </h3>
              <p className="text-xs text-slate-500">
                All 7 days with active Smart Block rules assigned.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-7 gap-2.5">
            {DAYS_OF_WEEK.map((day) => {
              const isToday = day === currentDay;
              const dayModes = smartBlockModes.filter((m) => m.enabled && m.activeDays.includes(day));

              return (
                <div
                  key={day}
                  className={`rounded-xl p-3 border transition ${
                    isToday
                      ? 'bg-indigo-50/70 dark:bg-indigo-950/40 border-indigo-300 dark:border-indigo-800 shadow-2xs'
                      : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700/60'
                  }`}
                >
                  <div className="flex items-center justify-between pb-2 border-b border-slate-200/60 dark:border-slate-700/60 mb-2">
                    <span className="text-xs font-black uppercase text-slate-900 dark:text-white">{day.substring(0, 3)}</span>
                    {isToday && (
                      <span className="text-[9px] font-extrabold px-1.5 py-0.2 rounded bg-indigo-600 text-white">
                        Today
                      </span>
                    )}
                  </div>

                  <div className="space-y-1.5">
                    {dayModes.length > 0 ? (
                      dayModes.map((m) => (
                        <div
                          key={m.id}
                          className="p-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-[11px] shadow-2xs"
                        >
                          <div className="font-extrabold text-slate-900 dark:text-white flex items-center gap-1 truncate">
                            <span>{m.icon}</span>
                            <span className="truncate">{m.name}</span>
                          </div>
                          <div className="text-[10px] font-mono text-slate-500 mt-0.5">
                            {m.startTime} - {m.endTime}
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-[11px] text-slate-400 italic text-center py-2">No Rules</div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* CREATE / EDIT RULE MODAL */}
      {(isCreating || editingMode) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 max-w-2xl w-full p-4 sm:p-6 shadow-2xl space-y-4 my-8 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950 flex items-center justify-center text-2xl border border-indigo-100 dark:border-indigo-900">
                  {formIcon}
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900 dark:text-white">
                    {editingMode ? (t.editSmartBlockRule || 'Edit Smart Block Rule') : (t.createSmartBlockRule || 'Create Smart Block Rule')}
                  </h3>
                  <p className="text-xs text-slate-500">Configure schedule time windows, app categories, and priority</p>
                </div>
              </div>
              <button
                onClick={() => {
                  setIsCreating(false);
                  setEditingMode(null);
                }}
                className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveForm} className="space-y-4 text-xs">
              {/* Rule Name & Icon Picker */}
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <div className="sm:col-span-3">
                  <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Rule Name
                  </label>
                  <input
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="e.g. School Time, Study Time, Bedtime"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Icon Emoji
                  </label>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {EMOJI_OPTIONS.slice(0, 8).map((em) => (
                      <button
                        type="button"
                        key={em}
                        onClick={() => setFormIcon(em)}
                        className={`w-7 h-7 rounded-lg text-base flex items-center justify-center transition ${
                          formIcon === em
                            ? 'bg-indigo-600 text-white shadow-2xs'
                            : 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200'
                        }`}
                      >
                        {em}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Description / Purpose
                </label>
                <input
                  type="text"
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="e.g. Classroom hours. Games and social media restricted."
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              {/* Time Window (Start Time & End Time) */}
              <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-extrabold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-indigo-500" /> Time Window
                  </span>
                  {isOvernight && (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800">
                      🌙 Overnight Schedule (Crosses midnight to next morning)
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 mb-1">START TIME</label>
                    <input
                      type="time"
                      required
                      value={formStartTime}
                      onChange={(e) => setFormStartTime(e.target.value)}
                      className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-mono font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 mb-1">END TIME</label>
                    <input
                      type="time"
                      required
                      value={formEndTime}
                      onChange={(e) => setFormEndTime(e.target.value)}
                      className="w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white font-mono font-bold"
                    />
                  </div>
                </div>
              </div>

              {/* Active Days */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300">
                    Active Days
                  </label>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => setFormActiveDays(WEEKDAYS)}
                      className="px-2 py-0.5 text-[10px] font-bold bg-slate-100 dark:bg-slate-800 rounded hover:bg-slate-200"
                    >
                      Weekdays
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormActiveDays(WEEKENDS)}
                      className="px-2 py-0.5 text-[10px] font-bold bg-slate-100 dark:bg-slate-800 rounded hover:bg-slate-200"
                    >
                      Weekends
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormActiveDays(EVERY_DAY)}
                      className="px-2 py-0.5 text-[10px] font-bold bg-slate-100 dark:bg-slate-800 rounded hover:bg-slate-200"
                    >
                      All 7 Days
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-7 gap-1.5">
                  {DAYS_OF_WEEK.map((d) => {
                    const isSelected = formActiveDays.includes(d);
                    return (
                      <button
                        type="button"
                        key={d}
                        onClick={() => toggleDay(d)}
                        className={`py-2 rounded-xl text-[11px] font-extrabold uppercase transition ${
                          isSelected
                            ? 'bg-indigo-600 text-white shadow-2xs'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-400 hover:bg-slate-200'
                        }`}
                      >
                        {d.substring(0, 3)}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Category Restrictions */}
              <div className="space-y-2">
                <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300">
                  Category Restrictions (Tap to toggle)
                </label>

                <div className="space-y-1.5">
                  <div className="text-[10px] font-bold text-red-600 dark:text-red-400 uppercase tracking-wider">
                    🚫 Blocked Categories (Cannot be launched during this rule)
                  </div>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {ALL_CATEGORIES.map((cat) => {
                      const isBlocked = formBlockedCategories.includes(cat);
                      return (
                        <button
                          type="button"
                          key={cat}
                          onClick={() => toggleBlockedCategory(cat)}
                          className={`px-2.5 py-1 rounded-xl text-xs font-bold transition flex items-center gap-1 ${
                            isBlocked
                              ? 'bg-red-600 text-white shadow-2xs'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          {isBlocked && <Check className="w-3 h-3" />}
                          <span className="capitalize">{cat}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="space-y-1.5 pt-1">
                  <div className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
                    ✅ Allowed Categories (Permitted to launch)
                  </div>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {ALL_CATEGORIES.map((cat) => {
                      const isAllowed = formAllowedCategories.includes(cat);
                      return (
                        <button
                          type="button"
                          key={cat}
                          onClick={() => toggleAllowedCategory(cat)}
                          className={`px-2.5 py-1 rounded-xl text-xs font-bold transition flex items-center gap-1 ${
                            isAllowed
                              ? 'bg-emerald-600 text-white shadow-2xs'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          {isAllowed && <Check className="w-3 h-3" />}
                          <span className="capitalize">{cat}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Priority Slider */}
              <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="text-[11px] font-extrabold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1">
                    <Sliders className="w-3.5 h-3.5 text-indigo-500" /> {t.priorityLevel || 'Rule Priority'}: {formPriority}
                  </label>
                  <span className="text-[10px] font-bold text-slate-500">Scale: 1 (Lowest) to 10 (Highest)</span>
                </div>
                <input
                  type="range"
                  min={1}
                  max={10}
                  step={1}
                  value={formPriority}
                  onChange={(e) => setFormPriority(Number(e.target.value))}
                  className="w-full accent-indigo-600 cursor-pointer"
                />
                <p className="text-[10px] text-slate-500">
                  {t.priorityExplanation || 'Higher priority rules automatically take precedence when time periods overlap.'}
                </p>
              </div>

              {/* Specific App Exceptions */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Exempt Specific Apps from Category Block (Exceptions)
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 max-h-36 overflow-y-auto p-1.5 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
                  {apps.map((app) => {
                    const isExempt = formExceptions.includes(app.packageName);
                    return (
                      <button
                        type="button"
                        key={app.packageName}
                        onClick={() => toggleAppException(app.packageName)}
                        className={`p-1.5 rounded-lg text-left rtl:text-right transition flex items-center gap-1.5 ${
                          isExempt
                            ? 'bg-indigo-600 text-white shadow-2xs'
                            : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        <AppIcon icon={app.icon} size="xs" shape="rounded" />
                        <span className="truncate text-[11px] font-bold">{app.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Modal Buttons */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsCreating(false);
                    setEditingMode(null);
                  }}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold rounded-xl hover:bg-slate-200 transition min-h-[38px]"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white font-black rounded-xl shadow-xs transition flex items-center gap-1.5 min-h-[38px]"
                >
                  <Check className="w-4 h-4" />
                  <span>{editingMode ? t.save : t.confirm}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION DIALOG */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 max-w-md w-full p-5 shadow-2xl space-y-3">
            <div className="flex items-center gap-3 text-red-600">
              <div className="w-10 h-10 rounded-full bg-red-100 dark:bg-red-950/60 flex items-center justify-center">
                <Trash2 className="w-5 h-5" />
              </div>
              <h3 className="text-base font-black text-slate-900 dark:text-white">Delete Schedule Rule?</h3>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300">
              Are you sure you want to delete this Smart Block mode? This schedule will no longer activate.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowDeleteConfirm(null)}
                className="px-3.5 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl hover:bg-slate-200 transition"
              >
                {t.cancel}
              </button>
              <button
                onClick={() => {
                  deleteSmartBlockMode(showDeleteConfirm);
                  setShowDeleteConfirm(null);
                }}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-black text-xs rounded-xl shadow-xs transition"
              >
                {t.delete}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
