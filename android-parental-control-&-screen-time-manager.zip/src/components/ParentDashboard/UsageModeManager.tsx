import React, { useState, useMemo } from 'react';
import { AppInfo, UsageMode } from '../../types';
import { useApp } from '../../context/AppContext';
import { translations } from '../../data/translations';
import { AppIcon } from '../common/AppIcon';
import { Plus, Edit2, Trash2, X, Check, Save } from 'lucide-react';

export const UsageModeManager: React.FC = () => {
  const { settings, updateSettings, language, apps, activeChildId, session, setActiveUsageMode, setActiveTab } = useApp();
  const t = translations[language];
  const [isEditing, setIsEditing] = useState(false);
  const [editingMode, setEditingMode] = useState<UsageMode | null>(null);

  const usageModes = settings?.usageModes || [];

  const handleEdit = (mode: UsageMode) => {
    setEditingMode({ ...mode, allowedApps: [...mode.allowedApps] });
    setIsEditing(true);
  };

  const handleCreate = () => {
    const newMode: UsageMode = {
      id: `mode_${Date.now()}`,
      name: '',
      description: '',
      icon: '🌟',
      isBuiltIn: false,
      allowedApps: [],
    };
    setEditingMode(newMode);
    setIsEditing(true);
  };

  const handleSave = () => {
    if (!editingMode) return;
    
    // Normal mode doesn't explicitly store apps
    if (editingMode.id === 'normal') {
      editingMode.allowedApps = [];
    }

    let newModes: UsageMode[];
    if (usageModes.find(m => m.id === editingMode.id)) {
      newModes = usageModes.map(m => m.id === editingMode.id ? editingMode : m);
    } else {
      newModes = [...usageModes, editingMode];
    }
    updateSettings({ ...settings, usageModes: newModes });
    setIsEditing(false);
    setEditingMode(null);
  };

  const handleDelete = (id: string) => {
    if (usageModes.find(m => m.id === id)?.isBuiltIn) return;
    const newModes = usageModes.filter(m => m.id !== id);
    updateSettings({ ...settings, usageModes: newModes });
  };

  const toggleApp = (packageName: string) => {
    if (!editingMode || editingMode.id === 'normal') return; // Cannot toggle apps in normal mode from here
    
    setEditingMode(prev => {
      if (!prev) return prev;
      const isCurrentlyAllowed = prev.allowedApps.includes(packageName);
      return {
        ...prev,
        allowedApps: isCurrentlyAllowed
          ? prev.allowedApps.filter(p => p !== packageName)
          : [...prev.allowedApps, packageName]
      };
    });
  };

  if (isEditing && editingMode) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center">
          <h3 className="font-semibold text-slate-800">
            {editingMode.id.startsWith('mode_') ? t.createUsageMode : t.editUsageMode}
          </h3>
          <button onClick={() => setIsEditing(false)} className="p-2 hover:bg-slate-200 rounded-full text-slate-500">
            <X size={20} />
          </button>
        </div>
        
        <div className="p-4 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">{t.modeName}</label>
              <input 
                type="text" 
                value={editingMode.name}
                onChange={e => setEditingMode({...editingMode, name: e.target.value})}
                disabled={editingMode.isBuiltIn}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-slate-100 disabled:text-slate-500"
                placeholder={t.modeName}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">{t.modeIcon}</label>
              <input 
                type="text" 
                value={editingMode.icon}
                onChange={e => setEditingMode({...editingMode, icon: e.target.value})}
                disabled={editingMode.isBuiltIn}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-slate-100 disabled:text-slate-500"
                maxLength={2}
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-700 mb-1">{t.modeDescription}</label>
              <input 
                type="text" 
                value={editingMode.description}
                onChange={e => setEditingMode({...editingMode, description: e.target.value})}
                disabled={editingMode.isBuiltIn}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-slate-100 disabled:text-slate-500"
              />
            </div>
          </div>

          {editingMode.id !== 'normal' && (
            <div className="mt-6">
              <h4 className="font-medium text-slate-800 mb-2">{t.allowedAppsInMode}</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 max-h-60 overflow-y-auto p-2 border border-slate-200 rounded-lg bg-slate-50">
                {apps.map(app => {
                  const isSelected = editingMode.allowedApps.includes(app.packageName);
                  return (
                    <div 
                      key={app.packageName}
                      onClick={() => toggleApp(app.packageName)}
                      className={`flex items-center p-2 rounded-lg cursor-pointer transition-colors border ${
                        isSelected ? "bg-blue-50 border-blue-200" : "bg-white border-transparent hover:bg-slate-100"
                      }`}
                    >
                      <AppIcon
                        icon={app.icon}
                        size="sm"
                        colorScheme={isSelected ? 'blue' : 'slate'}
                        shape="rounded"
                        className="mr-3 rtl:mr-0 rtl:ml-3"
                      />
                      <div className="flex-1 truncate">
                        <div className="text-sm font-medium text-slate-800 truncate">{app.appName}</div>
                      </div>
                      <div className={`w-5 h-5 rounded flex items-center justify-center border ${
                        isSelected ? "bg-blue-500 border-blue-500 text-white" : "border-slate-300 bg-white"
                      }`}>
                        {isSelected && <Check size={14} />}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          <div className="pt-4 flex justify-end">
            <button
              onClick={handleSave}
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Save size={18} className="mr-2" />
              Save Mode
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl shadow-xs border border-slate-200 dark:border-slate-800 overflow-hidden">
      <div className="p-3.5 sm:p-4 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center">
        <div>
          <h2 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white">{t.usageModeTitle}</h2>
          <p className="text-[11px] text-slate-500 font-medium">Configure allowed apps for different usage contexts.</p>
        </div>
        <button
          onClick={handleCreate}
          className="flex items-center px-3 py-1.5 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors text-xs font-bold shadow-2xs min-h-[34px]"
        >
          <Plus size={14} className="mr-1" />
          {t.createUsageMode}
        </button>
      </div>

      <div className="p-3.5 sm:p-4 grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-3.5">
        {usageModes.map(mode => (
          <div 
            key={mode.id} 
            className={`border rounded-2xl p-3 sm:p-3.5 flex flex-col justify-between transition-colors bg-white dark:bg-slate-900 shadow-2xs ${
              session.activeUsageModeId === mode.id 
                ? "border-emerald-400 ring-1 ring-emerald-400 bg-emerald-50/10 dark:bg-emerald-950/20" 
                : "border-slate-200 dark:border-slate-800 hover:border-blue-300"
            }`}
          >
            <div>
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center">
                  <div className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-lg mr-2.5 shrink-0 aspect-square">
                    {mode.icon}
                  </div>
                  <div>
                    <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">{mode.name}</h3>
                    <p className="text-[10px] text-slate-500 line-clamp-1">{mode.description}</p>
                  </div>
                </div>
                <div className="flex space-x-1">
                  <button 
                    onClick={() => handleEdit(mode)}
                    className="p-1 text-slate-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-slate-800 rounded-lg transition"
                  >
                    <Edit2 size={14} />
                  </button>
                  {!mode.isBuiltIn && (
                    <button 
                      onClick={() => handleDelete(mode.id)}
                      className="p-1 text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-slate-800 rounded-lg transition"
                    >
                      <Trash2 size={14} />
                    </button>
                  )}
                </div>
              </div>
            </div>

            <div className="mt-2.5 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <span className="text-[10px] font-medium text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-md">
                {mode.id === 'normal' ? 'Default restrictions' : `${mode.allowedApps.length} Apps Allowed`}
              </span>
              <div className="flex space-x-1.5 items-center">
                {mode.isBuiltIn && (
                  <span className="text-[9px] uppercase tracking-wider font-bold text-blue-600 bg-blue-50 dark:bg-blue-950/40 dark:text-blue-300 px-1.5 py-0.5 rounded flex items-center">
                    System
                  </span>
                )}
                {session.activeUsageModeId === mode.id ? (
                  <span className="text-[9px] uppercase tracking-wider font-bold text-emerald-700 bg-emerald-100 dark:bg-emerald-950/40 dark:text-emerald-300 px-2 py-0.5 rounded flex items-center border border-emerald-300">
                    Active
                  </span>
                ) : (
                  <button
                    onClick={() => {
                      setActiveUsageMode(mode.id);
                      setActiveTab('overview');
                    }}
                    className="text-[9px] uppercase tracking-wider font-bold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-blue-100 dark:hover:bg-slate-700 hover:text-blue-700 px-2 py-0.5 rounded transition-colors"
                  >
                    Activate
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
