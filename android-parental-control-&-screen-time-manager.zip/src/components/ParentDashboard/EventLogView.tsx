import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { EventLogItem, EventType } from '../../types';
import { translations } from '../../data/translations';
import { getStoredEventLogs } from '../../utils/storage';
import { useResponsiveLayout } from '../../utils/useResponsiveLayout';
import { AppIcon } from '../common/AppIcon';
import {
  ListOrdered,
  Search,
  Clock,
  ShieldAlert,
  CheckCircle,
  AlertTriangle,
  RotateCcw,
  Sparkles,
} from 'lucide-react';

export const EventLogView: React.FC = () => {
  const { language } = useApp();
  const t = translations[language];
  const { isTablet } = useResponsiveLayout();

  const [logs, setLogs] = useState<EventLogItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');

  useEffect(() => {
    setLogs(getStoredEventLogs());
  }, []);

  const filteredLogs = logs.filter((log) => {
    const matchesSearch =
      log.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (log.childName && log.childName.toLowerCase().includes(searchTerm.toLowerCase()));

    if (!matchesSearch) return false;
    if (typeFilter !== 'all' && log.type !== typeFilter) return false;
    return true;
  });

  const getEventBadge = (type: EventType) => {
    switch (type) {
      case 'lock_activated':
        return (
          <span className="bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-800 text-[10px] px-2.5 py-0.5 rounded-full font-bold">
            Lock Mode
          </span>
        );
      case 'pin_failed':
        return (
          <span className="bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-800 text-[10px] px-2.5 py-0.5 rounded-full font-bold">
            Failed PIN
          </span>
        );
      case 'pin_success':
        return (
          <span className="bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 text-[10px] px-2.5 py-0.5 rounded-full font-bold">
            PIN Valid
          </span>
        );
      case 'extra_time_granted':
        return (
          <span className="bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800 text-[10px] px-2.5 py-0.5 rounded-full font-bold">
            Extra Time
          </span>
        );
      case 'blocked_app_attempt':
        return (
          <span className="bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800 text-[10px] px-2.5 py-0.5 rounded-full font-bold">
            Blocked App
          </span>
        );
      case 'device_reboot':
        return (
          <span className="bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-300 border border-sky-200 dark:border-sky-800 text-[10px] px-2.5 py-0.5 rounded-full font-bold">
            Device Reboot
          </span>
        );
      case 'time_manipulation_detected':
        return (
          <span className="bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-800 text-[10px] px-2.5 py-0.5 rounded-full font-bold">
            Time Tamper
          </span>
        );
      default:
        return (
          <span className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 text-[10px] px-2.5 py-0.5 rounded-full font-medium">
            {type}
          </span>
        );
    }
  };

  return (
    <div className="space-y-3.5 sm:space-y-4">
      {/* Header & Controls */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl sm:rounded-3xl p-3.5 sm:p-4 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center space-x-2.5 rtl:space-x-reverse min-w-0">
          <AppIcon icon={ListOrdered} size="sm" colorScheme="purple" shape="rounded" />
          <div className="min-w-0">
            <h2 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white">
              {t.eventLog}
            </h2>
            <p className="text-[11px] text-slate-500 font-medium mt-0.5">
              Audit trail of lock events, PIN attempts, app launch blocks, and reboot recovery.
            </p>
          </div>
        </div>

        {/* Search & Filter */}
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          <div className="relative flex-1 md:w-52 min-w-[150px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 rtl:left-auto rtl:right-3 top-2.5 shrink-0 aspect-square" />
            <input
              type="text"
              placeholder="Search logs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl pl-8 rtl:pl-2.5 rtl:pr-8 pr-2.5 py-1.5 text-xs text-slate-800 dark:text-white font-medium focus:outline-none focus:border-blue-500 min-h-[34px]"
            />
          </div>

          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 dark:text-white font-bold focus:outline-none focus:border-blue-500 min-h-[34px]"
          >
            <option value="all">All Events</option>
            <option value="lock_activated">Lock Mode</option>
            <option value="pin_failed">Failed PIN</option>
            <option value="pin_success">PIN Success</option>
            <option value="extra_time_granted">Extra Time</option>
            <option value="blocked_app_attempt">Blocked App</option>
            <option value="device_reboot">Reboot</option>
            <option value="time_manipulation_detected">Time Tamper</option>
          </select>
        </div>
      </div>

      {/* Log Timeline */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl sm:rounded-3xl p-3.5 sm:p-4 shadow-2xs">
        {filteredLogs.length === 0 ? (
          <p className="text-xs text-slate-400 text-center py-6">No matching event logs found.</p>
        ) : (
          <div className="space-y-2">
            {filteredLogs.map((log) => {
              const formattedDate = new Date(log.timestamp).toLocaleString();
              return (
                <div
                  key={log.id}
                  className="p-3 bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 rounded-xl flex items-start justify-between gap-3 hover:bg-slate-100/60 dark:hover:bg-slate-800 transition"
                >
                  <div className="flex items-start space-x-2.5 rtl:space-x-reverse min-w-0">
                    <div className="p-1.5 bg-white dark:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700 shrink-0 mt-0.5 aspect-square flex items-center justify-center">
                      <Clock className="w-3.5 h-3.5 text-slate-500 shrink-0 aspect-square" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 mb-0.5 flex-wrap">
                        {getEventBadge(log.type)}
                        <span className="text-[10px] font-mono text-slate-400 font-medium">
                          {formattedDate}
                        </span>
                      </div>
                      <p className="text-xs text-slate-900 dark:text-white font-bold leading-snug">
                        {log.description}
                      </p>
                      {log.childName && (
                        <p className="text-[9px] text-slate-400 mt-0.5 font-medium">
                          Profile: {log.childName}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
