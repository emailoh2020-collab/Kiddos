import React from 'react';
import { useApp } from '../../context/AppContext';
import { translations } from '../../data/translations';
import { formatMinutesToReadable, formatSecondsToDigital, getNextAllowedPeriod } from '../../utils/time';
import { formatChildName } from '../../utils/locale';
import { useResponsiveLayout } from '../../utils/useResponsiveLayout';
import { AppIcon } from '../common/AppIcon';
import { DashboardCard, ActionButton } from '../common/ResponsiveComponents';
import {
  ShieldAlert,
  Smartphone,
  Clock,
  Calendar,
  Layers,
  Plus,
  Lock,
  BarChart3,
  ListOrdered,
  Camera,
  Settings,
  AlertTriangle,
  CheckCircle,
  Sparkles,
  ChevronRight,
  ShieldCheck,
} from 'lucide-react';

interface ParentOverviewProps {
  onNavigate: (tab: string) => void;
}

export const ParentOverview: React.FC<ParentOverviewProps> = ({ onNavigate }) => {
  const {
    child,
    session,
    schedule,
    settings,
    remainingDailySeconds,
    remainingSessionSeconds,
    isLocked,
    lockReason,
    setShowExtraTimeModal,
    forceLockDevice,
    unlockDeviceTemp,
    openPinModal,
    grantExtraTime,
    apps,
    language,
    getActiveUsageMode,
  } = useApp();

  const t = translations[language];
  const { isTablet, isExpanded } = useResponsiveLayout();
  const isFreeMode = settings?.controlMode === 'free';
  const activeUsageMode = getActiveUsageMode();

  // Free mode calculations
  const dailyAllowanceSec = isFreeMode
    ? child.dailyFreeTimeAllowanceSeconds || 10800
    : child.dailyLimitMinutes * 60;
  const usedTodaySec = isFreeMode
    ? session.freeModeUsedSecondsToday || 0
    : session.elapsedTodayMinutes * 60;
  const remainingSec = remainingDailySeconds;

  const totalAllowedWithExtra = dailyAllowanceSec + session.extraTimeMinutes * 60;
  const dailyProgress = Math.min(
    100,
    Math.round((usedTodaySec / Math.max(1, totalAllowedWithExtra)) * 100)
  );

  const sessionLimitSec = child.sessionLimitMinutes * 60;
  const sessionProgress = Math.min(
    100,
    Math.round(
      ((sessionLimitSec - remainingSessionSeconds) / Math.max(1, sessionLimitSec)) * 100
    )
  );

  const nextWindow = getNextAllowedPeriod(schedule);

  // Top used apps
  const sortedApps = [...apps]
    .sort((a, b) => b.totalUsageMinutes - a.totalUsageMinutes)
    .slice(0, 4);

  return (
    <div className="space-y-3.5 sm:space-y-4">
      {/* Control Mode Banner & Quick Toggle (Phone vs Tablet) */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl sm:rounded-3xl p-3.5 sm:p-4.5 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs">
        <div className="flex items-center space-x-2.5 sm:space-x-3 rtl:space-x-reverse min-w-0">
          <AppIcon
            icon={Clock}
            size="md"
            colorScheme={isFreeMode ? 'amber' : 'blue'}
            shape="squircle"
          />
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                {t.controlMode}:
              </span>
              <span
                className={`text-[11px] font-extrabold px-2 py-0.5 rounded-full border ${
                  isFreeMode
                    ? 'bg-amber-400/10 text-amber-300 border-amber-500/30'
                    : 'bg-blue-400/10 text-blue-300 border-blue-500/30'
                }`}
              >
                {isFreeMode ? t.freeMode : t.scheduledMode}
              </span>
            </div>
            <p className="text-[11px] text-slate-300 font-medium mt-0.5 truncate sm:whitespace-normal">
              {isFreeMode ? t.freeModeDesc : t.scheduledModeDesc}
            </p>
          </div>
        </div>

        <button
          onClick={() => onNavigate('settings')}
          className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-bold rounded-xl border border-slate-700 transition self-start sm:self-auto shrink-0 min-h-[36px]"
        >
          {t.edit} {t.controlMode}
        </button>
      </div>

      {/* Top Status Cards (1 column on phone, 2 columns on tablet, 4 on desktop) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-3.5">
        {/* Card 1: Device Status */}
        <DashboardCard
          title={t.deviceStatus}
          subtitle={`Child: ${formatChildName(child.name)} (${child.avatar || '👦'})`}
          icon={isLocked ? Lock : CheckCircle}
          badge={
            <span
              className={`px-2 py-0.5 rounded-full text-[11px] font-bold border flex items-center gap-1 ${
                isLocked
                  ? 'bg-red-50 text-red-600 border-red-200'
                  : 'bg-emerald-50 text-emerald-700 border-emerald-200'
              }`}
            >
              {isLocked ? t.statusLocked : t.statusAllowed}
            </span>
          }
        >
          <div className="mt-1">
            <div className="text-xl font-black text-slate-900 dark:text-white">
              {isLocked ? 'Device Locked' : 'PLAY MODE'}
            </div>
            <p className="text-[11px] text-slate-500 font-medium mt-0.5">
              {isLocked
                ? `Reason: ${
                    lockReason === 'daily_limit_reached'
                      ? t.dailyAllowanceUsedUp
                      : lockReason?.replace('_', ' ') || 'Time Expired'
                  }`
                : 'Full device permissions active'}
            </p>
          </div>

          <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-800">
            {isLocked ? (
              <ActionButton
                variant="success"
                size="sm"
                fullWidth
                onClick={() => openPinModal(unlockDeviceTemp, 'Parent Unlock Device')}
              >
                {t.unlockDevice}
              </ActionButton>
            ) : (
              <ActionButton
                variant="danger"
                size="sm"
                fullWidth
                onClick={() => forceLockDevice('manual_lock')}
              >
                {t.quickLock}
              </ActionButton>
            )}
          </div>
        </DashboardCard>

        {/* Card 2: Today's Screen Time Remaining */}
        <DashboardCard
          title={t.timeRemainingToday}
          subtitle={
            isFreeMode
              ? `${t.dailyAllowance}: ${formatSecondsToDigital(dailyAllowanceSec)}`
              : `Daily Limit: ${formatMinutesToReadable(child.dailyLimitMinutes)}`
          }
          icon={Clock}
          badge={
            session.extraTimeMinutes > 0 ? (
              <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded-full border border-emerald-200">
                +{session.extraTimeMinutes}m
              </span>
            ) : undefined
          }
        >
          <div className="mt-1">
            <div className="text-2xl font-mono font-black text-slate-900 dark:text-white tracking-tight">
              {formatSecondsToDigital(remainingSec)}
            </div>
            <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full mt-2 overflow-hidden border border-slate-200/50">
              <div
                className={`h-full transition-all duration-300 ${
                  dailyProgress > 85 ? 'bg-red-500' : 'bg-blue-600'
                }`}
                style={{ width: `${dailyProgress}%` }}
              />
            </div>
          </div>

          <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 font-medium flex items-center justify-between">
            <span>Progress: {dailyProgress}% used</span>
            <span className="text-slate-400">{Math.round(remainingSec / 60)}m left</span>
          </div>
        </DashboardCard>

        {/* Card 3: Free Mode Used / Active Session */}
        <DashboardCard
          title={isFreeMode ? t.usedToday : t.activeSession}
          subtitle={isFreeMode ? 'Cumulative usage' : `Max ${child.sessionLimitMinutes}m / session`}
          icon={Smartphone}
        >
          <div className="mt-1">
            <div
              className={`text-2xl font-mono font-black tracking-tight ${
                isFreeMode ? 'text-amber-600 dark:text-amber-400' : 'text-emerald-600 dark:text-emerald-400'
              }`}
            >
              {formatSecondsToDigital(usedTodaySec)}
            </div>
            <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full mt-2 overflow-hidden border border-slate-200/50">
              <div
                className={`h-full transition-all duration-300 ${
                  isFreeMode ? 'bg-amber-500' : 'bg-emerald-500'
                }`}
                style={{ width: `${isFreeMode ? dailyProgress : sessionProgress}%` }}
              />
            </div>
          </div>

          <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 font-medium flex items-center justify-between">
            {isFreeMode ? (
              <span className="text-slate-500">{t.freeTimeResetNotice}</span>
            ) : (
              <>
                <span>Next Window:</span>
                <span className="text-blue-600 font-bold">
                  {nextWindow?.day} at {nextWindow?.startTime}
                </span>
              </>
            )}
          </div>
        </DashboardCard>

        {/* Card 4: Current Usage Mode */}
        <DashboardCard
          title={t.usageModes || 'Usage Mode'}
          subtitle={activeUsageMode?.description || 'Current active mode'}
          icon={Sparkles}
        >
          <div className="mt-1 flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 flex items-center justify-center text-lg border border-indigo-100 shrink-0">
              {activeUsageMode?.icon || '🏠'}
            </div>
            <div>
              <div className="text-base font-black text-slate-900 dark:text-white">
                {activeUsageMode?.name || 'Normal Mode'}
              </div>
              <p className="text-[10px] text-slate-500 font-medium">
                {activeUsageMode?.id === 'normal' 
                  ? 'All allowed apps available'
                  : `${activeUsageMode?.allowedApps.length || 0} apps allowed`}
              </p>
            </div>
          </div>

          <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-800">
            <ActionButton
              variant="primary"
              size="sm"
              fullWidth
              onClick={() => onNavigate('usage_modes')}
            >
              {t.changeMode || 'Change Mode'}
            </ActionButton>
          </div>
        </DashboardCard>
      </div>

      {/* Grant Extra Time Quick Panel (Responsive) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl sm:rounded-3xl p-3.5 sm:p-4.5 shadow-xs">
        <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
          <div className="flex items-center space-x-2.5 rtl:space-x-reverse min-w-0">
            <AppIcon icon={Plus} size="sm" colorScheme="blue" shape="rounded" />
            <div className="min-w-0">
              <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-white truncate">
                {t.grantExtraTime}
              </h3>
              <p className="text-[10px] sm:text-[11px] text-slate-500 font-medium truncate">
                Instantly grant additional usage time to {formatChildName(child.name)}
              </p>
            </div>
          </div>
          <button
            onClick={() => setShowExtraTimeModal(true)}
            className="px-2.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-bold rounded-xl shadow-2xs transition shrink-0 min-h-[32px]"
          >
            Custom Time
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-2.5">
          {[5, 15, 30, 60].map((m) => (
            <button
              key={m}
              onClick={() => {
                openPinModal(() => {
                  grantExtraTime(m, 'Parent quick grant');
                }, `Approve +${m} Minutes`);
              }}
              className="py-2 bg-slate-900 hover:bg-slate-800 active:bg-blue-600 text-white font-bold text-xs rounded-xl transition flex items-center justify-center space-x-1 rtl:space-x-reverse shadow-2xs min-h-[38px]"
            >
              <span>+{m}</span>
              <span className="text-[10px] font-normal opacity-80">Mins</span>
            </button>
          ))}
        </div>
      </div>

      {/* Grid: Quick Action Cards + App Usage Highlights (Adaptive on tablets) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3.5 sm:gap-4">
        {/* Navigation Quick Actions */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl sm:rounded-3xl p-3.5 sm:p-4.5 shadow-xs">
          <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-white mb-3">
            {t.quickActions}
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 sm:gap-2.5">
            {[
              { id: 'schedule', label: t.schedule, sub: 'Weekly matrix', icon: Calendar, color: 'blue' as const },
              { id: 'apps', label: t.apps, sub: 'Allowed / Blocked', icon: Layers, color: 'emerald' as const },
              { id: 'usage_modes', label: t.usageModes || 'Usage Modes', sub: 'Context rules', icon: Sparkles, color: 'purple' as const },
              { id: 'statistics', label: t.statistics, sub: 'Screen analytics', icon: BarChart3, color: 'amber' as const },
              { id: 'eventLog', label: t.eventLog, sub: 'System activity', icon: ListOrdered, color: 'indigo' as const },
              { id: 'verification', label: t.verification, sub: 'Photo records', icon: Camera, color: 'red' as const },
              { id: 'settings', label: t.settings, sub: 'PIN & Security', icon: Settings, color: 'slate' as const },
            ].map((action) => {
              const ActionIcon = action.icon;
              return (
                <button
                  key={action.id}
                  onClick={() => onNavigate(action.id)}
                  className="p-2.5 sm:p-3 bg-slate-50 dark:bg-slate-800/60 hover:bg-blue-50/50 dark:hover:bg-slate-800 border border-slate-200/80 dark:border-slate-700/80 hover:border-blue-200 rounded-xl text-left rtl:text-right transition group min-h-[72px] flex flex-col justify-between"
                >
                  <AppIcon
                    icon={ActionIcon}
                    size="xs"
                    colorScheme={action.color}
                    shape="rounded"
                    className="mb-1 group-hover:scale-105 transition-transform"
                  />
                  <div>
                    <h4 className="text-[11px] sm:text-xs font-bold text-slate-900 dark:text-white truncate">
                      {action.label}
                    </h4>
                    <p className="text-[9px] text-slate-500 truncate mt-0.5">{action.sub}</p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Most Used Apps List */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl sm:rounded-3xl p-3.5 sm:p-4.5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-white">
                Most Used Apps
              </h3>
              <button
                onClick={() => onNavigate('apps')}
                className="text-[11px] text-blue-600 hover:underline font-bold"
              >
                Manage All
              </button>
            </div>

            <div className="space-y-2">
              {sortedApps.map((app) => (
                <div
                  key={app.packageName}
                  className="p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200/70 dark:border-slate-700/70 flex items-center justify-between hover:bg-slate-100/60 transition"
                >
                  <div className="flex items-center space-x-2 rtl:space-x-reverse min-w-0">
                    <AppIcon
                      icon={app.icon}
                      text={app.appName.charAt(0)}
                      size="xs"
                      colorScheme={app.isAllowed ? 'blue' : 'red'}
                      shape="rounded"
                    />
                    <div className="min-w-0">
                      <h4 className="text-[11px] sm:text-xs font-bold text-slate-800 dark:text-slate-200 leading-tight truncate">
                        {app.appName}
                      </h4>
                      <p className="text-[9px] text-slate-500 truncate max-w-[100px]">
                        {app.packageName}
                      </p>
                    </div>
                  </div>

                  <div className="text-right rtl:text-left shrink-0">
                    <span className="text-[11px] font-black text-slate-900 dark:text-white block">
                      {app.totalUsageMinutes}m
                    </span>
                    <span
                      className={`text-[8px] font-extrabold px-1 py-0.5 rounded uppercase ${
                        app.isAllowed
                          ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400'
                          : 'bg-red-50 text-red-600 dark:bg-red-950/40 dark:text-red-400'
                      }`}
                    >
                      {app.isAllowed ? 'Allowed' : 'Blocked'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
