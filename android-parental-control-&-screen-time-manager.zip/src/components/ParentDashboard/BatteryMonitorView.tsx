import React from 'react';
import { useApp } from '../../context/AppContext';
import { AppBatteryUsage } from '../../types';
import { translations } from '../../data/translations';
import { AppIcon } from '../common/AppIcon';
import {
  Zap,
  Battery,
  BatteryCharging,
  AlertTriangle,
  CheckCircle,
  Sliders,
  Smartphone,
  ShieldAlert,
  Activity,
  ArrowUpRight,
} from 'lucide-react';

export const BatteryMonitorView: React.FC = () => {
  const { batteryUsage, optimizeBatteryApp, language } = useApp();
  const t = translations[language];

  const totalBattery = batteryUsage.reduce((acc, curr) => acc + curr.totalBatteryPercent, 0);
  const excessiveCount = batteryUsage.filter((b) => b.status === 'excessive' || b.status === 'high_background').length;

  return (
    <div className="space-y-3.5 sm:space-y-4 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-amber-600 to-orange-700 text-white rounded-2xl sm:rounded-3xl p-4 sm:p-5 shadow-sm relative overflow-hidden flex flex-col md:flex-row justify-between items-start md:items-center gap-3.5">
        <div className="relative z-10 max-w-xl">
          <div className="inline-flex items-center space-x-1.5 bg-amber-500/30 backdrop-blur-md px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider mb-1.5">
            <Battery className="w-3.5 h-3.5 shrink-0 aspect-square" />
            <span>Battery & Power Monitor</span>
          </div>
          <h1 className="text-lg sm:text-xl font-black tracking-tight">
            Device Power & Background Drain
          </h1>
          <p className="text-amber-100 mt-1 text-xs leading-relaxed">
            Monitor real-time power consumption and identify apps draining the battery in the background on your child's device.
          </p>
        </div>

        {/* Quick Stats Card */}
        <div className="bg-white/10 backdrop-blur-md p-3 rounded-xl border border-white/25 flex items-center space-x-3 shrink-0">
          <div className="w-9 h-9 rounded-lg bg-amber-400/20 text-amber-200 flex items-center justify-center shrink-0 aspect-square">
            <Zap className="w-4.5 h-4.5" />
          </div>
          <div>
            <div className="text-[10px] font-bold uppercase text-amber-200">High Drain Apps</div>
            <div className="text-lg font-black">{excessiveCount} Flagged</div>
          </div>
        </div>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5 sm:gap-3">
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-3.5 sm:p-4 border border-slate-200 dark:border-slate-800 shadow-2xs flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-900/40 text-emerald-600 flex items-center justify-center shrink-0 aspect-square">
            <BatteryCharging className="w-4.5 h-4.5" />
          </div>
          <div>
            <div className="text-[10px] font-bold text-slate-400 uppercase">Estimated Battery Life</div>
            <div className="text-sm sm:text-base font-black text-slate-900 dark:text-white mt-0.5">8h 42m Remaining</div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-3.5 sm:p-4 border border-slate-200 dark:border-slate-800 shadow-2xs flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-blue-50 dark:bg-blue-900/40 text-blue-600 flex items-center justify-center shrink-0 aspect-square">
            <Activity className="w-4.5 h-4.5" />
          </div>
          <div>
            <div className="text-[10px] font-bold text-slate-400 uppercase">Total Tracked Drain</div>
            <div className="text-sm sm:text-base font-black text-slate-900 dark:text-white mt-0.5">{totalBattery.toFixed(1)}% / 24h</div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-2xl p-3.5 sm:p-4 border border-slate-200 dark:border-slate-800 shadow-2xs flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-amber-50 dark:bg-amber-900/40 text-amber-600 flex items-center justify-center shrink-0 aspect-square">
            <ShieldAlert className="w-4.5 h-4.5" />
          </div>
          <div>
            <div className="text-[10px] font-bold text-slate-400 uppercase">Power Optimization</div>
            <div className="text-sm sm:text-base font-black text-slate-900 dark:text-white mt-0.5">Ready to Restrict</div>
          </div>
        </div>
      </div>

      {/* App Battery Breakdown List */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl p-4 sm:p-5 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3.5">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2.5">
          <div>
            <h2 className="text-sm sm:text-base font-black text-slate-900 dark:text-white">App Power Consumption Breakdown</h2>
            <p className="text-[11px] text-slate-500 mt-0.5">Showing foreground and background battery drain for installed apps.</p>
          </div>
          <div className="text-[10px] font-bold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 px-2.5 py-1 rounded-lg border border-amber-200 dark:border-amber-800">
            Tap 'Optimize' to restrict background drain
          </div>
        </div>

        <div className="space-y-2.5">
          {batteryUsage.map((app) => {
            const isExcessive = app.status === 'excessive';
            const isHigh = app.status === 'high_background';
            return (
              <div
                key={app.packageName}
                className={`p-3.5 rounded-xl border transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-3 ${
                  isExcessive
                    ? 'bg-rose-50/50 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900/50'
                    : isHigh
                    ? 'bg-amber-50/40 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900/50'
                    : 'bg-slate-50/60 dark:bg-slate-800/50 border-slate-200 dark:border-slate-800'
                }`}
              >
                {/* App Info */}
                <div className="flex items-center space-x-3 min-w-0">
                  <AppIcon
                    icon={app.icon}
                    size="md"
                    colorScheme={isExcessive ? 'red' : isHigh ? 'amber' : 'blue'}
                    shape="rounded"
                  />
                  <div className="min-w-0">
                    <div className="flex items-center space-x-1.5">
                      <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white truncate">{app.appName}</h3>
                      <span
                        className={`px-1.5 py-0.5 rounded text-[9px] font-black uppercase tracking-wider ${
                          isExcessive
                            ? 'bg-rose-600 text-white'
                            : isHigh
                            ? 'bg-amber-600 text-white'
                            : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        {isExcessive ? 'Excessive' : isHigh ? 'High Bg' : 'Normal'}
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono mt-0.5">{app.packageName}</div>
                  </div>
                </div>

                {/* Battery Metrics & Actions */}
                <div className="flex items-center justify-between md:justify-end w-full md:w-auto gap-4 shrink-0">
                  <div className="text-right">
                    <div className="text-xs font-black text-slate-900 dark:text-white">
                      {app.totalBatteryPercent}% ({app.powerConsumptionMah} mAh)
                    </div>
                    <div className="text-[10px] text-slate-500 font-medium">
                      Fg: {app.foregroundBatteryPercent}% • Bg: {app.backgroundBatteryPercent}%
                    </div>
                  </div>

                  <button
                    onClick={() => optimizeBatteryApp(app.packageName)}
                    className={`px-3 py-1.5 rounded-lg text-[11px] font-bold transition-all shadow-2xs flex items-center space-x-1 min-h-[32px] ${
                      isExcessive || isHigh
                        ? 'bg-amber-600 hover:bg-amber-700 text-white'
                        : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-300'
                    }`}
                  >
                    <Sliders className="w-3 h-3 shrink-0 aspect-square" />
                    <span>Optimize</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
