import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { VerificationRecord } from '../../types';
import { translations } from '../../data/translations';
import { getStoredVerifications } from '../../utils/storage';
import { useResponsiveLayout } from '../../utils/useResponsiveLayout';
import { AppIcon } from '../common/AppIcon';
import { Camera, ShieldCheck, Trash2, Video, Lock, AlertCircle, Eye } from 'lucide-react';

export const VerificationView: React.FC = () => {
  const { captureVerificationPhoto, language } = useApp();
  const t = translations[language];
  const { isTablet } = useResponsiveLayout();

  const [records, setRecords] = useState<VerificationRecord[]>([]);
  const [cameraActive, setCameraActive] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    setRecords(getStoredVerifications());
  }, []);

  const handleStartCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ video: true });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
      setCameraActive(true);
    } catch (e) {
      console.warn('Camera access error or iframe permission limitation:', e);
      // Fallback mock camera trigger
      setCameraActive(true);
    }
  };

  const handleStopCamera = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
      setStream(null);
    }
    setCameraActive(false);
  };

  const handleCapturePhoto = () => {
    const mockPhotos = [
      'https://images.unsplash.com/photo-1543269865-cbf427effbad?w=400&q=80',
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&q=80',
    ];
    const snap = mockPhotos[Math.floor(Math.random() * mockPhotos.length)];
    captureVerificationPhoto(snap, 'Manual Parent Verification Check');
    handleStopCamera();
    setRecords(getStoredVerifications());
  };

  const handleClearVerifications = () => {
    localStorage.removeItem('pc_verifications_v2');
    setRecords([]);
  };

  return (
    <div className="space-y-5 sm:space-y-6">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center space-x-3 rtl:space-x-reverse min-w-0">
          <AppIcon icon={Camera} size="md" colorScheme="red" shape="rounded" />
          <div className="min-w-0">
            <h2 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white">
              {t.verification}
            </h2>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              User verification photo records for extra time or session access validation.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 rtl:space-x-reverse shrink-0">
          <button
            onClick={cameraActive ? handleStopCamera : handleStartCamera}
            className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-2xl shadow-xs transition flex items-center space-x-1.5 rtl:space-x-reverse min-h-[40px]"
          >
            <Video className="w-4 h-4 shrink-0 aspect-square" />
            <span>{cameraActive ? 'Close Camera' : 'Take Verification Photo'}</span>
          </button>
          {records.length > 0 && (
            <button
              onClick={handleClearVerifications}
              className="px-3.5 py-2.5 bg-red-50 dark:bg-red-950/40 hover:bg-red-100 text-red-600 dark:text-red-300 text-xs font-bold rounded-2xl border border-red-200 dark:border-red-800 transition flex items-center space-x-1 rtl:space-x-reverse min-h-[40px]"
            >
              <Trash2 className="w-3.5 h-3.5 shrink-0 aspect-square" />
              <span>Clear Records</span>
            </button>
          )}
        </div>
      </div>

      {/* Strict Privacy Notice Banner */}
      <div className="p-4 bg-blue-50 dark:bg-blue-950/40 border border-blue-200/80 dark:border-blue-800/80 rounded-3xl flex items-start space-x-3 rtl:space-x-reverse text-xs text-blue-900 dark:text-blue-200">
        <ShieldCheck className="w-5 h-5 text-blue-600 shrink-0 mt-0.5 aspect-square" />
        <div>
          <h4 className="font-extrabold text-slate-900 dark:text-white">
            Privacy by Design — Explicit Camera Operation
          </h4>
          <p className="mt-0.5 text-slate-600 dark:text-slate-300 font-medium leading-relaxed">
            Camera is <strong>never activated secretly</strong> in the background, and audio is{' '}
            <strong>never recorded</strong>. All verification photos require explicit user
            interaction and remain stored locally on device.
          </p>
        </div>
      </div>

      {/* Active Camera Viewfinder Box */}
      {cameraActive && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm text-center max-w-lg mx-auto">
          <div className="relative aspect-video bg-slate-100 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden mb-4 flex items-center justify-center">
            {stream ? (
              <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
            ) : (
              <div className="p-6 text-center">
                <Camera className="w-12 h-12 text-slate-400 mx-auto mb-2 animate-pulse shrink-0 aspect-square" />
                <p className="text-xs text-slate-600 dark:text-slate-300 font-bold">
                  Camera Viewfinder Active
                </p>
                <span className="inline-block mt-2 px-2.5 py-0.5 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 rounded-full text-[10px] font-bold">
                  Camera Active - Explicit User Verification
                </span>
              </div>
            )}
          </div>

          <div className="flex justify-center space-x-3 rtl:space-x-reverse">
            <button
              onClick={handleStopCamera}
              className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold rounded-2xl border border-slate-200 dark:border-slate-700 transition min-h-[40px]"
            >
              Cancel
            </button>
            <button
              onClick={handleCapturePhoto}
              className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-2xl shadow-xs transition flex items-center space-x-2 rtl:space-x-reverse min-h-[40px]"
            >
              <Camera className="w-4 h-4 shrink-0 aspect-square" />
              <span>Capture Photo</span>
            </button>
          </div>
        </div>
      )}

      {/* Verification Photo Log Grid */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm">
        <h3 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white mb-4">
          Saved Verification Records ({records.length})
        </h3>

        {records.length === 0 ? (
          <p className="text-xs text-slate-400 text-center py-8">No verification photos taken yet.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {records.map((rec) => (
              <div
                key={rec.id}
                className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 rounded-2xl overflow-hidden p-3"
              >
                <img
                  src={rec.photoUrl}
                  alt="Verification snapshot"
                  referrerPolicy="no-referrer"
                  className="w-full h-36 object-cover rounded-xl mb-2"
                />
                <div className="text-xs">
                  <span className="font-extrabold text-slate-900 dark:text-white block truncate">
                    {rec.reason}
                  </span>
                  <span className="text-[10px] text-slate-500 block mt-0.5 font-medium">
                    {new Date(rec.timestamp).toLocaleString()}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
