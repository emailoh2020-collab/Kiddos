import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { WebCategory, BlockedUrlRule } from '../../types';
import { translations } from '../../data/translations';
import {
  ShieldCheck,
  Globe,
  Lock,
  Unlock,
  Plus,
  Trash2,
  AlertTriangle,
  CheckCircle,
  HelpCircle,
  Flame,
  Gamepad2,
  MessageSquare,
  Film,
  Zap,
  Search,
  Check,
} from 'lucide-react';

export const WebFilterManager: React.FC = () => {
  const { webFilterConfig, updateWebFilterConfig, checkUrlAccess, language } = useApp();
  const t = translations[language];

  const [newUrlPattern, setNewUrlPattern] = useState('');
  const [newUrlCategory, setNewUrlCategory] = useState<WebCategory>('adult');
  const [newUrlNotes, setNewUrlNotes] = useState('');
  const [testUrl, setTestUrl] = useState('');
  const [testResult, setTestResult] = useState<{ allowed: boolean; category?: string; reason?: string } | null>(null);

  const categories: { key: WebCategory; label: string; desc: string; icon: any }[] = [
    { key: 'adult', label: 'Adult Content & NSFW', desc: 'Block adult websites, pornography, and mature content', icon: Flame },
    { key: 'gambling', label: 'Gambling & Betting', desc: 'Block online casinos, sports betting, and lottery sites', icon: Globe },
    { key: 'social_media', label: 'Social Media & Chat', desc: 'Block TikTok, Instagram, X (Twitter), Snapchat, etc.', icon: MessageSquare },
    { key: 'violence', label: 'Violence & Gore', desc: 'Block violent content, weapons, and graphic media', icon: AlertTriangle },
    { key: 'phishing', label: 'Phishing & Malware', desc: 'Block malicious websites, fake login pages, and scams', icon: ShieldCheck },
    { key: 'entertainment', label: 'Streaming & Video', desc: 'Block Netflix, Twitch, Hulu, and video platforms', icon: Film },
    { key: 'gaming', label: 'Online Gaming', desc: 'Block Roblox, Steam, Epic Games, and online web games', icon: Gamepad2 },
  ];

  const handleToggleEnabled = (enabled: boolean) => {
    updateWebFilterConfig({
      ...webFilterConfig,
      enabled,
    });
  };

  const handleToggleCategory = (category: WebCategory) => {
    const exists = webFilterConfig.blockedCategories.includes(category);
    const updatedCategories = exists
      ? webFilterConfig.blockedCategories.filter((c) => c !== category)
      : [...webFilterConfig.blockedCategories, category];

    updateWebFilterConfig({
      ...webFilterConfig,
      blockedCategories: updatedCategories,
    });
  };

  const handleToggleSafeSearch = (safeSearchEnabled: boolean) => {
    updateWebFilterConfig({
      ...webFilterConfig,
      safeSearchEnabled,
    });
  };

  const handleAddCustomUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUrlPattern.trim()) return;

    const newRule: BlockedUrlRule = {
      id: `url_${Date.now()}`,
      urlPattern: newUrlPattern.trim(),
      category: newUrlCategory,
      isBlocked: true,
      notes: newUrlNotes.trim() || undefined,
    };

    updateWebFilterConfig({
      ...webFilterConfig,
      customBlockedUrls: [...webFilterConfig.customBlockedUrls, newRule],
    });

    setNewUrlPattern('');
    setNewUrlNotes('');
  };

  const handleDeleteRule = (id: string) => {
    updateWebFilterConfig({
      ...webFilterConfig,
      customBlockedUrls: webFilterConfig.customBlockedUrls.filter((r) => r.id !== id),
    });
  };

  const handleTestUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!testUrl.trim()) return;
    const result = checkUrlAccess(testUrl.trim());
    setTestResult(result);
  };

  return (
    <div className="space-y-3.5 sm:space-y-4 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white rounded-2xl sm:rounded-3xl p-4 sm:p-5 shadow-sm relative overflow-hidden flex flex-col md:flex-row justify-between items-start md:items-center gap-3.5">
        <div className="relative z-10 max-w-xl">
          <div className="inline-flex items-center space-x-1.5 bg-emerald-500/30 backdrop-blur-md px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider mb-1.5">
            <ShieldCheck className="w-3.5 h-3.5 shrink-0 aspect-square" />
            <span>Web Filtering & URL Protection</span>
          </div>
          <h1 className="text-lg sm:text-xl font-black tracking-tight">
            Category-Based Web Filtering & URL Blocking
          </h1>
          <p className="text-emerald-100 mt-1 text-xs leading-relaxed">
            Protect your child from inappropriate websites, adult content, gambling, and dangerous domains with automated filters and custom URL blocks.
          </p>
        </div>

        {/* Master Toggle */}
        <div className="bg-white/10 backdrop-blur-md p-3 rounded-xl border border-white/25 flex items-center space-x-3 shrink-0">
          <div className="text-right">
            <div className="text-[10px] font-bold uppercase text-emerald-200">Web Filter Status</div>
            <div className="text-sm font-black">{webFilterConfig.enabled ? 'ACTIVE & PROTECTING' : 'DISABLED'}</div>
          </div>
          <button
            onClick={() => handleToggleEnabled(!webFilterConfig.enabled)}
            className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
              webFilterConfig.enabled ? 'bg-emerald-400' : 'bg-slate-500'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white transition-transform ${
                webFilterConfig.enabled ? 'transform translate-x-5' : ''
              }`}
            />
          </button>
        </div>
      </div>

      {/* Safe Search & Global Options */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-3.5 sm:p-4 border border-slate-200 dark:border-slate-800 shadow-2xs flex flex-col sm:flex-row justify-between items-center gap-3">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-blue-50 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0 aspect-square">
            <Search className="w-4.5 h-4.5" />
          </div>
          <div>
            <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">Enforce Strict SafeSearch</h3>
            <p className="text-[10px] text-slate-500">Automatically filter explicit images and videos from Google, Bing, and YouTube searches.</p>
          </div>
        </div>
        <button
          onClick={() => handleToggleSafeSearch(!webFilterConfig.safeSearchEnabled)}
          className={`px-4 py-2 rounded-xl font-bold text-xs transition-all min-h-[34px] ${
            webFilterConfig.safeSearchEnabled
              ? 'bg-blue-600 text-white shadow-2xs'
              : 'bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
          }`}
        >
          {webFilterConfig.safeSearchEnabled ? 'SafeSearch Enforced' : 'Disabled'}
        </button>
      </div>

      {/* Categories Grid */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl p-4 sm:p-5 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3.5">
        <div>
          <h2 className="text-sm sm:text-base font-black text-slate-900 dark:text-white">Restricted Web Categories</h2>
          <p className="text-[11px] text-slate-500 mt-0.5">Select website categories to automatically block during child browsing sessions.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 sm:gap-3">
          {categories.map((cat) => {
            const Icon = cat.icon;
            const isBlocked = webFilterConfig.blockedCategories.includes(cat.key);
            return (
              <div
                key={cat.key}
                onClick={() => handleToggleCategory(cat.key)}
                className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                  isBlocked
                    ? 'border-emerald-500/50 bg-emerald-50/50 dark:bg-emerald-950/20 shadow-2xs'
                    : 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center space-x-2.5">
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 aspect-square ${
                      isBlocked
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white">{cat.label}</div>
                    <div className="text-[10px] text-slate-500 line-clamp-1">{cat.desc}</div>
                  </div>
                </div>

                <div
                  className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 border ${
                    isBlocked
                      ? 'bg-emerald-600 border-emerald-600 text-white'
                      : 'border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-transparent'
                  }`}
                >
                  <Check className="w-3 h-3 stroke-[3]" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Custom URL Rules & Sandbox */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3.5 sm:gap-4">
        {/* Add & List Custom URLs */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl p-4 sm:p-5 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            <div>
              <h3 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white">Custom Domain & URL Blocklist</h3>
              <p className="text-[11px] text-slate-500">Add specific web domains or keywords to block instantly.</p>
            </div>

            <form onSubmit={handleAddCustomUrl} className="space-y-2.5">
              <div>
                <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400">URL / Domain Pattern</label>
                <input
                  type="text"
                  value={newUrlPattern}
                  onChange={(e) => setNewUrlPattern(e.target.value)}
                  placeholder="e.g. distraction-site.com"
                  className="w-full mt-1 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 min-h-[36px]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400">Category</label>
                  <select
                    value={newUrlCategory}
                    onChange={(e) => setNewUrlCategory(e.target.value as WebCategory)}
                    className="w-full mt-1 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-[11px] font-medium focus:outline-none min-h-[34px]"
                  >
                    {categories.map((c) => (
                      <option key={c.key} value={c.key}>
                        {c.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400">Notes (Optional)</label>
                  <input
                    type="text"
                    value={newUrlNotes}
                    onChange={(e) => setNewUrlNotes(e.target.value)}
                    placeholder="e.g. Blocked per teacher"
                    className="w-full mt-1 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-[11px] font-medium focus:outline-none min-h-[34px]"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-xs shadow-2xs transition-all flex items-center justify-center space-x-1.5 min-h-[36px]"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Blocked URL Rule</span>
              </button>
            </form>
          </div>

          <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
            <div className="text-[10px] font-bold text-slate-500 uppercase">Active Custom Rules ({webFilterConfig.customBlockedUrls.length})</div>
            {webFilterConfig.customBlockedUrls.length === 0 ? (
              <div className="text-xs text-slate-400 italic py-2 text-center">No custom URL rules added yet.</div>
            ) : (
              webFilterConfig.customBlockedUrls.map((rule) => (
                <div key={rule.id} className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-slate-900 dark:text-white truncate">{rule.urlPattern}</div>
                    <div className="text-[9px] text-slate-500 uppercase font-medium">{rule.category} {rule.notes ? `• ${rule.notes}` : ''}</div>
                  </div>
                  <button
                    onClick={() => handleDeleteRule(rule.id)}
                    className="p-1 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-md transition-colors shrink-0"
                    title="Remove rule"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {/* URL Filter Sandbox Tester */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl p-4 sm:p-5 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-lg bg-teal-50 dark:bg-teal-900/40 text-teal-600 flex items-center justify-center shrink-0 aspect-square">
                <Globe className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-xs sm:text-sm font-black text-slate-900 dark:text-white">Web Filter Sandbox Tester</h3>
                <p className="text-[10px] text-slate-500">Test any URL against active web filter rules.</p>
              </div>
            </div>

            <form onSubmit={handleTestUrl} className="space-y-2">
              <div>
                <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400">Enter Website URL to Test</label>
                <div className="flex space-x-2 mt-1">
                  <input
                    type="text"
                    value={testUrl}
                    onChange={(e) => setTestUrl(e.target.value)}
                    placeholder="https://example.com/page"
                    className="flex-1 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-teal-500 min-h-[36px]"
                  />
                  <button
                    type="submit"
                    className="px-3.5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg font-bold text-xs shadow-2xs transition-all min-h-[36px]"
                  >
                    Test URL
                  </button>
                </div>
              </div>
            </form>

            {testResult && (
              <div
                className={`p-3 rounded-xl border flex items-start space-x-2.5 transition-all ${
                  testResult.allowed
                    ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
                    : 'bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200'
                }`}
              >
                {testResult.allowed ? (
                  <CheckCircle className="w-4 h-4 shrink-0 text-emerald-600 mt-0.5" />
                ) : (
                  <AlertTriangle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
                )}
                <div className="space-y-0.5">
                  <div className="text-[11px] font-bold uppercase tracking-wider">
                    {testResult.allowed ? 'Access Allowed' : 'Access Blocked'}
                  </div>
                  <div className="text-[11px] font-medium">
                    {testResult.allowed
                      ? 'This URL complies with all parental web filter rules and category settings.'
                      : testResult.reason || 'Blocked by active web filter policy.'}
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 text-[10px] text-slate-500 space-y-1">
            <div className="font-bold text-slate-700 dark:text-slate-300">How Web Filtering Integrates:</div>
            <p>
              When web filtering is active, any browsing attempt matching blocked categories or custom rules immediately triggers a secure restriction screen and logs an event in the Parent Event Log.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
