import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { ChildProfile, EmergencyContact } from '../../types';
import { translations } from '../../data/translations';
import { SUPPORTED_LANGUAGES } from '../../data/languages';
import { formatChildName } from '../../utils/locale';
import { generateSalt, hashPin } from '../../utils/crypto';
import { clearAllChildData } from '../../utils/storage';
import { APP_CONFIG } from '../../config/appConfig';
import { AppLogo } from '../AppLogo';
import { LanguageModal } from '../LanguageModal';
import { useResponsiveLayout } from '../../utils/useResponsiveLayout';
import { AppIcon } from '../common/AppIcon';
import { ActionButton, DashboardCard } from '../common/ResponsiveComponents';
import { nativeBridge } from '../../utils/nativeBridge';
import {
  Settings,
  Lock,
  PhoneCall,
  ShieldAlert,
  Clock,
  Globe,
  Trash2,
  Plus,
  Check,
  Info,
  ChevronRight,
  Users,
  UserPlus,
  UserCheck,
  Edit2,
  User,
  ShieldCheck,
  Sparkles,
  Smartphone,
  Sliders,
  Cpu,
  Power,
  RefreshCw,
  Eye,
  AlertTriangle
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const {
    settings,
    updateSettings,
    child,
    childrenList,
    activeChildId,
    updateChildProfile,
    addChildProfile,
    deleteChildProfile,
    selectActiveChild,
    setLanguage,
    openPinModal,
    language,
    setActiveTab,
    exitParentSession,
    touchParentActivity,
    addEventLog,
    addNotification,
  } = useApp();
  const t = translations[language];
  const { isTablet } = useResponsiveLayout();

  // Active category for two-pane layout on tablets
  const [selectedCategory, setSelectedCategory] = useState<
    'mode' | 'children' | 'security' | 'protection' | 'contacts' | 'system' | 'about'
  >('mode');

  // Multi-Child Account Form State
  const [showChildModal, setShowChildModal] = useState(false);
  const [showLanguageModal, setShowLanguageModal] = useState(false);
  const [editingChildId, setEditingChildId] = useState<string | null>(null);
  const [childToDelete, setChildToDelete] = useState<ChildProfile | null>(null);
  const [formName, setFormName] = useState('Adam');
  const [formAvatar, setFormAvatar] = useState('👦');
  const [formFreeHours, setFormFreeHours] = useState(3);
  const [formDailyLimitMins, setFormDailyLimitMins] = useState(120);
  const [formSessionLimitMins, setFormSessionLimitMins] = useState(45);

  // PIN Change State
  const [newPinInput, setNewPinInput] = useState('');
  const [pinMsg, setPinMsg] = useState<{ text: string; error: boolean } | null>(null);

  // Emergency Contact Form
  const [newContactName, setNewContactName] = useState('');
  const [newContactPhone, setNewContactPhone] = useState('');
  const [newContactRelation, setNewContactRelation] = useState('Parent');

  const handleModeChange = (mode: 'free' | 'scheduled') => {
    openPinModal(() => {
      updateSettings({ ...settings, controlMode: mode });
      addEventLog(
        'mode_changed',
        `Control Mode changed to: ${mode === 'free' ? 'Free Mode' : 'Scheduled Mode'}`,
        child.name
      );
      addNotification(
        'Control Mode Updated',
        `Switched to ${mode === 'free' ? 'Free Mode' : 'Scheduled Mode'}.`,
        'success'
      );
    }, `Switch to ${mode === 'free' ? 'Free Mode' : 'Scheduled Mode'}`);
  };

  const handleOpenAddModal = () => {
    setEditingChildId(null);
    setFormName('');
    setFormAvatar('👦');
    setFormFreeHours(3);
    setFormDailyLimitMins(120);
    setFormSessionLimitMins(45);
    setShowChildModal(true);
  };

  const handleOpenEditModal = (c: ChildProfile) => {
    setEditingChildId(c.id);
    setFormName(c.name);
    setFormAvatar(c.avatar || '👦');
    setFormFreeHours(Math.max(1, Math.round((c.dailyFreeTimeAllowanceSeconds || 10800) / 3600)));
    setFormDailyLimitMins(c.dailyLimitMinutes || 120);
    setFormSessionLimitMins(c.sessionLimitMinutes || 45);
    setShowChildModal(true);
  };

  const handleSaveChildForm = () => {
    if (!formName.trim()) {
      addNotification('Name Required', 'Please enter a name for the child account.', 'error');
      return;
    }

    const freeSec = formFreeHours * 3600;

    if (editingChildId) {
      updateChildProfile({
        id: editingChildId,
        name: formName.trim(),
        avatar: formAvatar,
        dailyFreeTimeAllowanceSeconds: freeSec,
        dailyLimitMinutes: formDailyLimitMins,
        sessionLimitMinutes: formSessionLimitMins,
      });
    } else {
      addChildProfile({
        name: formName.trim(),
        avatar: formAvatar,
        dailyFreeTimeAllowanceSeconds: freeSec,
        dailyLimitMinutes: formDailyLimitMins,
        sessionLimitMinutes: formSessionLimitMins,
      });
    }

    setShowChildModal(false);
  };

  const handleChangePin = async () => {
    if (newPinInput.length < 4) {
      setPinMsg({ text: 'New PIN must be at least 4 digits', error: true });
      return;
    }

    const salt = await generateSalt();
    const hash = await hashPin(newPinInput, salt);

    updateSettings({
      ...settings,
      parentPinHash: hash,
      parentPinSalt: salt,
    });

    // Synchronize PIN to Android Hardware Encrypted Storage
    nativeBridge.setParentPin(newPinInput);

    setPinMsg({ text: 'Parent PIN updated successfully and saved to encrypted keystore!', error: false });
    setNewPinInput('');
  };

  const handleAddEmergencyContact = () => {
    if (!newContactName || !newContactPhone) return;
    const newContact: EmergencyContact = {
      id: `e_${Date.now()}`,
      name: newContactName,
      phone: newContactPhone,
      relation: newContactRelation,
    };
    const updated = [...(settings?.emergencyContacts || []), newContact];
    updateSettings({ ...settings, emergencyContacts: updated });
    setNewContactName('');
    setNewContactPhone('');
  };

  const handleDeleteEmergencyContact = (id: string) => {
    const updated = (settings?.emergencyContacts || []).filter((c) => c.id !== id);
    updateSettings({ ...settings, emergencyContacts: updated });
  };

  const handleClearAllData = () => {
    openPinModal(() => {
      clearAllChildData();
      window.location.reload();
    }, 'Authorize Complete Data Reset');
  };

  const categories = [
    { id: 'mode' as const, label: t.controlMode, icon: Clock, color: 'blue' as const },
    { id: 'children' as const, label: t.manageChildren, icon: Users, color: 'emerald' as const },
    { id: 'security' as const, label: 'PIN & Security', icon: Lock, color: 'indigo' as const },
    { id: 'protection' as const, label: 'Native Android Protection', icon: Cpu, color: 'blue' as const },
    { id: 'contacts' as const, label: 'Emergency Contacts', icon: PhoneCall, color: 'purple' as const },
    { id: 'system' as const, label: 'System & Language', icon: Globe, color: 'amber' as const },
    { id: 'about' as const, label: t.aboutMenu, icon: Info, color: 'slate' as const },
  ];

  // Render individual config sections
  const renderModeSection = () => (
    <div className="space-y-6">
      <div>
        <div className="flex items-center space-x-2.5 rtl:space-x-reverse mb-1">
          <AppIcon icon={Clock} size="sm" colorScheme="blue" shape="rounded" />
          <h3 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white">
            {t.controlMode}
          </h3>
        </div>
        <p className="text-xs text-slate-500 font-medium">{t.controlModeSubtitle}</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Free Mode */}
        <div
          onClick={() => handleModeChange('free')}
          className={`p-5 rounded-2xl border-2 cursor-pointer transition flex flex-col justify-between ${
            settings?.controlMode === 'free'
              ? 'bg-amber-50/70 dark:bg-amber-950/30 border-amber-500 text-slate-900 dark:text-white shadow-xs'
              : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 hover:border-amber-300'
          }`}
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-extrabold uppercase tracking-wider text-amber-700 dark:text-amber-300 bg-amber-100/80 dark:bg-amber-900/60 px-2.5 py-1 rounded-full">
              {t.freeMode}
            </span>
            {settings?.controlMode === 'free' && (
              <span className="w-6 h-6 rounded-full bg-amber-500 text-white flex items-center justify-center font-bold text-xs aspect-square">
                ✓
              </span>
            )}
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-300 font-medium leading-relaxed mb-4">
            {t.freeModeDesc}
          </p>
          <div className="text-[11px] text-amber-800 dark:text-amber-300 font-bold bg-amber-100/60 dark:bg-amber-900/40 p-2.5 rounded-xl border border-amber-200/60">
            {t.freeTimeResetNotice}
          </div>
        </div>

        {/* Scheduled Mode */}
        <div
          onClick={() => handleModeChange('scheduled')}
          className={`p-5 rounded-2xl border-2 cursor-pointer transition flex flex-col justify-between ${
            settings?.controlMode === 'scheduled'
              ? 'bg-blue-50/70 dark:bg-blue-950/30 border-blue-500 text-slate-900 dark:text-white shadow-xs'
              : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 hover:border-blue-300'
          }`}
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-extrabold uppercase tracking-wider text-blue-700 dark:text-blue-300 bg-blue-100/80 dark:bg-blue-900/60 px-2.5 py-1 rounded-full">
              {t.scheduledMode}
            </span>
            {settings?.controlMode === 'scheduled' && (
              <span className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-xs aspect-square">
                ✓
              </span>
            )}
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-300 font-medium leading-relaxed mb-4">
            {t.scheduledModeDesc}
          </p>
          <div className="text-[11px] text-blue-800 dark:text-blue-300 font-bold bg-blue-100/60 dark:bg-blue-900/40 p-2.5 rounded-xl border border-blue-200/60">
            Enforces weekly time slots matrix configured in Schedule tab.
          </div>
        </div>
      </div>
    </div>
  );

  const renderChildrenSection = () => (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <AppIcon icon={Users} size="sm" colorScheme="emerald" shape="rounded" />
            <h4 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white">
              {t.manageChildren}
            </h4>
          </div>
          <p className="text-xs text-slate-500 font-medium mt-0.5">{t.manageChildrenSubtitle}</p>
        </div>

        <button
          onClick={handleOpenAddModal}
          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs rounded-2xl shadow-xs transition flex items-center justify-center space-x-1.5 rtl:space-x-reverse shrink-0 min-h-[40px]"
        >
          <Plus className="w-4 h-4 shrink-0 aspect-square" />
          <span>{t.addChildProfile}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {childrenList.map((c) => {
          const isActive = c.id === activeChildId;
          const freeHours = Math.round((c.dailyFreeTimeAllowanceSeconds || 10800) / 3600);

          return (
            <div
              key={c.id}
              className={`p-4 rounded-2xl border transition flex flex-col justify-between ${
                isActive
                  ? 'bg-emerald-50/80 dark:bg-emerald-950/40 border-emerald-400 shadow-xs'
                  : 'bg-slate-50/90 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700 hover:border-slate-300'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3 rtl:space-x-reverse">
                    <span className="w-11 h-11 bg-white dark:bg-slate-800 rounded-2xl shadow-2xs border border-slate-100 dark:border-slate-700 flex items-center justify-center text-xl shrink-0 aspect-square">
                      {c.avatar || '👦'}
                    </span>
                    <div>
                      <div className="flex items-center space-x-2 rtl:space-x-reverse">
                        <h5 className="text-sm font-extrabold text-slate-900 dark:text-white">
                          {formatChildName(c.name)}
                        </h5>
                      </div>
                    </div>
                  </div>

                  {!isActive && (
                    <button
                      onClick={() => selectActiveChild(c.id)}
                      className="px-3 py-1.5 rounded-xl bg-white hover:bg-blue-50 border border-slate-300 text-blue-700 font-bold text-xs transition"
                    >
                      {t.selectActiveChild}
                    </button>
                  )}
                </div>

                {/* Customized Parameters Summary */}
                <div className="grid grid-cols-3 gap-2 py-2 px-3 bg-white/80 dark:bg-slate-900/60 rounded-xl border border-slate-200/60 dark:border-slate-700 mb-3 text-[11px]">
                  <div>
                    <span className="block text-[10px] font-bold text-slate-400 uppercase">
                      {t.freeMode}
                    </span>
                    <span className="font-extrabold text-slate-800 dark:text-slate-200">
                      {freeHours}h / day
                    </span>
                  </div>
                  <div>
                    <span className="block text-[10px] font-bold text-slate-400 uppercase">
                      Scheduled
                    </span>
                    <span className="font-extrabold text-slate-800 dark:text-slate-200">
                      {c.dailyLimitMinutes || 120}m
                    </span>
                  </div>
                  <div>
                    <span className="block text-[10px] font-bold text-slate-400 uppercase">
                      Session
                    </span>
                    <span className="font-extrabold text-slate-800 dark:text-slate-200">
                      {c.sessionLimitMinutes || 45}m
                    </span>
                  </div>
                </div>
              </div>

              {/* Account Actions */}
              <div className="flex items-center justify-end space-x-2 rtl:space-x-reverse pt-2 border-t border-slate-200/60 dark:border-slate-700">
                <button
                  onClick={() => handleOpenEditModal(c)}
                  className="px-3 py-1.5 bg-white dark:bg-slate-800 hover:bg-slate-100 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl transition flex items-center space-x-1 rtl:space-x-reverse"
                >
                  <Edit2 className="w-3.5 h-3.5 text-slate-500 shrink-0 aspect-square" />
                  <span>Edit</span>
                </button>

                <button
                  onClick={() => {
                    if (childrenList.length <= 1) {
                      addNotification('Cannot Delete', t.cannotDeletePrimaryChild, 'warning');
                      return;
                    }
                    setChildToDelete(c);
                  }}
                  disabled={childrenList.length <= 1}
                  title={childrenList.length <= 1 ? t.cannotDeletePrimaryChild : t.deleteChild}
                  className={`px-3 py-1.5 border font-bold text-xs rounded-xl transition flex items-center space-x-1 rtl:space-x-reverse ${
                    childrenList.length <= 1
                      ? 'bg-slate-100 dark:bg-slate-800 text-slate-400 border-slate-200 dark:border-slate-700 cursor-not-allowed'
                      : 'bg-white dark:bg-slate-800 hover:bg-red-50 dark:hover:bg-red-950/40 text-red-600 dark:text-red-400 border-red-200 dark:border-red-800/60'
                  }`}
                >
                  <Trash2 className="w-3.5 h-3.5 shrink-0 aspect-square" />
                  <span>{t.deleteChild}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );

  const renderSecuritySection = () => (
    <div className="space-y-6">
      {/* Change PIN */}
      <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl p-5">
        <div className="flex items-center space-x-2.5 rtl:space-x-reverse mb-3">
          <AppIcon icon={Lock} size="sm" colorScheme="indigo" shape="rounded" />
          <h3 className="text-sm font-extrabold text-slate-900 dark:text-white">Change Parent PIN</h3>
        </div>

        {pinMsg && (
          <div
            className={`p-3 rounded-xl text-xs mb-4 border ${
              pinMsg.error
                ? 'bg-red-50 border-red-200 text-red-700 font-bold'
                : 'bg-emerald-50 border-emerald-200 text-emerald-700 font-bold'
            }`}
          >
            {pinMsg.text}
          </div>
        )}

        <div className="space-y-3 mb-4">
          <label className="block text-xs font-bold text-slate-500">
            New Parent PIN (4-8 digits)
          </label>
          <input
            type="password"
            placeholder="Enter new 4-8 digit PIN"
            value={newPinInput}
            onChange={(e) => setNewPinInput(e.target.value)}
            className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-slate-800 dark:text-white font-mono focus:outline-none focus:border-blue-500"
          />
        </div>

        <button
          onClick={handleChangePin}
          className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-xs transition"
        >
          Update Parent PIN
        </button>
      </div>

      {/* Anti-Tamper Protection */}
      <div className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl p-5">
        <div className="flex items-center space-x-2.5 rtl:space-x-reverse mb-2">
          <AppIcon icon={ShieldCheck} size="sm" colorScheme="blue" shape="rounded" />
          <h3 className="text-sm font-extrabold text-slate-900 dark:text-white">
            Time Manipulation & Screen Security
          </h3>
        </div>
        <p className="text-xs text-slate-500 font-medium mb-4">
          Locks device on manual time clock change and guards PIN input screen with FLAG_SECURE.
        </p>

        <div className="space-y-2">
          <div className="flex items-center justify-between p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700">
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
              Anti-Time Tampering Lock
            </span>
            <input
              type="checkbox"
              checked={settings?.timeManipulationProtection}
              onChange={(e) =>
                updateSettings({ ...settings, timeManipulationProtection: e.target.checked })
              }
              className="w-4 h-4 accent-blue-600 rounded cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between p-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700">
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
              FLAG_SECURE Anti-Screen Recording
            </span>
            <input
              type="checkbox"
              checked={settings?.flagSecureEnabled}
              onChange={(e) =>
                updateSettings({ ...settings, flagSecureEnabled: e.target.checked })
              }
              className="w-4 h-4 accent-blue-600 rounded cursor-pointer"
            />
          </div>
        </div>
      </div>
    </div>
  );

  const renderProtectionSection = () => {
    const permStatus = nativeBridge.getNativePermissions();
    const isNative = nativeBridge.isNativeEnvironment();

    return (
      <div className="space-y-6">
        <div>
          <div className="flex items-center space-x-2.5 rtl:space-x-reverse mb-1">
            <AppIcon icon={Cpu} size="sm" colorScheme="blue" shape="rounded" />
            <h3 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white">
              Native Android Protection Engine
            </h3>
          </div>
          <p className="text-xs text-slate-500 font-medium">
            Status of native system services, foreground monitoring, and anti-bypass kiosk policies.
          </p>
        </div>

        {/* Runtime Environment Banner */}
        <div className={`p-4 rounded-2xl border flex items-center justify-between gap-3 ${
          isNative
            ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
            : 'bg-blue-50 dark:bg-blue-950/40 border-blue-200 dark:border-blue-800 text-blue-900 dark:text-blue-200'
        }`}>
          <div className="flex items-center space-x-3 rtl:space-x-reverse">
            <div className="w-9 h-9 rounded-xl bg-white/80 dark:bg-slate-900/80 border border-current/20 flex items-center justify-center font-bold text-sm shrink-0 aspect-square">
              {isNative ? '🤖' : '🌐'}
            </div>
            <div>
              <h4 className="text-xs font-extrabold">
                {isNative ? 'Native Android APK Execution Mode' : 'Web & Simulation Runtime Mode'}
              </h4>
              <p className="text-[11px] opacity-80 font-medium">
                {isNative
                  ? 'Connected to SafeShield Kotlin Native Services & Device Policy Manager.'
                  : 'Running responsive interface. Full native features activate inside the Android APK.'}
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              nativeBridge.restartMonitoringService();
              addNotification('Native Services Verified', 'Protection services synchronized.', 'success');
            }}
            className="px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white rounded-xl text-xs font-bold shadow-2xs hover:bg-slate-50 dark:hover:bg-slate-700 flex items-center space-x-1 rtl:space-x-reverse shrink-0"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Sync</span>
          </button>
        </div>

        {/* Protection Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {/* Usage Access */}
          <div className="p-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl flex flex-col justify-between">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200">Usage Access (App Tracking)</span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 border border-emerald-200">
                ACTIVE
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mb-3">Allows querying PACKAGE_USAGE_STATS for real-time app usage tracking.</p>
            <button
              onClick={() => nativeBridge.requestUsageAccess()}
              className="w-full py-1.5 bg-slate-200/80 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 rounded-xl text-[11px] font-bold text-slate-800 dark:text-slate-200"
            >
              Verify Permission
            </button>
          </div>

          {/* System Overlay */}
          <div className="p-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl flex flex-col justify-between">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200">System Alert Window (Overlay)</span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 border border-emerald-200">
                ACTIVE
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mb-3">Enables drawing the full-screen lock screen over blocked applications.</p>
            <button
              onClick={() => nativeBridge.requestOverlayPermission()}
              className="w-full py-1.5 bg-slate-200/80 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 rounded-xl text-[11px] font-bold text-slate-800 dark:text-slate-200"
            >
              Configure Overlay
            </button>
          </div>

          {/* Accessibility Service */}
          <div className="p-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl flex flex-col justify-between">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200">Accessibility App Guardian</span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 border border-emerald-200">
                ACTIVE
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mb-3">Intercepts window transitions in &lt;50ms before restricted apps can load.</p>
            <button
              onClick={() => nativeBridge.openAccessibilitySettings()}
              className="w-full py-1.5 bg-slate-200/80 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 rounded-xl text-[11px] font-bold text-slate-800 dark:text-slate-200"
            >
              Accessibility Settings
            </button>
          </div>

          {/* Device Admin */}
          <div className="p-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl flex flex-col justify-between">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200">Device Policy Admin</span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 border border-emerald-200">
                ACTIVE
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mb-3">Prevents unauthorized removal and enables system-level kiosk lockdown.</p>
            <button
              onClick={() => nativeBridge.requestDeviceAdmin()}
              className="w-full py-1.5 bg-slate-200/80 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 rounded-xl text-[11px] font-bold text-slate-800 dark:text-slate-200"
            >
              Admin Permissions
            </button>
          </div>

          {/* Battery Optimization Whitelist */}
          <div className="p-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl flex flex-col justify-between">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200">Battery Optimization (Doze Whitelist)</span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 border border-emerald-200">
                EXEMPTED
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mb-3">Prevents Android from killing the background monitoring service during deep sleep.</p>
            <button
              onClick={() => {
                nativeBridge.requestIgnoreBatteryOptimizations();
                addNotification('Battery Exemption', 'Opened battery optimization settings', 'info');
              }}
              className="w-full py-1.5 bg-slate-200/80 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 rounded-xl text-[11px] font-bold text-slate-800 dark:text-slate-200"
            >
              Exempt from Doze
            </button>
          </div>
        </div>

        {/* Lock Task Mode & Kiosk Enforcement */}
        <div className="p-4 bg-indigo-50/80 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/80 rounded-2xl">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <Lock className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <span className="text-xs font-bold text-slate-900 dark:text-white">Android Lock Task Mode (Kiosk Shell)</span>
            </div>
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
              nativeBridge.isInLockTaskMode() || nativeBridge.isKioskEnabled()
                ? 'bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 border-emerald-300'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-300'
            }`}>
              {nativeBridge.isInLockTaskMode() || nativeBridge.isKioskEnabled() ? 'LOCKED IN KIOSK' : 'STANDBY'}
            </span>
          </div>
          <p className="text-[11px] text-slate-600 dark:text-slate-300 mb-3">
            Locks the Android system navigation bar, status bar, and recent apps overview to prevent escaping SafeShield.
          </p>
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <button
              onClick={() => {
                nativeBridge.startLockTaskMode();
                addNotification('Kiosk Mode Activated', 'SafeShield is locked into foreground Lock Task mode.', 'success');
              }}
              className="flex-1 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition shadow-xs"
            >
              Start Lock Task Mode
            </button>
            <button
              onClick={() => {
                openPinModal(() => {
                  nativeBridge.stopLockTaskMode('1234');
                  addNotification('Kiosk Mode Exited', 'Parent unlocked system navigation.', 'info');
                }, 'Enter Parent PIN to Exit Kiosk Mode');
              }}
              className="px-4 py-2 bg-white dark:bg-slate-800 hover:bg-slate-100 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold transition"
            >
              Exit Kiosk Mode
            </button>
          </div>
        </div>

        {/* Device Owner ADB Box */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl text-slate-200">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <ShieldCheck className="w-4 h-4 text-blue-400" />
              <span className="text-xs font-bold text-white">Device Owner (Kiosk Lockdown Provisioning)</span>
            </div>
            <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
              nativeBridge.isDeviceOwner()
                ? 'bg-emerald-900/60 text-emerald-300 border-emerald-700 font-bold'
                : 'bg-blue-900/60 text-blue-300 border-blue-700'
            }`}>
              {nativeBridge.isDeviceOwner() ? 'PROVISIONED (DEVICE OWNER)' : 'ADB PROVISIONING READY'}
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mb-2">
            {nativeBridge.isDeviceOwner()
              ? 'SafeShield is actively verified as the Android Device Owner. System buttons and recent apps are completely enforced.'
              : 'To make SafeShield the supreme un-bypassable Device Owner on unmanaged Android setups, run via computer terminal:'}
          </p>
          {!nativeBridge.isDeviceOwner() && (
            <div className="relative group">
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-2.5 font-mono text-[11px] text-emerald-400 break-all select-all">
                adb shell dpm set-device-owner com.safeshield.parentalcontrol/.DeviceAdminReceiver
              </div>
            </div>
          )}
        </div>
      </div>
    );
  };

  const renderContactsSection = () => (
    <div className="space-y-5">
      <div>
        <div className="flex items-center space-x-2.5 rtl:space-x-reverse mb-1">
          <AppIcon icon={PhoneCall} size="sm" colorScheme="purple" shape="rounded" />
          <h3 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white">
            Emergency Contacts (Lock Mode)
          </h3>
        </div>
        <p className="text-xs text-slate-500 font-medium">
          Allowed phone numbers that child can call even when the device is locked.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {(settings?.emergencyContacts || []).map((contact) => (
          <div
            key={contact.id}
            className="p-3.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl flex items-center justify-between"
          >
            <div>
              <h4 className="text-xs font-extrabold text-slate-900 dark:text-white">{contact.name}</h4>
              <p className="text-[11px] font-mono font-bold text-blue-600">{contact.phone}</p>
              <span className="text-[10px] text-slate-400 font-medium">{contact.relation}</span>
            </div>
            <button
              onClick={() => handleDeleteEmergencyContact(contact.id)}
              className="p-2 text-red-500 hover:text-red-700 hover:bg-red-50 rounded-xl transition aspect-square"
            >
              <Trash2 className="w-4 h-4 shrink-0 aspect-square" />
            </button>
          </div>
        ))}
      </div>

      {/* Add New Contact Form */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-4 border-t border-slate-200 dark:border-slate-700">
        <input
          type="text"
          placeholder="Contact Name"
          value={newContactName}
          onChange={(e) => setNewContactName(e.target.value)}
          className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-800 dark:text-white focus:outline-none focus:border-blue-500"
        />
        <input
          type="text"
          placeholder="Phone Number"
          value={newContactPhone}
          onChange={(e) => setNewContactPhone(e.target.value)}
          className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-800 dark:text-white focus:outline-none focus:border-blue-500"
        />
        <button
          onClick={handleAddEmergencyContact}
          className="py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition flex items-center justify-center space-x-1 rtl:space-x-reverse min-h-[38px]"
        >
          <Plus className="w-4 h-4 shrink-0 aspect-square" />
          <span>Add Contact</span>
        </button>
      </div>
    </div>
  );

  const renderSystemSection = () => {
    const currentLangObj = SUPPORTED_LANGUAGES.find((l) => l.code === language) || SUPPORTED_LANGUAGES[0];
    return (
      <div className="space-y-6">
        {/* Language Card */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center space-x-3 rtl:space-x-reverse">
              <div className="w-12 h-12 rounded-2xl bg-amber-100 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800/60 flex items-center justify-center text-amber-600 dark:text-amber-400 shrink-0 text-2xl">
                {currentLangObj.flag}
              </div>
              <div>
                <div className="flex items-center space-x-2 rtl:space-x-reverse">
                  <h3 className="text-base font-extrabold text-slate-900 dark:text-white">{t.language}</h3>
                  <span className="text-[10px] font-bold px-2 py-0.5 bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 rounded-full border border-blue-200 dark:border-blue-800">
                    20 Available
                  </span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 font-medium mt-0.5">
                  Current: <strong className="text-slate-700 dark:text-slate-200">{currentLangObj.nativeName} ({currentLangObj.name})</strong> &bull; Universal RTL/LTR Localization
                </p>
              </div>
            </div>
            <button
              onClick={() => {
                touchParentActivity();
                setShowLanguageModal(true);
              }}
              className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-extrabold text-xs rounded-2xl shadow-xs transition flex items-center justify-center space-x-2 rtl:space-x-reverse shrink-0 min-h-[40px]"
            >
              <Globe className="w-4 h-4 shrink-0 aspect-square" />
              <span>Change Language</span>
            </button>
          </div>
        </div>

        {/* Danger Zone */}
      <div className="bg-red-50/70 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-2xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h4 className="text-xs sm:text-sm font-extrabold text-red-700 dark:text-red-300 flex items-center gap-1.5">
            <ShieldAlert className="w-4 h-4 shrink-0 aspect-square" />
            Wipe All Child Data
          </h4>
          <p className="text-[11px] text-slate-600 dark:text-slate-400 font-medium mt-0.5">
            Clears all statistics, logs, and reset profiles. Requires Parent PIN.
          </p>
        </div>
        <button
          onClick={handleClearAllData}
          className="px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl shadow-xs transition shrink-0 min-h-[40px]"
        >
          Reset All Data
        </button>
      </div>
    </div>
    );
  };

  const renderAboutSection = () => (
    <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-blue-950 text-white border border-slate-800 rounded-3xl p-6 shadow-sm space-y-4">
      <div className="flex items-center space-x-4 rtl:space-x-reverse">
        <AppLogo size="lg" showBadge />
        <div>
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            <h3 className="text-base font-extrabold">{APP_CONFIG.appName}</h3>
            <span className="bg-blue-500/20 text-blue-300 border border-blue-400/30 text-[10px] px-2 py-0.5 rounded-full font-mono font-bold">
              v{APP_CONFIG.versionName}
            </span>
          </div>
          <p className="text-xs text-blue-200 mt-0.5 font-medium">
            {APP_CONFIG.tagline} &bull; {t.developer}:{' '}
            <span className="text-white font-bold">{APP_CONFIG.developerName}</span>
          </p>
        </div>
      </div>

      <div className="pt-3 border-t border-white/10 flex justify-between items-center">
        <span className="text-xs text-slate-400">
          © {APP_CONFIG.copyrightYear} {APP_CONFIG.developerName}
        </span>
        <button
          onClick={() => setActiveTab('about')}
          className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-xs font-bold rounded-xl transition flex items-center space-x-1.5 rtl:space-x-reverse"
        >
          <span>Full About Screen</span>
          <ChevronRight className="w-4 h-4 rtl:rotate-180" />
        </button>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div
        onClick={touchParentActivity}
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-4 sm:p-6 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
      >
        <div className="flex items-center space-x-3 rtl:space-x-reverse">
          <AppIcon icon={Settings} size="md" colorScheme="blue" shape="rounded" />
          <div>
            <h2 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white">
              {t.settings}
            </h2>
            <p className="text-xs text-slate-500 font-medium">
              Administrative PIN, Screen Time Modes, and Account Protection
            </p>
          </div>
        </div>

        <button
          onClick={exitParentSession}
          className="w-full sm:w-auto px-4 py-2.5 bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-xs rounded-2xl shadow-xs transition flex items-center justify-center space-x-2 rtl:space-x-reverse shrink-0 min-h-[40px]"
        >
          <Check className="w-4 h-4 shrink-0 aspect-square" />
          <span>{t.exitParentSession}</span>
        </button>
      </div>

      {/* Adaptive Layout: Tablet Two-Pane vs Phone Single Column */}
      {isTablet ? (
        <div className="grid grid-cols-12 gap-6 items-start">
          {/* Left Pane: Categories List */}
          <div className="col-span-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-3 shadow-sm space-y-1.5">
            {categories.map((cat) => {
              const CatIcon = cat.icon;
              const isSelected = selectedCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`w-full flex items-center justify-between p-3 rounded-2xl font-bold text-xs sm:text-sm transition-all ${
                    isSelected
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center space-x-3 rtl:space-x-reverse min-w-0">
                    <CatIcon className="w-4 h-4 shrink-0 aspect-square" />
                    <span className="truncate">{cat.label}</span>
                  </div>
                  <ChevronRight
                    className={`w-4 h-4 shrink-0 rtl:rotate-180 ${
                      isSelected ? 'text-white' : 'text-slate-400'
                    }`}
                  />
                </button>
              );
            })}
          </div>

          {/* Right Pane: Selected Configuration */}
          <div className="col-span-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 shadow-sm min-h-[420px]">
            {selectedCategory === 'mode' && renderModeSection()}
            {selectedCategory === 'children' && renderChildrenSection()}
            {selectedCategory === 'security' && renderSecuritySection()}
            {selectedCategory === 'protection' && renderProtectionSection()}
            {selectedCategory === 'contacts' && renderContactsSection()}
            {selectedCategory === 'system' && renderSystemSection()}
            {selectedCategory === 'about' && renderAboutSection()}
          </div>
        </div>
      ) : (
        /* Phone Single-Column Layout: Accordion / Card sequence */
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
            {renderModeSection()}
          </div>
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
            {renderChildrenSection()}
          </div>
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
            {renderSecuritySection()}
          </div>
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
            {renderProtectionSection()}
          </div>
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
            {renderContactsSection()}
          </div>
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
            {renderSystemSection()}
          </div>
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 shadow-sm">
            {renderAboutSection()}
          </div>
        </div>
      )}

      {/* Child Account Customization Modal */}
      {showChildModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 select-none">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full p-5 sm:p-6 shadow-2xl animate-fadeIn text-slate-900 dark:text-slate-100 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800 mb-4">
              <div className="flex items-center space-x-2.5 rtl:space-x-reverse">
                <AppIcon icon={User} size="md" colorScheme="blue" shape="rounded" />
                <div>
                  <h3 className="text-sm font-extrabold">
                    {editingChildId ? t.editChildProfile : t.addChildProfile}
                  </h3>
                  <p className="text-xs text-slate-500 font-medium">
                    Configure customized limits & allowance
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowChildModal(false)}
                className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 font-bold text-sm aspect-square"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs font-bold text-slate-700 dark:text-slate-300">
              {/* Child Name */}
              <div>
                <label className="block text-slate-500 mb-1">{t.childName}</label>
                <input
                  type="text"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g. Sarah"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-extrabold text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              {/* Avatar & Age */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-500 mb-1">Avatar Emoji</label>
                  <div className="flex items-center space-x-1 rtl:space-x-reverse flex-wrap gap-1">
                    {['👦', '👧', '🧒', '🚀', '👑', '🦄', '⚽', '🎨'].map((emoji) => (
                      <button
                        key={emoji}
                        type="button"
                        onClick={() => setFormAvatar(emoji)}
                        className={`w-9 h-9 rounded-xl border flex items-center justify-center text-lg transition aspect-square ${
                          formAvatar === emoji
                            ? 'bg-blue-100 border-blue-500 shadow-2xs'
                            : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Free Time Allowance */}
              <div>
                <label className="block text-slate-500 mb-1">
                  {t.dailyFreeTimeAllowance} (Free Mode)
                </label>
                <select
                  value={formFreeHours}
                  onChange={(e) => setFormFreeHours(Number(e.target.value))}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-extrabold text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                >
                  <option value={1}>1 Hour (3,600 sec)</option>
                  <option value={2}>2 Hours (7,200 sec)</option>
                  <option value={3}>3 Hours (10,800 sec)</option>
                  <option value={4}>4 Hours (14,400 sec)</option>
                  <option value={5}>5 Hours (18,000 sec)</option>
                  <option value={6}>6 Hours (21,600 sec)</option>
                </select>
              </div>

              {/* Scheduled Mode Daily Limit & Session Limit */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-500 mb-1">{t.scheduledDailyLimit}</label>
                  <select
                    value={formDailyLimitMins}
                    onChange={(e) => setFormDailyLimitMins(Number(e.target.value))}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-extrabold text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value={30}>30 Minutes</option>
                    <option value={60}>60 Minutes (1 hr)</option>
                    <option value={90}>90 Minutes (1.5 hrs)</option>
                    <option value={120}>120 Minutes (2 hrs)</option>
                    <option value={180}>180 Minutes (3 hrs)</option>
                    <option value={240}>240 Minutes (4 hrs)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-500 mb-1">{t.sessionLimit}</label>
                  <select
                    value={formSessionLimitMins}
                    onChange={(e) => setFormSessionLimitMins(Number(e.target.value))}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-extrabold text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                  >
                    <option value={15}>15 Minutes</option>
                    <option value={30}>30 Minutes</option>
                    <option value={45}>45 Minutes</option>
                    <option value={60}>60 Minutes</option>
                    <option value={90}>90 Minutes</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end space-x-3 rtl:space-x-reverse pt-4 mt-4 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => setShowChildModal(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl transition"
              >
                {t.close}
              </button>
              <button
                onClick={handleSaveChildForm}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs rounded-2xl shadow-xs transition"
              >
                Save Child Profile
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Child Account Confirmation Modal */}
      {childToDelete && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-md p-5 sm:p-6 shadow-2xl text-slate-900 dark:text-white">
            <div className="flex items-center space-x-3 rtl:space-x-reverse mb-4">
              <div className="w-12 h-12 rounded-2xl bg-red-100 dark:bg-red-950/50 border border-red-200 dark:border-red-800/60 flex items-center justify-center text-red-600 dark:text-red-400 shrink-0">
                <Trash2 className="w-6 h-6 shrink-0 aspect-square" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                  {t.confirmDeleteChildTitle}
                </h3>
              </div>
            </div>

            <div className="bg-slate-50 dark:bg-slate-800/60 rounded-2xl p-4 border border-slate-200/80 dark:border-slate-700 mb-4">
              <div className="flex items-center space-x-3 rtl:space-x-reverse mb-2">
                <span className="w-10 h-10 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-center text-xl shrink-0">
                  {childToDelete.avatar || '👦'}
                </span>
                <div>
                  <h4 className="text-sm font-extrabold text-slate-900 dark:text-white">
                    {formatChildName(childToDelete.name)}
                  </h4>
                  {childToDelete.id === activeChildId && (
                    <span className="inline-block mt-0.5 text-[10px] font-bold px-2 py-0.5 bg-blue-100 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 rounded-full border border-blue-200 dark:border-blue-800">
                      {t.activeChild}
                    </span>
                  )}
                </div>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300 font-medium leading-relaxed">
                {t.confirmDeleteChildDesc} <strong>{formatChildName(childToDelete.name)}</strong>? {t.confirmDeleteChildWarning}
              </p>
            </div>

            <div className="flex items-center justify-end space-x-2.5 rtl:space-x-reverse pt-2">
              <button
                type="button"
                onClick={() => setChildToDelete(null)}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl transition"
              >
                {t.cancel}
              </button>
              <button
                type="button"
                onClick={() => {
                  const idToDelete = childToDelete.id;
                  setChildToDelete(null);
                  deleteChildProfile(idToDelete);
                }}
                className="px-4 py-2.5 bg-red-600 hover:bg-red-700 active:bg-red-800 text-white font-extrabold text-xs rounded-xl shadow-xs transition flex items-center space-x-1.5 rtl:space-x-reverse"
              >
                <Trash2 className="w-3.5 h-3.5 shrink-0 aspect-square" />
                <span>{t.confirmDeleteChildBtn}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Language Selection Modal */}
      <LanguageModal isOpen={showLanguageModal} onClose={() => setShowLanguageModal(false)} />
    </div>
  );
};
