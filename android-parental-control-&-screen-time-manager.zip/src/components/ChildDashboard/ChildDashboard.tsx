import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { translations } from '../../data/translations';
import { formatChildName } from '../../utils/locale';
import { useResponsiveLayout } from '../../utils/useResponsiveLayout';
import { AppIcon } from '../common/AppIcon';
import { CountdownTimer, ActionButton } from '../common/ResponsiveComponents';
import {
  Smartphone,
  Clock,
  PlusCircle,
  CheckCircle,
  ExternalLink,
  ShieldCheck,
  Send,
  X,
  Lock,
  Sparkles,
  GraduationCap,
  AlertCircle,
  BookOpen,
  Key,
  Unlock,
} from 'lucide-react';

export const ChildDashboard: React.FC = () => {
  const {
    child,
    session,
    settings,
    remainingDailySeconds,
    remainingSessionSeconds,
    apps,
    language,
    logEvent,
    isSmartBlockActiveNow,
    activeSmartBlockMode,
    isAppRestrictedBySmartBlock,
    getSmartBlockRestrictionDetails,
    openPinModal,
    setRole,
    setActiveTab,
    touchParentActivity,
    addNotification,
    getActiveUsageMode,
    isAppAllowedInCurrentMode,
  } = useApp();

  const t = translations[language];
  const { isTablet, isCompact } = useResponsiveLayout();
  const isFreeMode = settings?.controlMode === 'free';
  const activeUsageMode = getActiveUsageMode();

  const [showRequestModal, setShowRequestModal] = useState(false);
  const [requestReason, setRequestReason] = useState('Need 15 more mins for homework');
  const [requestSent, setRequestSent] = useState(false);
  const [blockedAlertApp, setBlockedAlertApp] = useState<string | null>(null);

  const handleParentUnlock = () => {
    touchParentActivity();
    openPinModal(() => {
      setRole('parent');
      setActiveTab('overview');
      addNotification('Parent Access Granted', 'Switched to Parent Dashboard.', 'info');
      logEvent('parent_unlock', 'Parent unlocked device from play mode screen');
    }, t.enterParentPin);
  };

  const allowedAppsList = apps.filter((a) => isAppAllowedInCurrentMode(a));
  const isExtraTimeActive =
    session.extraTimeEndTimestamp !== null && session.extraTimeEndTimestamp > Date.now();
  const activeRemainingSec = isExtraTimeActive
    ? remainingDailySeconds
    : isFreeMode
    ? remainingDailySeconds
    : Math.min(remainingDailySeconds, remainingSessionSeconds);

  const extraEndTimeStr = session.extraTimeEndTimestamp
    ? new Date(session.extraTimeEndTimestamp).toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
      })
    : '';

  const dailyAllowanceSec = isFreeMode
    ? child.dailyFreeTimeAllowanceSeconds || 10800
    : child.dailyLimitMinutes * 60;
  const usedTodaySec = isFreeMode
    ? session.freeModeUsedSecondsToday || 0
    : session.elapsedTodayMinutes * 60;

  const handleLaunchApp = (appName: string, packageName: string, isRestricted: boolean) => {
    if (isRestricted) {
      setBlockedAlertApp(appName);
      logEvent(
        'bypass_attempt',
        `Child attempted to open restricted Smart Block app: ${appName} (${packageName})`
      );
      return;
    }
    logEvent('session_started', `Child launched allowed app: ${appName} (${packageName})`);
  };

  const handleSendRequest = () => {
    setRequestSent(true);
    setTimeout(() => {
      setRequestSent(false);
      setShowRequestModal(false);
    }, 2000);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-3.5 sm:space-y-4 pb-6 select-none">
      {/* Welcome Card (Responsive on phone vs tablet) */}
      <div className="bg-gradient-to-br from-blue-600 via-indigo-600 to-slate-900 border border-blue-500/30 rounded-2xl sm:rounded-3xl p-4 sm:p-5 md:p-6 shadow-sm text-white relative overflow-hidden">
        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-1 min-w-0">
            <div className="inline-flex items-center space-x-1.5 rtl:space-x-reverse bg-white/20 backdrop-blur-md px-2.5 py-0.5 rounded-full text-[11px] font-bold">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-300 shrink-0 aspect-square" />
              <span>{isFreeMode ? t.freeModeActive : t.scheduledModeActive}</span>
            </div>
            <h2 className="text-lg sm:text-2xl font-black tracking-tight truncate">
              {t.hello}, {formatChildName(child.name)}! {child.avatar || '👦'}
            </h2>
            <p className="text-blue-100 text-xs max-w-lg font-medium leading-normal">
              {isFreeMode ? t.freeModeDesc : t.scheduledModeDesc}
            </p>
          </div>

          <div className="shrink-0 self-start sm:self-center flex flex-wrap sm:flex-col gap-2">
            <button
              onClick={() => setShowRequestModal(true)}
              className="px-3.5 py-2 bg-white hover:bg-blue-50 text-blue-800 font-extrabold rounded-xl shadow-xs transition flex items-center space-x-1.5 rtl:space-x-reverse text-xs min-h-[38px]"
            >
              <PlusCircle className="w-3.5 h-3.5 text-blue-600 shrink-0 aspect-square" />
              <span>{t.requestExtraTime}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Usage Mode Banner */}
      {activeUsageMode && activeUsageMode.id !== 'normal' && (
        <div className="bg-gradient-to-r from-blue-500 to-indigo-500 text-white rounded-2xl p-3 sm:p-4 shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center space-x-2.5 rtl:space-x-reverse">
            <div className="w-9 h-9 bg-white/20 backdrop-blur-md rounded-xl flex items-center justify-center shrink-0 aspect-square text-lg">
              {activeUsageMode.icon}
            </div>
            <div>
              <div className="flex items-center space-x-1.5 rtl:space-x-reverse flex-wrap">
                <h3 className="text-xs sm:text-sm font-extrabold">{activeUsageMode.name}</h3>
                <span className="text-[9px] font-bold px-1.5 py-0.5 bg-white/25 rounded-full uppercase">
                  {t.currentMode}
                </span>
              </div>
              <p className="text-[11px] text-blue-100 font-medium mt-0.5">
                {activeUsageMode.description}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Smart Block 2.0 Alert Banner for Child */}
      {isSmartBlockActiveNow && activeSmartBlockMode && (
        <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 text-white rounded-2xl p-3 sm:p-4 shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border border-amber-400/30">
          <div className="flex items-center space-x-2.5 rtl:space-x-reverse">
            <div className="w-10 h-10 bg-white/20 backdrop-blur-md rounded-xl flex items-center justify-center shrink-0 aspect-square text-2xl">
              {activeSmartBlockMode.icon || '📚'}
            </div>
            <div>
              <div className="flex items-center space-x-1.5 rtl:space-x-reverse flex-wrap">
                <h3 className="text-xs sm:text-sm font-extrabold">{activeSmartBlockMode.name} Active</h3>
                <span className="text-[9px] font-mono font-bold px-2 py-0.5 bg-white/25 rounded-full">
                  {activeSmartBlockMode.startTime} — {activeSmartBlockMode.endTime}
                </span>
              </div>
              <p className="text-[11px] text-amber-100 font-medium mt-0.5">
                {activeSmartBlockMode.description || 'Scheduled focus window. Distraction apps are temporarily paused.'}
              </p>
            </div>
          </div>

          <div className="text-[10px] font-black bg-white/25 px-3 py-1 rounded-xl self-end sm:self-center shrink-0 flex items-center gap-1 border border-white/20">
            <span>{activeSmartBlockMode.icon}</span>
            <span>Active until {activeSmartBlockMode.endTime}</span>
          </div>
        </div>
      )}

      {/* Main Responsive Countdown Timer Card */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl sm:rounded-3xl p-4 sm:p-6 shadow-xs text-center">
        <CountdownTimer
          seconds={activeRemainingSec}
          label={
            isExtraTimeActive
              ? 'Active Extra Time Session'
              : isFreeMode
              ? t.remainingToday
              : t.remainingSession
          }
          variant={activeRemainingSec < 300 ? 'danger' : activeRemainingSec < 900 ? 'warning' : 'primary'}
          size={isTablet ? 'lg' : 'adaptive'}
        />

        {isExtraTimeActive && (
          <div className="inline-block mt-2 px-2.5 py-0.5 bg-emerald-50 text-emerald-700 rounded-full text-[11px] font-bold border border-emerald-200">
            Extra Time Granted &bull; Active until {extraEndTimeStr}
          </div>
        )}

        {/* Free Mode Progress Bar */}
        {isFreeMode && (
          <div className="max-w-md mx-auto mt-3 space-y-1">
            <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2.5 overflow-hidden border border-slate-200 dark:border-slate-700">
              <div
                className="bg-blue-600 h-full rounded-full transition-all duration-500"
                style={{
                  width: `${Math.min(
                    100,
                    Math.max(0, (usedTodaySec / Math.max(1, dailyAllowanceSec)) * 100)
                  )}%`,
                }}
              />
            </div>
            <div className="flex justify-between text-[10px] text-slate-500 font-bold px-1">
              <span>Used: {Math.round(usedTodaySec / 60)} mins</span>
              <span>Total Bank: {Math.round(dailyAllowanceSec / 60)} mins</span>
            </div>
          </div>
        )}

        <p className="text-[11px] text-slate-400 font-medium mt-3">
          Device automatically enters LOCK MODE when this countdown reaches zero.
        </p>

        {/* Parent Access Bar */}
        <div className="mt-4 pt-3.5 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-2.5 text-start">
          <div className="flex items-center space-x-2 rtl:space-x-reverse w-full sm:w-auto">
            <div className="w-8 h-8 rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 flex items-center justify-center text-amber-600 dark:text-amber-400 shrink-0 aspect-square">
              <Key className="w-3.5 h-3.5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200">Parent Controls</h4>
              <p className="text-[10px] text-slate-500 dark:text-slate-400 font-medium">Switch to parental dashboard or adjust rules</p>
            </div>
          </div>
          <button
            onClick={handleParentUnlock}
            className="w-full sm:w-auto px-3.5 py-2 bg-slate-900 hover:bg-slate-800 active:bg-slate-950 dark:bg-slate-100 dark:hover:bg-white text-white dark:text-slate-900 font-extrabold rounded-xl text-xs transition flex items-center justify-center space-x-1.5 rtl:space-x-reverse shadow-2xs min-h-[38px] shrink-0"
          >
            <Lock className="w-3 h-3" />
            <span>Parent Unlock</span>
          </button>
        </div>
      </div>

      {/* Allowed Apps Grid (Adaptive columns: 2 on small phone, 3 on standard phone, 4-6 on tablet) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl sm:rounded-3xl p-3.5 sm:p-5 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
            <Smartphone className="w-4 h-4 text-blue-600 shrink-0 aspect-square" />
            <span>{t.allowedApps} ({allowedAppsList.length})</span>
          </h3>
          {isSmartBlockActiveNow && (
            <span className="text-[10px] font-bold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-lg flex items-center gap-1">
              <Sparkles className="w-3 h-3 shrink-0 aspect-square" />
              <span>Smart Block Active</span>
            </span>
          )}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2.5 sm:gap-3">
          {allowedAppsList.map((app) => {
            const isRestricted = isAppRestrictedBySmartBlock(app);
            const isEdu = app.category === 'educational';

            return (
              <button
                key={app.packageName}
                onClick={() => handleLaunchApp(app.appName, app.packageName, isRestricted)}
                className={`p-3 border rounded-xl text-center transition group flex flex-col items-center justify-between shadow-2xs relative overflow-hidden min-h-[105px] sm:min-h-[115px] ${
                  isRestricted
                    ? 'bg-amber-50/60 border-amber-200/80 hover:border-amber-300 opacity-90'
                    : isEdu
                    ? 'bg-emerald-50/40 border-emerald-200 hover:border-emerald-300 hover:bg-emerald-50/70'
                    : 'bg-slate-50 dark:bg-slate-800/60 hover:bg-blue-50/50 dark:hover:bg-slate-800 border-slate-200/80 dark:border-slate-700/80'
                }`}
              >
                {/* Educational or Restricted Tag */}
                {isEdu && (
                  <span className="absolute top-1.5 right-1.5 rtl:right-auto rtl:left-1.5 text-[8px] font-extrabold px-1 py-0.5 rounded-md bg-emerald-100 text-emerald-800 flex items-center gap-0.5">
                    <GraduationCap className="w-2 h-2 shrink-0 aspect-square" />
                    EDU
                  </span>
                )}
                {isRestricted && (
                  <span className="absolute top-1.5 right-1.5 rtl:right-auto rtl:left-1.5 text-[8px] font-extrabold px-1 py-0.5 rounded-md bg-amber-200 text-amber-900 flex items-center gap-0.5">
                    <Lock className="w-2 h-2 shrink-0 aspect-square" />
                    PAUSED
                  </span>
                )}

                {/* Standardized 1:1 App Icon Component */}
                <div className="my-0.5">
                  <AppIcon
                    icon={app.icon}
                    text={app.appName.charAt(0)}
                    size="md"
                    colorScheme={isRestricted ? 'amber' : isEdu ? 'emerald' : 'blue'}
                    shape="squircle"
                    className="group-hover:scale-105 transition-transform"
                  />
                </div>

                <h4 className="text-[11px] sm:text-xs font-bold text-slate-900 dark:text-white leading-tight line-clamp-1 w-full text-center">
                  {app.appName}
                </h4>

                {isRestricted ? (
                  <span className="text-[9px] text-amber-700 font-bold mt-0.5 flex items-center gap-0.5 truncate">
                    <Lock className="w-2.5 h-2.5 shrink-0 aspect-square" />
                    Study Hours
                  </span>
                ) : (
                  <span className="text-[9px] text-emerald-600 font-bold mt-0.5 flex items-center gap-0.5 truncate">
                    <ExternalLink className="w-2.5 h-2.5 shrink-0 aspect-square" />
                    Launch
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Blocked App Alert Modal */}
      {blockedAlertApp && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-sm p-6 shadow-2xl text-slate-900 dark:text-white relative text-center space-y-3">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-100 dark:bg-amber-950/70 border border-amber-200 dark:border-amber-800 flex items-center justify-center text-3xl shadow-xs">
              {activeSmartBlockMode?.icon || '🔒'}
            </div>
            <div>
              <span className="px-2.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-300 text-[10px] font-black uppercase tracking-wider">
                {activeSmartBlockMode ? activeSmartBlockMode.name : 'Smart Block Active'}
              </span>
              <h3 className="text-base font-black mt-1.5">{blockedAlertApp} is Restricted</h3>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 font-medium leading-relaxed">
              {activeSmartBlockMode
                ? `This app is paused during ${activeSmartBlockMode.name} (${activeSmartBlockMode.startTime} — ${activeSmartBlockMode.endTime}). Focus on study, educational tools, or family time!`
                : t.smartBlockNoticeChild}
            </p>
            <div className="pt-2">
              <button
                onClick={() => setBlockedAlertApp(null)}
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white font-black rounded-xl text-xs transition shadow-xs"
              >
                Understood
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Request Extra Time Modal */}
      {showRequestModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-md p-6 shadow-xl text-slate-900 relative">
            <button
              onClick={() => setShowRequestModal(false)}
              className="absolute top-4 right-4 rtl:right-auto rtl:left-4 text-slate-400 hover:text-slate-600 p-1.5 rounded-full hover:bg-slate-100 transition min-w-[36px] min-h-[36px] flex items-center justify-center aspect-square"
            >
              <X className="w-5 h-5 shrink-0 aspect-square" />
            </button>

            <h3 className="text-lg font-extrabold mb-1">{t.requestExtraTime}</h3>
            <p className="text-xs text-slate-500 font-medium mb-4">
              Send a request to your parent for 15 additional minutes
            </p>

            {requestSent ? (
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-center text-emerald-700 text-xs font-bold">
                {t.extraTimeRequested}
              </div>
            ) : (
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1">Reason</label>
                  <input
                    type="text"
                    value={requestReason}
                    onChange={(e) => setRequestReason(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 focus:outline-none focus:border-blue-500 font-medium"
                  />
                </div>
                <button
                  onClick={handleSendRequest}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-2xl shadow-xs transition flex items-center justify-center space-x-2 rtl:space-x-reverse min-h-[48px]"
                >
                  <Send className="w-4 h-4 shrink-0 aspect-square" />
                  <span>Send Request to Parent</span>
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
