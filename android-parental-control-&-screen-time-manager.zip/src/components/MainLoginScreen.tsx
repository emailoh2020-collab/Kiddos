import React from 'react';
import { useApp } from '../context/AppContext';
import { translations } from '../data/translations';
import { formatChildName } from '../utils/locale';
import { Shield } from 'lucide-react';
import { AppLogo } from './AppLogo';

export const MainLoginScreen: React.FC = () => {
  const {
    language,
    childrenList,
    setRole,
    selectActiveChild,
    setAccountSelected,
    openPinModal,
    setActiveTab,
  } = useApp();
  const t = translations[language];

  const handleSelectParent = () => {
    openPinModal(() => {
      setRole('parent');
      setAccountSelected(true);
    }, t.parentAccess);
  };

  const handleLaunchChild = (childId: string) => {
    selectActiveChild(childId);
    setRole('child');
    setAccountSelected(true);
  };

  // Total users = All child accounts + Parent account
  const totalUsers = childrenList.length + 1;

  // Grid layout according to user count:
  // 1 user -> 1 col
  // 2 users -> 2 cols
  // 3 users -> 3 cols
  // 4 users -> 3 cols, 2 rows (and so on)
  const getGridClass = () => {
    if (totalUsers <= 1) {
      return 'grid grid-cols-1 gap-3 sm:gap-4 max-w-xs mx-auto';
    }
    if (totalUsers === 2) {
      return 'grid grid-cols-2 gap-3.5 sm:gap-4 max-w-md mx-auto';
    }
    if (totalUsers === 3) {
      return 'grid grid-cols-3 gap-3 sm:gap-4 max-w-lg mx-auto';
    }
    // 4 or more users: 3 columns with wrapping rows
    return 'grid grid-cols-3 gap-3 sm:gap-4 max-w-xl mx-auto';
  };

  return (
    <div
      dir={language === 'ar' ? 'rtl' : 'ltr'}
      className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 select-none animate-in fade-in duration-300 overflow-y-auto"
    >
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl sm:rounded-3xl w-full max-w-lg p-4.5 sm:p-6 shadow-2xl text-slate-900 dark:text-slate-100 my-auto relative space-y-4.5 sm:space-y-6">
        
        {/* Header Logo */}
        <div className="text-center space-y-1">
          <div className="flex justify-center mb-0.5">
            <AppLogo size="lg" showBadge />
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white tracking-tight">
            SafeShield
          </h1>
        </div>

        {/* User Selection Dynamic Grid */}
        <div className={getGridClass()}>
          {/* Child User Accounts */}
          {childrenList.map((child) => (
            <button
              key={child.id}
              onClick={() => handleLaunchChild(child.id)}
              className="p-3 sm:p-4 rounded-xl sm:rounded-2xl bg-slate-50 hover:bg-blue-50/70 dark:bg-slate-800/60 dark:hover:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 hover:border-blue-500 dark:hover:border-blue-500 transition-all flex flex-col items-center justify-center text-center group shadow-xs hover:shadow-sm min-h-[105px] sm:min-h-[120px]"
            >
              <div className="w-11 h-11 sm:w-13 sm:h-13 rounded-xl sm:rounded-2xl bg-white dark:bg-slate-700/80 border border-slate-200 dark:border-slate-600 flex items-center justify-center text-2xl sm:text-3xl shadow-xs group-hover:scale-105 transition-transform duration-200 shrink-0 aspect-square">
                {child.avatar || '👦'}
              </div>
              <div className="mt-2 w-full">
                <h3 className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition truncate px-1">
                  {formatChildName(child.name)}
                </h3>
              </div>
            </button>
          ))}

          {/* Parent Account */}
          <button
            onClick={handleSelectParent}
            className="p-3 sm:p-4 rounded-xl sm:rounded-2xl bg-slate-900 hover:bg-slate-800 dark:bg-slate-800 dark:hover:bg-slate-700 border-2 border-slate-800 hover:border-blue-500 transition-all flex flex-col items-center justify-center text-center group shadow-xs hover:shadow-md text-white min-h-[105px] sm:min-h-[120px]"
          >
            <div className="w-11 h-11 sm:w-13 sm:h-13 rounded-xl sm:rounded-2xl bg-blue-600/30 border border-blue-400/30 text-blue-400 flex items-center justify-center group-hover:scale-105 transition-transform duration-200 shadow-xs shrink-0 aspect-square">
              <Shield className="w-5 h-5 sm:w-6 sm:h-6 shrink-0 aspect-square" />
            </div>
            <div className="mt-2 w-full">
              <h3 className="font-extrabold text-xs sm:text-sm text-white truncate px-1">
                {t.parentDashboard || 'Parent'}
              </h3>
            </div>
          </button>
        </div>

        {/* Footer: Version, Copyright, About */}
        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-400 gap-1.5">
          <div>Version 2.4.0 • Build 2026.08</div>
          <div className="flex items-center space-x-2.5 rtl:space-x-reverse">
            <span>© SafeShield</span>
            <span>•</span>
            <button
              onClick={() => {
                setAccountSelected(true);
                setRole('parent');
                setActiveTab('about');
              }}
              className="hover:text-blue-600 dark:hover:text-blue-400 font-bold underline transition"
            >
              {t.aboutMenu || 'About'}
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
