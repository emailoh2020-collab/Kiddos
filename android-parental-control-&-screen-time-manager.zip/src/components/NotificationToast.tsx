import React from 'react';
import { useApp } from '../context/AppContext';
import { ShieldAlert, AlertTriangle, Info, CheckCircle, X } from 'lucide-react';

export const NotificationToast: React.FC = () => {
  const { notifications, dismissNotification } = useApp();

  if (notifications.length === 0) return null;

  return (
    <div className="fixed bottom-4 right-4 rtl:right-auto rtl:left-4 z-50 flex flex-col space-y-2.5 max-w-sm w-full pointer-events-none p-2">
      {notifications.map(n => {
        let bgColor = 'bg-white border-slate-200 text-slate-900 shadow-xl';
        let barColor = 'bg-blue-600';
        let Icon = Info;
        let iconColor = 'text-blue-600';

        if (n.type === 'warning') {
          bgColor = 'bg-amber-50 border-amber-200 text-amber-900 shadow-xl';
          barColor = 'bg-amber-600';
          Icon = AlertTriangle;
          iconColor = 'text-amber-600';
        } else if (n.type === 'error') {
          bgColor = 'bg-red-50 border-red-200 text-red-900 shadow-xl';
          barColor = 'bg-red-600';
          Icon = ShieldAlert;
          iconColor = 'text-red-600';
        } else if (n.type === 'success') {
          bgColor = 'bg-emerald-50 border-emerald-200 text-emerald-900 shadow-xl';
          barColor = 'bg-emerald-600';
          Icon = CheckCircle;
          iconColor = 'text-emerald-600';
        }

        return (
          <div
            key={n.id}
            className={`pointer-events-auto rounded-2xl border shadow-xl overflow-hidden flex flex-col relative animate-in slide-in-from-bottom duration-300 ${bgColor}`}
          >
            <div className="p-4 flex items-start space-x-3 rtl:space-x-reverse">
              <Icon className={`w-5 h-5 mt-0.5 shrink-0 ${iconColor}`} />
              <div className="flex-1 min-w-0">
                <h4 className="font-extrabold text-xs sm:text-sm tracking-tight">{n.title}</h4>
                <p className="text-xs opacity-90 mt-0.5 font-medium leading-snug break-words">{n.message}</p>
              </div>
              <button
                onClick={() => dismissNotification(n.id)}
                className="p-1 rounded-lg hover:bg-slate-200/50 opacity-70 hover:opacity-100 transition shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* 5-second transient timer progress bar */}
            <div className="w-full bg-slate-200/50 h-1 overflow-hidden">
              <div
                className={`h-full ${barColor}`}
                style={{
                  animation: 'toast-timer 5s linear forwards',
                }}
              />
            </div>
          </div>
        );
      })}

      <style>{`
        @keyframes toast-timer {
          from { width: 100%; }
          to { width: 0%; }
        }
      `}</style>
    </div>
  );
};
