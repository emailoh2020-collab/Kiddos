import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { translations } from '../data/translations';
import {
  Wand2,
  CheckCircle2,
  Lock,
  User,
  Clock,
  Calendar,
  Smartphone,
  ShieldAlert,
  PhoneCall,
  Sparkles,
  ChevronRight,
  ChevronLeft,
  X,
} from 'lucide-react';
import { generateSalt, hashPin } from '../utils/crypto';

export const SetupWizard: React.FC = () => {
  const {
    showSetupWizard,
    setShowSetupWizard,
    settings,
    updateSettings,
    child,
    updateChildProfile,
    language,
    forceLockDevice,
  } = useApp();

  const [step, setStep] = useState(1);
  const [pinInput, setPinInput] = useState('');
  const [pinConfirm, setPinConfirm] = useState('');
  const [pinError, setPinError] = useState<string | null>(null);

  const [childName, setChildName] = useState(child.name);
  const [dailyLimitMins, setDailyLimitMins] = useState(child.dailyLimitMinutes);
  const [sessionLimitMins, setSessionLimitMins] = useState(child.sessionLimitMinutes);

  if (!showSetupWizard) return null;

  const handlePinSubmit = async () => {
    if (pinInput.length < 4) {
      setPinError('PIN must be at least 4 digits');
      return;
    }
    if (pinInput !== pinConfirm) {
      setPinError('PINs do not match!');
      return;
    }

    const salt = await generateSalt();
    const hash = await hashPin(pinInput, salt);

    updateSettings({
      ...settings,
      parentPinHash: hash,
      parentPinSalt: salt,
    });

    setPinError(null);
    setStep(2);
  };

  const handleChildProfileSubmit = () => {
    updateChildProfile({
      ...child,
      name: childName,
      dailyLimitMinutes: dailyLimitMins,
      sessionLimitMinutes: sessionLimitMins,
    });
    setStep(3);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-2xl p-6 shadow-xl text-slate-900 relative">
        <button
          onClick={() => setShowSetupWizard(false)}
          className="absolute top-4 right-4 rtl:right-auto rtl:left-4 text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-slate-100 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Wizard Progress Bar */}
        <div className="mb-6">
          <div className="flex items-center justify-between text-xs text-slate-500 font-bold mb-2">
            <span className="font-bold text-blue-600 flex items-center gap-1">
              <Wand2 className="w-4 h-4 text-blue-600" />
              Setup Wizard
            </span>
            <span>Step {step} of 10</span>
          </div>
          <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
            <div
              className="bg-blue-600 h-full transition-all duration-300"
              style={{ width: `${(step / 10) * 100}%` }}
            />
          </div>
        </div>

        {/* STEP 1: Set Parent PIN */}
        {step === 1 && (
          <div>
            <div className="flex items-center space-x-3 rtl:space-x-reverse mb-4">
              <div className="p-3 bg-blue-50 text-blue-600 rounded-xl border border-blue-200">
                <Lock className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">Step 1: Set Secure Parent PIN</h3>
                <p className="text-xs text-slate-500 font-medium">Protects administrative settings and lock screen</p>
              </div>
            </div>

            {pinError && (
              <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs font-bold">
                {pinError}
              </div>
            )}

            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">New Parent PIN (4-8 digits)</label>
                <input
                  type="password"
                  value={pinInput}
                  onChange={e => setPinInput(e.target.value)}
                  placeholder="e.g. 1234"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:border-blue-500 font-medium"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">Confirm Parent PIN</label>
                <input
                  type="password"
                  value={pinConfirm}
                  onChange={e => setPinConfirm(e.target.value)}
                  placeholder="Re-enter PIN"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:border-blue-500 font-medium"
                />
              </div>
            </div>

            <button
              onClick={handlePinSubmit}
              className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-xs transition flex items-center justify-center space-x-2 rtl:space-x-reverse text-xs"
            >
              <span>Save PIN & Next</span>
              <ChevronRight className="w-5 h-5 rtl:rotate-180" />
            </button>
          </div>
        )}

        {/* STEP 2: Child Profile */}
        {step === 2 && (
          <div>
            <div className="flex items-center space-x-3 rtl:space-x-reverse mb-4">
              <div className="p-3 bg-blue-50 text-blue-600 rounded-xl border border-blue-200">
                <User className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">Step 2: Create Child Profile</h3>
                <p className="text-xs text-slate-500 font-medium">Specify child details and limits</p>
              </div>
            </div>

            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">Child's Name</label>
                <input
                  type="text"
                  value={childName}
                  onChange={e => setChildName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:border-blue-500 font-medium"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">Daily Limit (Minutes)</label>
                  <input
                    type="number"
                    value={dailyLimitMins}
                    onChange={e => setDailyLimitMins(parseInt(e.target.value) || 0)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:border-blue-500 font-medium"
                  />
                  <span className="text-[11px] text-slate-400 font-medium">{Math.floor(dailyLimitMins / 60)}h {dailyLimitMins % 60}m</span>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">Session Limit (Minutes)</label>
                  <input
                    type="number"
                    value={sessionLimitMins}
                    onChange={e => setSessionLimitMins(parseInt(e.target.value) || 0)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 focus:outline-none focus:border-blue-500 font-medium"
                  />
                  <span className="text-[11px] text-slate-400 font-medium">{sessionLimitMins} mins max session</span>
                </div>
              </div>
            </div>

            <button
              onClick={handleChildProfileSubmit}
              className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-xs transition flex items-center justify-center space-x-2 rtl:space-x-reverse text-xs"
            >
              <span>Save Profile & Next</span>
              <ChevronRight className="w-5 h-5 rtl:rotate-180" />
            </button>
          </div>
        )}

        {/* STEP 3-9 Overview steps */}
        {step >= 3 && step <= 9 && (
          <div>
            <div className="flex items-center space-x-3 rtl:space-x-reverse mb-4">
              <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl border border-emerald-200">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">
                  Step {step}: {step === 3 && 'Daily Limit Verified'}
                  {step === 4 && 'Usage Schedule Active'}
                  {step === 5 && 'App Restrictions Configured'}
                  {step === 6 && 'Android Usage Access Granted'}
                  {step === 7 && 'Device Owner Mode Configured'}
                  {step === 8 && 'Emergency Contacts Set'}
                  {step === 9 && 'Lock Mode Enforcement Test'}
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  {step === 7
                    ? 'ADB Device Owner command active for anti-bypass protection'
                    : 'System capabilities verified and ready'}
                </p>
              </div>
            </div>

            <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-xl text-xs text-slate-700 font-medium mb-6 leading-relaxed">
              {step === 9 ? (
                <div className="text-center py-2">
                  <p className="mb-3 font-bold text-amber-700">
                    Click below to trigger a 1-Minute Enforcement Test Run.
                  </p>
                  <button
                    onClick={() => {
                      forceLockDevice('test_mode');
                      setShowSetupWizard(false);
                    }}
                    className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl shadow-xs transition text-xs"
                  >
                    Run Test Lock Screen Now
                  </button>
                </div>
              ) : (
                <p>
                  Configuration parameter step verified successfully. All rules and system hooks have been loaded into persistent device storage.
                </p>
              )}
            </div>

            <div className="flex space-x-3 rtl:space-x-reverse">
              <button
                onClick={() => setStep(step - 1)}
                className="py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl border border-slate-200 transition text-xs"
              >
                Back
              </button>
              <button
                onClick={() => setStep(step + 1)}
                className="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-xs transition flex items-center justify-center space-x-2 rtl:space-x-reverse text-xs"
              >
                <span>Continue</span>
                <ChevronRight className="w-5 h-5 rtl:rotate-180" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 10: Complete */}
        {step === 10 && (
          <div className="text-center py-4">
            <div className="mx-auto w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mb-4 border border-emerald-200">
              <Sparkles className="w-8 h-8" />
            </div>
            <h3 className="text-2xl font-bold mb-2 text-slate-900">Setup Complete!</h3>
            <p className="text-xs text-slate-500 font-medium max-w-md mx-auto mb-6">
              Your Android Parental Control & Screen Time Manager is fully active and protecting child device usage according to your rules.
            </p>
            <button
              onClick={() => setShowSetupWizard(false)}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-xs transition text-xs"
            >
              Open Dashboard
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
