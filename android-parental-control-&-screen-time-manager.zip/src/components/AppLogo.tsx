import React from 'react';

interface AppLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  className?: string;
  showBadge?: boolean;
  variant?: 'adaptive' | 'standard' | 'minimal';
}

/**
 * Redesigned Android Adaptive Application Icon Component
 * Designed according to Android Adaptive Icon Safe-Zone Requirements (Inner 66% Safe Area).
 * Symbol represents: Parental Control (Lock) + Screen Time (Clock) + Child Safety (Shield).
 */
export const AppLogo: React.FC<AppLogoProps> = ({
  size = 'md',
  className = '',
  showBadge = false,
  variant = 'standard',
}) => {
  const sizeMap = {
    sm: { container: 'w-8 h-8 rounded-xl', icon: 'w-5 h-5', badge: 'w-2.5 h-2.5', padding: 'p-1.5' },
    md: { container: 'w-11 h-11 rounded-2xl', icon: 'w-7 h-7', badge: 'w-3.5 h-3.5', padding: 'p-2' },
    lg: { container: 'w-16 h-16 rounded-2xl', icon: 'w-10 h-10', badge: 'w-4 h-4', padding: 'p-3' },
    xl: { container: 'w-24 h-24 rounded-3xl', icon: 'w-16 h-16', badge: 'w-6 h-6', padding: 'p-4' },
    '2xl': { container: 'w-32 h-32 rounded-[2.25rem]', icon: 'w-22 h-22', badge: 'w-7 h-7', padding: 'p-5' },
  };

  const dim = sizeMap[size];

  return (
    <div className={`relative inline-flex items-center justify-center shrink-0 select-none ${className}`}>
      {/* Outer Adaptive Icon Container with Inner 66% Safe Area Padding */}
      <div
        className={`${dim.container} ${dim.padding} bg-gradient-to-br from-blue-600 via-indigo-700 to-slate-900 text-white flex items-center justify-center shadow-lg shadow-blue-900/30 border border-blue-400/30 transition-all duration-300 hover:scale-105 overflow-hidden`}
        style={{
          // Ensure background contrast and layer isolation
          boxShadow: '0 10px 25px -5px rgba(29, 78, 216, 0.35), 0 8px 10px -6px rgba(15, 23, 42, 0.4)',
        }}
      >
        {/* Inner Safe Zone Vector SVG (Shield + Clock + Lock) */}
        <svg
          viewBox="0 0 108 108"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={`${dim.icon} drop-shadow-md`}
        >
          {/* Subtle Background Radial Glow Layer inside Safe Zone */}
          <circle cx="54" cy="54" r="36" fill="url(#blue_glow)" fillOpacity="0.35" />

          {/* 1. Parental Protection Shield (Child Safety) */}
          <path
            d="M54 22 C64 22, 74 18, 78 26 C78 52, 68 72, 54 84 C40 72, 30 52, 30 26 C34 18, 44 22, 54 22 Z"
            fill="url(#shield_grad)"
            stroke="#93C5FD"
            strokeWidth="2.5"
            strokeLinejoin="round"
          />

          {/* 2. Integrated Screen Time Clock Face (Screen Time) */}
          <circle
            cx="54"
            cy="50"
            r="18"
            fill="#1E293B"
            fillOpacity="0.8"
            stroke="#60A5FA"
            strokeWidth="2.2"
          />
          {/* Clock Ticks */}
          <line x1="54" y1="34" x2="54" y2="37" stroke="#93C5FD" strokeWidth="2" strokeLinecap="round" />
          <line x1="54" y1="63" x2="54" y2="66" stroke="#93C5FD" strokeWidth="2" strokeLinecap="round" />
          <line x1="38" y1="50" x2="41" y2="50" stroke="#93C5FD" strokeWidth="2" strokeLinecap="round" />
          <line x1="67" y1="50" x2="70" y2="50" stroke="#93C5FD" strokeWidth="2" strokeLinecap="round" />

          {/* Clock Hands indicating 10:10 / Protection Time */}
          <path d="M54 50 L54 41" stroke="#FBBF24" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M54 50 L62 45" stroke="#38BDF8" strokeWidth="2.2" strokeLinecap="round" />
          <circle cx="54" cy="50" r="2" fill="#F59E0B" />

          {/* 3. Center Security Padlock Keyhole (Parental Lock Enforced) */}
          <path
            d="M48 62 C48 58, 60 58, 60 62 L60 70 C60 72, 48 72, 48 70 Z"
            fill="#F59E0B"
            stroke="#FEF3C7"
            strokeWidth="1.2"
          />
          <path
            d="M51 62 V58 C51 55.5, 57 55.5, 57 58 V62"
            stroke="#FEF3C7"
            strokeWidth="2"
            strokeLinecap="round"
            fill="none"
          />
          <circle cx="54" cy="65" r="1.2" fill="#78350F" />

          {/* Sparkle Protection Stars */}
          <path d="M72 32 L73.5 35.5 L77 37 L73.5 38.5 L72 42 L70.5 38.5 L67 37 L70.5 35.5 Z" fill="#FBBF24" />

          {/* SVG Gradients Definition */}
          <defs>
            <radialGradient id="blue_glow" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(54 54) rotate(90) scale(36)">
              <stop stopColor="#60A5FA" />
              <stop offset="1" stopColor="#1E3A8A" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="shield_grad" x1="30" y1="22" x2="78" y2="84" gradientUnits="userSpaceOnUse">
              <stop stopColor="#2563EB" />
              <stop offset="0.5" stopColor="#1D4ED8" />
              <stop offset="1" stopColor="#0F172A" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      {/* Optional Badge Indicator */}
      {showBadge && (
        <span className="absolute -top-1 -right-1 p-1 bg-amber-400 text-slate-950 rounded-full shadow-md border-2 border-slate-900 flex items-center justify-center">
          <svg viewBox="0 0 24 24" fill="currentColor" className={dim.badge}>
            <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" />
          </svg>
        </span>
      )}
    </div>
  );
};
