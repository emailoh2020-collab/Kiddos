import React from 'react';

export const TestModeBar: React.FC = () => {
  // Hidden as requested to keep UI clean and production-ready
  return null;
};

