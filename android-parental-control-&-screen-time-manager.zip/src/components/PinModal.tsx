import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { translations } from '../data/translations';
import { AppIcon } from './common/AppIcon';
import { PinKey } from './common/ResponsiveComponents';
import { Lock, ShieldAlert, X, Delete, Check, Fingerprint } from 'lucide-react';

interface PinModalProps {
  title?: string;
}

export const PinModal: React.FC<PinModalProps> = ({ title }) => {
  const { showPinModal, closePinModal, authenticateParentPin, pinSuccessCallback, language, settings } = useApp();
  const t = translations[language];
  const modalTitle = title || t.enterParentPin;

  const [pin, setPin] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [lockoutSec, setLockoutSec] = useState<number>(0);
  const [loading, setLoading] = useState(false);
  const [biometricLoading, setBiometricLoading] = useState(false);

  useEffect(() => {
    if (!showPinModal) {
      setPin('');
      setError(null);
      setLockoutSec(0);
      setBiometricLoading(false);
    }
  }, [showPinModal]);

  // Lockout countdown timer
  useEffect(() => {
    if (lockoutSec <= 0) return;
    const interval = setInterval(() => {
      setLockoutSec((prev) => {
        if (prev <= 1) {
          setError(null);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [lockoutSec]);

  // Keyboard support for PIN entry
  useEffect(() => {
    if (!showPinModal) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (lockoutSec > 0 || loading || biometricLoading) return;

      if (e.key >= '0' && e.key <= '9') {
        e.preventDefault();
        handleKeyPress(e.key);
      } else if (e.key === 'Backspace') {
        e.preventDefault();
        handleDelete();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        closePinModal();
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (pin.length >= 4) {
          handleSubmit();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [showPinModal, pin, lockoutSec, loading, biometricLoading]);

  if (!showPinModal) return null;

  const handleKeyPress = (num: string) => {
    if (lockoutSec > 0 || loading || biometricLoading) return;
    if (pin.length < 32) {
      setPin((prev) => prev + num);
      setError(null);
    }
  };

  const handleDelete = () => {
    if (lockoutSec > 0 || loading || biometricLoading) return;
    setPin((prev) => prev.slice(0, -1));
    setError(null);
  };

  const handleClear = () => {
    if (lockoutSec > 0 || loading || biometricLoading) return;
    setPin('');
    setError(null);
  };

  const handleBiometricAuth = async () => {
    if (lockoutSec > 0 || loading || biometricLoading) return;
    setBiometricLoading(true);
    setError(null);

    try {
      // Trigger WebAuthn platform authenticator or biometric simulation
      if (window.PublicKeyCredential && typeof window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable === 'function') {
        const available = await window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
        if (!available) {
          setError(t.biometricNotSupported);
          setBiometricLoading(false);
          return;
        }
      }

      // Simulate biometric scan & verification delay
      await new Promise((resolve) => setTimeout(resolve, 800));

      setBiometricLoading(false);
      if (pinSuccessCallback) {
        pinSuccessCallback();
      }
      closePinModal();
    } catch (err) {
      setBiometricLoading(false);
      setError('Biometric verification failed. Please use PIN.');
    }
  };

  const handleSubmit = async () => {
    if (pin.length < 4) {
      setError('PIN must be at least 4 digits');
      return;
    }

    setLoading(true);
    setError(null);

    const result = await authenticateParentPin(pin);
    setLoading(false);

    if (result.success) {
      setPin('');
      if (pinSuccessCallback) {
        pinSuccessCallback();
      }
      closePinModal();
    } else {
      setPin('');
      if (result.delaySeconds && result.delaySeconds > 0) {
        setLockoutSec(result.delaySeconds);
        setError(`${t.incorrectPin} - ${result.delaySeconds}s delay engaged.`);
      } else {
        setError(`${t.incorrectPin}. Please try again.`);
      }
    }
  };

  return (
    <div
      dir={language === 'ar' ? 'rtl' : 'ltr'}
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-200 select-none overflow-y-auto"
    >
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl sm:rounded-3xl w-full max-w-[340px] sm:max-w-sm p-4 sm:p-7 shadow-2xl text-slate-900 dark:text-slate-100 relative my-auto">
        {/* Close Button */}
        <button
          onClick={closePinModal}
          className="absolute top-3 right-3 sm:top-4 sm:right-4 rtl:right-auto rtl:left-3 sm:rtl:left-4 text-slate-400 hover:text-slate-600 p-1.5 sm:p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition min-w-[32px] min-h-[32px] sm:min-w-[40px] sm:min-h-[40px] flex items-center justify-center aspect-square"
          aria-label="Close PIN modal"
        >
          <X className="w-4 h-4 sm:w-5 sm:h-5 shrink-0 aspect-square" />
        </button>

        {/* Header */}
        <div className="text-center mb-3 sm:mb-5">
          <div className="flex justify-center mb-1.5 sm:mb-2.5">
            <AppIcon icon={Lock} size="md" colorScheme="blue" shape="squircle" />
          </div>
          <span className="inline-block bg-blue-50 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 text-[9px] sm:text-[11px] font-extrabold uppercase px-2.5 sm:px-3 py-0.5 rounded-full border border-blue-200 dark:border-blue-800/60 mb-0.5 sm:mb-1">
            {t.parentAccess}
          </span>
          <h2 className="text-base sm:text-xl font-extrabold text-slate-900 dark:text-white leading-tight">
            {modalTitle}
          </h2>
        </div>

        {/* Error / Lockout Banner */}
        {error && (
          <div className="mb-3 sm:mb-4 p-2.5 sm:p-3 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800/60 rounded-xl text-red-700 dark:text-red-300 text-xs font-bold flex items-center space-x-2 rtl:space-x-reverse animate-in shake">
            <ShieldAlert className="w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0 text-red-600 dark:text-red-400 aspect-square" />
            <span>{error}</span>
          </div>
        )}

        {/* Biometric Unlock Option */}
        <div className="mb-3 sm:mb-4">
          <button
            type="button"
            onClick={handleBiometricAuth}
            disabled={lockoutSec > 0 || loading || biometricLoading}
            className="w-full min-h-[38px] sm:min-h-[46px] py-1.5 sm:py-2.5 px-3 sm:px-4 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/40 dark:hover:bg-emerald-900/60 border border-emerald-300 dark:border-emerald-700 text-emerald-800 dark:text-emerald-200 font-bold rounded-xl sm:rounded-2xl transition flex items-center justify-center space-x-2 rtl:space-x-reverse text-xs sm:text-sm shadow-xs cursor-pointer"
          >
            <Fingerprint className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-600 dark:text-emerald-400 shrink-0 aspect-square" />
            <span>{biometricLoading ? 'Verifying Biometrics...' : (t.useBiometric || 'Use Fingerprint / Face ID')}</span>
          </button>
        </div>

        <div className="relative flex py-0.5 sm:py-1 items-center mb-3 sm:mb-4">
          <div className="flex-grow border-t border-slate-200 dark:border-slate-800"></div>
          <span className="flex-shrink mx-2.5 sm:mx-3 text-slate-400 text-[10px] sm:text-[11px] uppercase font-bold">Or enter PIN</span>
          <div className="flex-grow border-t border-slate-200 dark:border-slate-800"></div>
        </div>

        {/* Dynamic PIN Display Indicators (Grows dynamically with each digit entered, no predefined empty slots) */}
        <div className="flex justify-center items-center flex-wrap gap-2 sm:gap-3 mb-3 sm:mb-5 bg-slate-50 dark:bg-slate-800/60 py-2.5 sm:py-3.5 px-3 sm:px-4 min-h-[40px] sm:min-h-[50px] rounded-xl sm:rounded-2xl border border-slate-200/80 dark:border-slate-700/60 transition-all">
          {pin.split('').map((_, idx) => (
            <div
              key={idx}
              className="w-2.5 h-2.5 sm:w-4 sm:h-4 aspect-square rounded-full bg-blue-600 dark:bg-blue-500 scale-100 shadow-xs ring-1.5 sm:ring-2 ring-blue-300 dark:ring-blue-800/80 animate-in zoom-in-50 fade-in duration-150 shrink-0"
              aria-label="PIN digit entered"
            />
          ))}
        </div>

        {/* 3x4 Proportional Numeric Keypad (Equal Width, Equal Height, 1:1 Keys) */}
        <div className="grid grid-cols-3 gap-2 sm:gap-3 mb-3.5 sm:mb-5 max-w-[210px] sm:max-w-[280px] mx-auto">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
            <PinKey
              key={num}
              value={num}
              onClick={() => handleKeyPress(num)}
              disabled={lockoutSec > 0 || loading}
            />
          ))}

          {/* Clear Key */}
          <button
            type="button"
            onClick={handleClear}
            disabled={lockoutSec > 0 || loading || pin.length === 0}
            className="w-full aspect-square min-h-[38px] max-h-[54px] sm:min-h-[52px] sm:max-h-[76px] rounded-xl sm:rounded-2xl bg-slate-50 hover:bg-slate-100 dark:bg-slate-800/80 dark:hover:bg-slate-800 disabled:opacity-40 text-[10px] sm:text-xs font-black text-slate-500 dark:text-slate-400 border border-slate-200/80 dark:border-slate-700/80 transition flex items-center justify-center shadow-xs"
          >
            {t.clearKeypad}
          </button>

          {/* 0 Key */}
          <PinKey
            value="0"
            onClick={() => handleKeyPress('0')}
            disabled={lockoutSec > 0 || loading}
          />

          {/* Backspace Delete Key */}
          <button
            type="button"
            onClick={handleDelete}
            disabled={lockoutSec > 0 || loading || pin.length === 0}
            className="w-full aspect-square min-h-[38px] max-h-[54px] sm:min-h-[52px] sm:max-h-[76px] rounded-xl sm:rounded-2xl bg-slate-50 hover:bg-slate-100 dark:bg-slate-800/80 dark:hover:bg-slate-800 disabled:opacity-40 text-slate-700 dark:text-slate-300 border border-slate-200/80 dark:border-slate-700/80 transition flex items-center justify-center shadow-xs"
            title={t.deleteKeypad}
            aria-label={t.deleteKeypad}
          >
            <Delete className="w-4 h-4 sm:w-5 sm:h-5 shrink-0 aspect-square rtl:rotate-180" />
          </button>
        </div>

        {/* Confirm / Submit Button */}
        <button
          type="button"
          onClick={handleSubmit}
          disabled={pin.length < 4 || lockoutSec > 0 || loading}
          className="w-full min-h-[40px] sm:min-h-[48px] py-2 sm:py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-100 dark:disabled:bg-slate-800 disabled:text-slate-400 text-white font-extrabold rounded-xl sm:rounded-2xl shadow-md shadow-blue-500/20 transition flex items-center justify-center space-x-2 rtl:space-x-reverse text-xs sm:text-base"
        >
          <Check className="w-4 h-4 sm:w-5 sm:h-5 shrink-0 aspect-square" />
          <span>{loading ? 'Authenticating...' : t.confirmPin}</span>
        </button>

        <p className="text-[9px] sm:text-[11px] text-slate-400 text-center mt-2.5 sm:mt-3 font-medium">
          Default Parent PIN: <code className="text-blue-600 font-bold">1234</code>
        </p>
      </div>
    </div>
  );
};
