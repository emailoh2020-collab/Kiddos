import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Clock, Plus, ShieldCheck, X, Camera } from 'lucide-react';
import { AppIcon } from './common/AppIcon';

export const ExtraTimeModal: React.FC = () => {
  const {
    showExtraTimeModal,
    setShowExtraTimeModal,
    grantExtraTime,
    openPinModal,
    settings,
    captureVerificationPhoto,
  } = useApp();

  const [selectedMins, setSelectedMins] = useState<number>(15);
  const [customMins, setCustomMins] = useState<string>('');
  const [reason, setReason] = useState<string>('Homework completion');
  const [showCamera, setShowCamera] = useState<boolean>(false);

  if (!showExtraTimeModal) return null;

  const handleGrant = (mins: number) => {
    openPinModal(() => {
      grantExtraTime(mins, reason);
      setShowExtraTimeModal(false);
    }, `Approve +${mins} Extra Minutes`);
  };

  const handleTakeVerification = () => {
    const mockSnapshots = [
      'https://images.unsplash.com/photo-1543269865-cbf427effbad?w=300&q=80',
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&q=80',
    ];
    const snap = mockSnapshots[Math.floor(Math.random() * mockSnapshots.length)];
    captureVerificationPhoto(snap, 'Extra Time Authorization');
    setShowCamera(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200 select-none">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-md p-6 shadow-xl text-slate-900 dark:text-white relative">
        <button
          onClick={() => setShowExtraTimeModal(false)}
          className="absolute top-4 right-4 rtl:right-auto rtl:left-4 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1.5 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition aspect-square min-w-[36px] min-h-[36px] flex items-center justify-center"
        >
          <X className="w-5 h-5 shrink-0 aspect-square" />
        </button>

        <div className="flex items-center space-x-3 rtl:space-x-reverse mb-6">
          <AppIcon icon={Clock} size="md" colorScheme="emerald" shape="rounded" />
          <div>
            <h3 className="text-base sm:text-lg font-extrabold text-slate-900 dark:text-white">
              Grant Extra Time
            </h3>
            <p className="text-xs text-slate-500 font-medium">Add temporary screen time allowance</p>
          </div>
        </div>

        {/* Quick Presets Grid */}
        <div className="grid grid-cols-3 sm:grid-cols-5 gap-2.5 mb-4">
          {[5, 10, 15, 30, 60].map((m) => (
            <button
              key={m}
              onClick={() => setSelectedMins(m)}
              className={`py-3 px-2 rounded-2xl text-xs font-bold border transition flex flex-col items-center justify-center min-h-[60px] ${
                selectedMins === m
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                  : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
              }`}
            >
              <span className="text-base font-black">+{m}</span>
              <span className="text-[10px] opacity-90 font-medium">mins</span>
            </button>
          ))}
        </div>

        {/* Custom Input */}
        <div className="mb-4">
          <label className="block text-xs font-bold text-slate-500 mb-1">
            Custom Duration (Minutes)
          </label>
          <input
            type="number"
            placeholder="e.g. 45"
            value={customMins}
            onChange={(e) => {
              setCustomMins(e.target.value);
              if (e.target.value) setSelectedMins(parseInt(e.target.value) || 0);
            }}
            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-bold text-slate-800 dark:text-white focus:outline-none focus:border-blue-500 min-h-[42px]"
          />
        </div>

        {/* Reason */}
        <div className="mb-6">
          <label className="block text-xs font-bold text-slate-500 mb-1">Reason / Activity Note</label>
          <select
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-3.5 py-2.5 text-xs font-bold text-slate-800 dark:text-white focus:outline-none focus:border-blue-500 min-h-[42px]"
          >
            <option value="Homework completion">Homework / Studying</option>
            <option value="Educational video">Educational / Reading</option>
            <option value="Chores reward">Reward for chores</option>
            <option value="Parent discretion">Parent discretion</option>
          </select>
        </div>

        {/* Camera Verification Optional */}
        {settings?.requireVerificationForExtraTime && (
          <div className="mb-6 p-3 bg-blue-50 dark:bg-blue-950/40 border border-blue-200/80 dark:border-blue-800 rounded-2xl flex items-center justify-between">
            <div className="flex items-center space-x-2.5 rtl:space-x-reverse">
              <Camera className="w-5 h-5 text-blue-600 shrink-0 aspect-square" />
              <div>
                <p className="text-xs font-bold text-slate-900 dark:text-white">User Verification Photo</p>
                <p className="text-[10px] text-slate-500 font-medium">Capture photo before unlock</p>
              </div>
            </div>
            <button
              onClick={handleTakeVerification}
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-xs transition"
            >
              Take Photo
            </button>
          </div>
        )}

        <div className="flex space-x-3 rtl:space-x-reverse">
          <button
            onClick={() => setShowExtraTimeModal(false)}
            className="flex-1 py-3 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold rounded-2xl border border-slate-200 dark:border-slate-700 transition text-xs min-h-[44px]"
          >
            Cancel
          </button>
          <button
            onClick={() => handleGrant(selectedMins)}
            disabled={selectedMins <= 0}
            className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold rounded-2xl shadow-xs transition flex items-center justify-center space-x-2 rtl:space-x-reverse text-xs min-h-[44px]"
          >
            <Plus className="w-4 h-4 shrink-0 aspect-square" />
            <span>Grant +{selectedMins}m</span>
          </button>
        </div>
      </div>
    </div>
  );
};
