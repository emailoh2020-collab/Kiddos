import React from 'react';
import { useApp } from '../context/AppContext';
import { translations } from '../data/translations';
import { formatChildName } from '../utils/locale';
import {
  ShieldAlert,
  Wand2,
  Info,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Clock,
  Users,
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    role,
    language,
    setActiveTab,
    child,
    childrenList,
    selectActiveChild,
    setShowSetupWizard,
    currentMode,
    touchParentActivity,
    setAccountSelected,
  } = useApp();

  const t = translations[language];

  // Mode badge visual configuration
  const getModeBadge = () => {
    switch (currentMode) {
      case 'PARENT_SETTINGS':
        return (
          <span className="inline-flex items-center space-x-1 rtl:space-x-reverse bg-amber-500/10 text-amber-700 dark:text-amber-400 border border-amber-500/30 text-xs font-extrabold px-2.5 py-1 rounded-full shadow-2xs">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-600 animate-pulse shrink-0 aspect-square" />
            <span>{t.modeParentBadge}</span>
          </span>
        );
      case 'LOCKED':
        return (
          <span className="inline-flex items-center space-x-1 rtl:space-x-reverse bg-red-500/10 text-red-700 dark:text-red-400 border border-red-500/30 text-xs font-extrabold px-2.5 py-1 rounded-full shadow-2xs">
            <XCircle className="w-3.5 h-3.5 text-red-600 shrink-0 aspect-square" />
            <span>{t.modeLockedBadge}</span>
          </span>
        );
      case 'EXTRA_TIME':
        return (
          <span className="inline-flex items-center space-x-1 rtl:space-x-reverse bg-blue-500/10 text-blue-700 dark:text-blue-400 border border-blue-500/30 text-xs font-extrabold px-2.5 py-1 rounded-full shadow-2xs">
            <Clock className="w-3.5 h-3.5 text-blue-600 shrink-0 aspect-square" />
            <span>{t.modeExtraTimeBadge}</span>
          </span>
        );
      case 'PLAYING':
      default:
        return (
          <span className="inline-flex items-center space-x-1 rtl:space-x-reverse bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30 text-xs font-extrabold px-2.5 py-1 rounded-full shadow-2xs">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0 aspect-square" />
            <span>{t.modePlayingBadge}</span>
          </span>
        );
    }
  };

  return (
    <header 
      onClick={touchParentActivity}
      className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100 sticky top-0 z-40 shadow-xs w-full"
    >
      <div className="w-full px-3 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand Icon & Status */}
        <div className="flex items-center space-x-2.5 sm:space-x-3 rtl:space-x-reverse">
          <div 
            className="w-9 h-9 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center text-white font-bold shadow-md shadow-blue-500/20 shrink-0 aspect-square"
            title="Smart Parental Control"
          >
            <ShieldAlert className="w-5 h-5 text-white" />
          </div>
          <div className="flex items-center space-x-2 rtl:space-x-reverse">
            {getModeBadge()}
            <div className="text-xs text-slate-500 dark:text-slate-400 hidden sm:flex items-center gap-1.5 font-medium">
              <span>{child.avatar || '👦'} {formatChildName(child.name)}</span>
              {role === 'parent' && childrenList.length > 1 && (
                <select
                  value={child.id}
                  onChange={(e) => selectActiveChild(e.target.value)}
                  className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-[11px] font-bold rounded-md px-1.5 py-0.5 border border-slate-200 dark:border-slate-700 focus:outline-none cursor-pointer"
                >
                  {childrenList.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.avatar} {formatChildName(c.name)}
                    </option>
                  ))}
                </select>
              )}
            </div>
          </div>
        </div>

        {/* Top Header Controls: Setup Wizard, App Info, and Language Button */}
        <div className="flex items-center space-x-2 sm:space-x-3 rtl:space-x-reverse">
          {/* Setup Wizard Button */}
          <button
            onClick={() => {
              touchParentActivity();
              setShowSetupWizard(true);
            }}
            className="flex items-center space-x-1.5 rtl:space-x-reverse px-2.5 sm:px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs sm:text-sm font-semibold rounded-xl border border-slate-200 dark:border-slate-700 transition min-h-[38px]"
            title={t.setupWizard}
          >
            <Wand2 className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 aspect-square" />
            <span className="hidden sm:inline">{t.setupWizard}</span>
          </button>

          {/* App Info Button */}
          <button
            onClick={() => {
              touchParentActivity();
              setActiveTab('about');
            }}
            className="flex items-center space-x-1.5 rtl:space-x-reverse px-2.5 sm:px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs sm:text-sm rounded-xl border border-slate-200 dark:border-slate-700 transition font-semibold min-h-[38px]"
            title={t.aboutMenu}
          >
            <Info className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 aspect-square" />
            <span className="hidden sm:inline">{t.aboutMenu}</span>
          </button>

          {/* Switch Account Button */}
          <button
            onClick={() => {
              touchParentActivity();
              setAccountSelected(false);
            }}
            className="flex items-center space-x-1.5 rtl:space-x-reverse px-2.5 sm:px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs sm:text-sm rounded-xl border border-slate-200 dark:border-slate-700 transition font-semibold min-h-[38px]"
            title={t.switchAccount}
          >
            <Users className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 aspect-square" />
            <span className="hidden sm:inline">{t.switchAccount}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
