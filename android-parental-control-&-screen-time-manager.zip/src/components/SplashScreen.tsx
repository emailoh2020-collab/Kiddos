import React, { useEffect, useState } from 'react';
import { APP_CONFIG } from '../config/appConfig';
import { AppLogo } from './AppLogo';
import { translations } from '../data/translations';
import { useApp } from '../context/AppContext';
import { Sparkles, ShieldCheck } from 'lucide-react';

interface SplashScreenProps {
  onFinish?: () => void;
  forceVisible?: boolean;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish, forceVisible = false }) => {
  const { language } = useApp();
  const t = translations[language];
  const [visible, setVisible] = useState(true);
  const [fading, setFading] = useState(false);

  useEffect(() => {
    // 1.8 seconds splash duration for optimal speed without long artificial delay
    const timer = setTimeout(() => {
      setFading(true);
      const dismissTimer = setTimeout(() => {
        setVisible(false);
        if (onFinish) onFinish();
      }, 300);
      return () => clearTimeout(dismissTimer);
    }, 1800);

    return () => clearTimeout(timer);
  }, [onFinish]);

  if (!visible && !forceVisible) return null;

  return (
    <div
      className={`fixed inset-0 z-50 bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 text-white flex flex-col justify-between p-8 select-none transition-opacity duration-300 ${
        fading ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
      dir={language === 'ar' ? 'rtl' : 'ltr'}
    >
      {/* Top Bar / Status */}
      <div className="flex items-center justify-between text-xs text-slate-400">
        <div className="flex items-center space-x-2 rtl:space-x-reverse bg-blue-500/10 border border-blue-500/20 px-3 py-1 rounded-full text-blue-300 font-semibold">
          <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
          <span>Android 15 Device Owner API</span>
        </div>
        <span className="font-mono text-slate-500 text-[11px]">v{APP_CONFIG.versionName}</span>
      </div>

      {/* Center Branding & Logo */}
      <div className="flex flex-col items-center justify-center text-center max-w-sm mx-auto space-y-6">
        {/* Animated Logo Container */}
        <div className="relative">
          <div className="absolute -inset-4 bg-blue-500/20 rounded-full blur-xl animate-pulse"></div>
          <AppLogo size="xl" showBadge />
        </div>

        {/* Application Name & Tagline */}
        <div className="space-y-2 animate-in fade-in zoom-in-95 duration-500">
          <h1 className="text-3xl font-extrabold tracking-tight text-white flex items-center justify-center gap-2">
            {APP_CONFIG.appName}
          </h1>
          <p className="text-sm text-blue-300 font-semibold tracking-wide uppercase">
            {t.splashTagline || APP_CONFIG.tagline}
          </p>
        </div>

        {/* Version Badge */}
        <div className="inline-flex items-center space-x-2 rtl:space-x-reverse px-3.5 py-1.5 bg-slate-800/80 border border-slate-700/80 rounded-full text-xs font-mono text-slate-300">
          <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <span>
            {t.version} {APP_CONFIG.versionName} ({t.build} {APP_CONFIG.versionCode})
          </span>
        </div>

        {/* Loading Progress Bar */}
        <div className="w-48 bg-slate-800/80 h-1.5 rounded-full overflow-hidden border border-slate-700/50 mt-4">
          <div className="h-full bg-gradient-to-r from-blue-500 via-indigo-500 to-blue-400 animate-pulse w-full rounded-full" />
        </div>
      </div>

      {/* Footer Creator & Copyright */}
      <div className="text-center text-xs text-slate-500 font-medium space-y-1">
        <p className="text-slate-400 font-semibold">
          {t.developer}: <span className="text-slate-200 font-bold">{APP_CONFIG.developerName}</span>
        </p>
        <p className="text-[11px] text-slate-600">
          © {APP_CONFIG.copyrightYear} {APP_CONFIG.developerName}. All rights reserved.
        </p>
      </div>
    </div>
  );
};
