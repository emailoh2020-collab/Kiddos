import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { translations } from '../../data/translations';
import { getNextAllowedPeriod } from '../../utils/time';
import { formatDate, formatTime, formatMinutes } from '../../utils/locale';
import { useResponsiveLayout } from '../../utils/useResponsiveLayout';
import { AppIcon } from '../common/AppIcon';
import { ActionButton } from '../common/ResponsiveComponents';
import { Lock, PhoneCall, ShieldAlert, Key, Clock, Sparkles } from 'lucide-react';

export const LockScreen: React.FC = () => {
  const {
    schedule,
    openPinModal,
    grantExtraTime,
    setRole,
    setActiveTab,
    settings,
    language,
    isLocked,
    role,
    parentSessionActive,
  } = useApp();

  const t = translations[language];
  const { isTablet, isCompact, orientation } = useResponsiveLayout();
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => {
      setNow(new Date());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  if (!isLocked || role === 'parent' || parentSessionActive) return null;

  const nextWindow = getNextAllowedPeriod(schedule);

  const handleParentUnlock = () => {
    openPinModal(() => {
      setRole('parent');
      setActiveTab('settings');
    }, t.parentAccess);
  };

  const handleQuickAddExtra = (mins: number) => {
    openPinModal(() => {
      grantExtraTime(mins, 'Parent Lock Screen Extra Time');
    }, `${t.grantExtraTime}: +${formatMinutes(mins, language)}`);
  };

  const isLandscape = orientation === 'landscape';

  return (
    <div
      dir={language === 'ar' ? 'rtl' : 'ltr'}
      className="fixed inset-0 z-50 bg-slate-900 text-white flex flex-col justify-between p-3.5 sm:p-6 md:p-8 select-none animate-in fade-in duration-300 overflow-y-auto"
    >
      {/* Top Bar: Emergency Contacts & Status Badge */}
      <header className="flex items-center justify-between gap-2.5 w-full max-w-5xl mx-auto">
        <div className="flex items-center space-x-1.5 rtl:space-x-reverse bg-red-500/20 text-red-300 border border-red-500/40 px-3 py-1 rounded-full text-[11px] font-black shrink-0">
          <ShieldAlert className="w-3.5 h-3.5 text-red-400 shrink-0 aspect-square" />
          <span>{t.modeLockedBadge}</span>
        </div>

        {/* Emergency Call Buttons */}
        <div className="flex items-center space-x-2 rtl:space-x-reverse overflow-x-auto">
          {(settings?.emergencyContacts || []).slice(0, 2).map((contact) => (
            <a
              key={contact.id}
              href={`tel:${contact.phone}`}
              className="px-3 py-1 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 rounded-lg text-xs font-bold transition flex items-center space-x-1.5 rtl:space-x-reverse shrink-0 min-h-[34px]"
            >
              <PhoneCall className="w-3 h-3 text-emerald-400 shrink-0 aspect-square" />
              <span className="truncate">{contact.name}</span>
            </a>
          ))}
        </div>
      </header>

      {/* Main Lock Screen Center: Phone vs Tablet / Landscape layout */}
      <main className="my-auto py-2 w-full max-w-4xl mx-auto">
        <div className={`flex flex-col ${isLandscape ? 'md:flex-row md:items-center md:justify-center gap-6' : 'items-center gap-4 sm:gap-5'} text-center`}>
          {/* Left / Top: Lock Icon & Main Heading */}
          <div className="flex flex-col items-center space-y-2">
            <div className="w-14 h-14 sm:w-18 sm:h-18 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-400 flex items-center justify-center shadow-md shadow-red-950/50 shrink-0 aspect-square">
              <Lock className="w-7 h-7 sm:w-9 sm:h-9 shrink-0 aspect-square" />
            </div>

            <div>
              <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white">
                {t.timeIsUp}
              </h1>
              <p className="text-slate-400 text-xs sm:text-sm font-semibold max-w-md mx-auto mt-0.5">
                {t.screenTimeEnded}
              </p>
            </div>
          </div>

          {/* Right / Bottom: Current Clock & Next Allowed Period Card */}
          <div className="w-full max-w-md bg-slate-800/80 border border-slate-700/80 rounded-2xl sm:rounded-3xl p-4 sm:p-5 shadow-lg backdrop-blur-sm">
            <span className="text-[10px] sm:text-[11px] font-bold text-slate-400 block">
              {formatDate(now, language)}
            </span>
            <div className="text-2xl sm:text-4xl font-mono font-black text-white block my-0.5 tracking-tight">
              {formatTime(now, language)}
            </div>

            {settings?.controlMode === 'free' ? (
              <div className="mt-2.5 pt-2.5 border-t border-slate-700 text-[11px] text-amber-400 font-bold flex items-center justify-center space-x-1.5 rtl:space-x-reverse">
                <Clock className="w-3.5 h-3.5 text-amber-400 shrink-0 aspect-square" />
                <span>{t.nextAllowanceTomorrow}</span>
              </div>
            ) : nextWindow ? (
              <div className="mt-2.5 pt-2.5 border-t border-slate-700 text-[11px] text-blue-300 font-bold flex items-center justify-center space-x-1.5 rtl:space-x-reverse">
                <Clock className="w-3.5 h-3.5 text-blue-400 shrink-0 aspect-square" />
                <span>
                  {t.nextPeriodAt} <strong className="text-white font-black">{nextWindow.startTime}</strong> ({nextWindow.day})
                </span>
              </div>
            ) : null}

            {/* Quick Extra Time for Parent */}
            <div className="mt-3 pt-3 border-t border-slate-700/60">
              <span className="text-[10px] text-slate-400 font-bold block mb-1.5">
                {t.grantExtraTime} ({t.parentAccess}):
              </span>
              <div className="flex justify-center gap-1.5 flex-wrap">
                {[5, 15, 30].map((m) => (
                  <button
                    key={m}
                    onClick={() => handleQuickAddExtra(m)}
                    className="px-2.5 py-1 bg-slate-700 hover:bg-slate-600 active:bg-blue-600 text-slate-200 text-[11px] font-bold rounded-lg border border-slate-600 transition min-h-[32px] min-w-[48px]"
                  >
                    +{formatMinutes(m, language)}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Bottom Bar: Parent Unlock Action */}
      <footer className="w-full max-w-md mx-auto pt-2">
        <ActionButton
          variant="primary"
          size="md"
          fullWidth
          icon={Key}
          onClick={handleParentUnlock}
          className="shadow-md shadow-blue-900/40"
        >
          {t.unlockDevice}
        </ActionButton>
      </footer>
    </div>
  );
};
