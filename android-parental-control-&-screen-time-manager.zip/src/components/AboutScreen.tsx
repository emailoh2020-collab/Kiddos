import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { APP_CONFIG } from '../config/appConfig';
import { translations } from '../data/translations';
import { AppLogo } from './AppLogo';
import { useResponsiveLayout } from '../utils/useResponsiveLayout';
import { AppIcon } from './common/AppIcon';
import {
  ArrowLeft,
  Mail,
  Globe,
  HelpCircle,
  ShieldCheck,
  FileText,
  Lock,
  Code2,
  ExternalLink,
  Sparkles,
  Smartphone,
  X,
  Copy,
  Check,
} from 'lucide-react';

interface AboutScreenProps {
  onBack: () => void;
  onPreviewSplash?: () => void;
}

export const AboutScreen: React.FC<AboutScreenProps> = ({ onBack, onPreviewSplash }) => {
  const { language } = useApp();
  const t = translations[language];
  const { isTablet } = useResponsiveLayout();

  const [activeModal, setActiveModal] = useState<'privacy' | 'terms' | 'licenses' | null>(null);
  const [copiedEmail, setCopiedEmail] = useState(false);

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(APP_CONFIG.developerEmail);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2000);
  };

  const handleContactDev = () => {
    if (APP_CONFIG.developerEmail) {
      window.open(
        `mailto:${APP_CONFIG.developerEmail}?subject=${encodeURIComponent(
          APP_CONFIG.appName + ' Support Inquiry'
        )}`
      );
    }
  };

  return (
    <div
      className="space-y-5 sm:space-y-6 max-w-4xl mx-auto pb-12"
      dir={language === 'ar' ? 'rtl' : 'ltr'}
    >
      {/* Navigation Toolbar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-4 sm:p-5 shadow-sm flex items-center justify-between">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 rtl:space-x-reverse text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 px-3.5 py-2 rounded-2xl border border-slate-200 dark:border-slate-700 text-xs font-bold transition min-h-[40px]"
        >
          <ArrowLeft className="w-4 h-4 rtl:rotate-180 shrink-0 aspect-square" />
          <span>{t.back}</span>
        </button>

        <div className="flex items-center space-x-2 rtl:space-x-reverse min-w-0">
          <AppIcon icon={ShieldCheck} size="sm" colorScheme="blue" shape="circle" />
          <h1 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white truncate">
            {t.aboutMenu}
          </h1>
        </div>

        {onPreviewSplash && (
          <button
            onClick={onPreviewSplash}
            className="flex items-center space-x-1.5 rtl:space-x-reverse text-xs font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40 hover:bg-blue-100 dark:hover:bg-blue-900 px-3 py-2 rounded-2xl border border-blue-200 dark:border-blue-800 transition min-h-[40px]"
          >
            <Sparkles className="w-3.5 h-3.5 shrink-0 aspect-square text-blue-600 dark:text-blue-400" />
            <span className="hidden sm:inline">{t.previewSplash}</span>
          </button>
        )}
      </div>

      {/* Hero Branding Header */}
      <div className="bg-gradient-to-b from-white to-slate-50 dark:from-slate-900 dark:to-slate-950 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-sm text-center space-y-4 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-5 text-blue-600 pointer-events-none">
          <ShieldCheck className="w-48 h-48 shrink-0 aspect-square" />
        </div>

        {/* Large Centered Logo */}
        <div className="flex justify-center pt-2">
          <AppLogo size="xl" showBadge />
        </div>

        {/* App Title & Tagline */}
        <div className="space-y-1">
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
            {APP_CONFIG.appName}
          </h2>
          <p className="text-xs sm:text-sm font-extrabold text-blue-600 dark:text-blue-400 tracking-wide uppercase">
            {APP_CONFIG.tagline}
          </p>
        </div>

        {/* Version Badge */}
        <div className="inline-flex items-center space-x-2 rtl:space-x-reverse px-4 py-1.5 bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border border-blue-200/80 dark:border-blue-800 rounded-full text-xs font-bold font-mono">
          <span>
            {t.version} {APP_CONFIG.versionName} ({t.build} {APP_CONFIG.versionCode})
          </span>
        </div>

        {/* Description */}
        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 font-medium max-w-2xl mx-auto leading-relaxed pt-2">
          {APP_CONFIG.description[language] || APP_CONFIG.description.en}
        </p>
      </div>

      {/* Grid Layout for Meta & Legal Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 sm:gap-6">
        {/* Creator & Copyright Card */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
          <div className="flex items-center space-x-2.5 rtl:space-x-reverse border-b border-slate-100 dark:border-slate-800 pb-3">
            <Code2 className="w-5 h-5 text-blue-600 shrink-0 aspect-square" />
            <h3 className="text-sm font-extrabold text-slate-900 dark:text-white">{t.developer}</h3>
          </div>

          <div className="space-y-3 text-xs">
            <div className="flex justify-between items-center p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-700">
              <span className="text-slate-500 font-medium">{t.developer}</span>
              <span className="font-extrabold text-slate-900 dark:text-white text-sm">
                {APP_CONFIG.developerName}
              </span>
            </div>

            <div className="flex justify-between items-center p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-700">
              <span className="text-slate-500 font-medium">{t.copyright}</span>
              <span className="font-bold text-slate-800 dark:text-slate-200 text-right">
                © {APP_CONFIG.copyrightYear} {APP_CONFIG.developerName}
              </span>
            </div>

            {APP_CONFIG.developerEmail && (
              <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-700 space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-slate-500 font-medium">{t.contactDeveloper}</span>
                  <button
                    onClick={handleCopyEmail}
                    className="text-[11px] text-blue-600 dark:text-blue-400 font-bold hover:underline flex items-center gap-1"
                  >
                    {copiedEmail ? (
                      <Check className="w-3 h-3 text-emerald-600 shrink-0 aspect-square" />
                    ) : (
                      <Copy className="w-3 h-3 shrink-0 aspect-square" />
                    )}
                    <span>{copiedEmail ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <p className="font-mono text-xs font-bold text-blue-600 dark:text-blue-400 truncate">
                  {APP_CONFIG.developerEmail}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Technical Specs Card */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
          <div className="flex items-center space-x-2.5 rtl:space-x-reverse border-b border-slate-100 dark:border-slate-800 pb-3">
            <Smartphone className="w-5 h-5 text-indigo-600 shrink-0 aspect-square" />
            <h3 className="text-sm font-extrabold text-slate-900 dark:text-white">
              {t.technicalSpecs}
            </h3>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex justify-between items-center p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-700">
              <span className="text-slate-500 font-medium">{t.minAndroidVersion}</span>
              <span className="font-bold text-slate-800 dark:text-slate-200 font-mono">
                {APP_CONFIG.minAndroidVersion}
              </span>
            </div>

            <div className="flex justify-between items-center p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-700">
              <span className="text-slate-500 font-medium">{t.targetAndroidVersion}</span>
              <span className="font-bold text-blue-700 dark:text-blue-400 font-mono">
                {APP_CONFIG.targetAndroidVersion}
              </span>
            </div>

            <div className="flex justify-between items-center p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-700">
              <span className="text-slate-500 font-medium">{t.releaseDate}</span>
              <span className="font-bold text-slate-800 dark:text-slate-200 font-mono">
                {APP_CONFIG.releaseDate}
              </span>
            </div>

            <div className="flex justify-between items-center p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-100 dark:border-slate-700">
              <span className="text-slate-500 font-medium">Anti-Bypass Protection</span>
              <span className="font-bold text-emerald-700 dark:text-emerald-400">
                Device Policy Owner
              </span>
            </div>
          </div>
        </div>

        {/* Contact & Support Links Card */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4 md:col-span-2">
          <div className="flex items-center space-x-2.5 rtl:space-x-reverse border-b border-slate-100 dark:border-slate-800 pb-3">
            <Mail className="w-5 h-5 text-blue-600 shrink-0 aspect-square" />
            <h3 className="text-sm font-extrabold text-slate-900 dark:text-white">
              Developer Contact & Support
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {APP_CONFIG.developerEmail && (
              <button
                onClick={handleContactDev}
                className="p-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-2xl text-xs shadow-xs transition flex items-center justify-center space-x-2 rtl:space-x-reverse min-h-[44px]"
              >
                <Mail className="w-4 h-4 shrink-0 aspect-square" />
                <span>{t.contactDeveloper}</span>
              </button>
            )}

            {APP_CONFIG.websiteUrl && (
              <a
                href={APP_CONFIG.websiteUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="p-3.5 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold border border-slate-200 dark:border-slate-700 rounded-2xl text-xs transition flex items-center justify-center space-x-2 rtl:space-x-reverse min-h-[44px]"
              >
                <Globe className="w-4 h-4 text-blue-600 shrink-0 aspect-square" />
                <span>{t.officialWebsite}</span>
                <ExternalLink className="w-3.5 h-3.5 text-slate-400 shrink-0 aspect-square" />
              </a>
            )}

            {APP_CONFIG.supportUrl && (
              <a
                href={APP_CONFIG.supportUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="p-3.5 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold border border-slate-200 dark:border-slate-700 rounded-2xl text-xs transition flex items-center justify-center space-x-2 rtl:space-x-reverse min-h-[44px]"
              >
                <HelpCircle className="w-4 h-4 text-emerald-600 shrink-0 aspect-square" />
                <span>{t.support}</span>
                <ExternalLink className="w-3.5 h-3.5 text-slate-400 shrink-0 aspect-square" />
              </a>
            )}
          </div>
        </div>

        {/* Legal & Open Source Licenses Card */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 shadow-sm space-y-4 md:col-span-2">
          <div className="flex items-center space-x-2.5 rtl:space-x-reverse border-b border-slate-100 dark:border-slate-800 pb-3">
            <Lock className="w-5 h-5 text-amber-600 shrink-0 aspect-square" />
            <h3 className="text-sm font-extrabold text-slate-900 dark:text-white">
              Legal Policies & Licenses
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <button
              onClick={() => setActiveModal('privacy')}
              className="p-3 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold border border-slate-200 dark:border-slate-700 rounded-2xl text-xs transition flex items-center justify-between min-h-[44px]"
            >
              <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <FileText className="w-4 h-4 text-blue-600 shrink-0 aspect-square" />
                <span>{t.privacyPolicy}</span>
              </div>
              <span className="text-blue-600 font-extrabold">&rarr;</span>
            </button>

            <button
              onClick={() => setActiveModal('terms')}
              className="p-3 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold border border-slate-200 dark:border-slate-700 rounded-2xl text-xs transition flex items-center justify-between min-h-[44px]"
            >
              <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 aspect-square" />
                <span>{t.termsOfUse}</span>
              </div>
              <span className="text-emerald-600 font-extrabold">&rarr;</span>
            </button>

            <button
              onClick={() => setActiveModal('licenses')}
              className="p-3 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold border border-slate-200 dark:border-slate-700 rounded-2xl text-xs transition flex items-center justify-between min-h-[44px]"
            >
              <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <Code2 className="w-4 h-4 text-indigo-600 shrink-0 aspect-square" />
                <span>{t.openSourceLicenses}</span>
              </div>
              <span className="text-indigo-600 font-extrabold">&rarr;</span>
            </button>
          </div>
        </div>
      </div>

      {/* Modal Dialogs for Privacy, Terms, Licenses */}
      {activeModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-2xl max-h-[80vh] flex flex-col shadow-xl text-slate-900 dark:text-white overflow-hidden relative">
            {/* Modal Header */}
            <div className="p-4 bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between shrink-0">
              <h3 className="text-base font-extrabold text-slate-900 dark:text-white">
                {activeModal === 'privacy' && t.privacyPolicy}
                {activeModal === 'terms' && t.termsOfUse}
                {activeModal === 'licenses' && t.openSourceLicenses}
              </h3>
              <button
                onClick={() => setActiveModal(null)}
                className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition aspect-square min-w-[36px] min-h-[36px] flex items-center justify-center"
              >
                <X className="w-5 h-5 shrink-0 aspect-square" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 overflow-y-auto space-y-4 text-xs font-medium text-slate-700 dark:text-slate-300 leading-relaxed">
              {activeModal === 'privacy' && (
                <pre className="whitespace-pre-wrap font-sans">
                  {APP_CONFIG.privacyPolicy[language] || APP_CONFIG.privacyPolicy.en}
                </pre>
              )}

              {activeModal === 'terms' && (
                <pre className="whitespace-pre-wrap font-sans">
                  {APP_CONFIG.termsOfUse[language] || APP_CONFIG.termsOfUse.en}
                </pre>
              )}

              {activeModal === 'licenses' && (
                <div className="space-y-3">
                  <p className="text-slate-500 mb-4">
                    Kiddos SafeGuard is built with gratitude using the following open source
                    components:
                  </p>
                  {APP_CONFIG.openSourceLicenses.map((lib, idx) => (
                    <div
                      key={idx}
                      className="p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl flex items-center justify-between"
                    >
                      <div>
                        <h4 className="font-bold text-slate-900 dark:text-white text-xs">
                          {lib.name}{' '}
                          <span className="text-[10px] text-slate-400 font-mono">
                            v{lib.version}
                          </span>
                        </h4>
                        <span className="text-[10px] text-blue-600 dark:text-blue-400 font-semibold">
                          {lib.license}
                        </span>
                      </div>
                      <a
                        href={lib.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[11px] text-slate-500 hover:text-blue-600 flex items-center gap-1 font-bold"
                      >
                        <span>View Repository</span>
                        <ExternalLink className="w-3 h-3 shrink-0 aspect-square" />
                      </a>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-50 dark:bg-slate-800 border-t border-slate-200 dark:border-slate-700 text-right shrink-0">
              <button
                onClick={() => setActiveModal(null)}
                className="px-5 py-2.5 bg-slate-800 dark:bg-slate-700 hover:bg-slate-900 text-white font-bold text-xs rounded-2xl transition min-h-[40px]"
              >
                {t.close}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
