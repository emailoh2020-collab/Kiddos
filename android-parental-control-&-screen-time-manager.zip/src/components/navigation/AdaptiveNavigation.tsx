import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { translations } from '../../data/translations';
import { formatChildName } from '../../utils/locale';
import { useResponsiveLayout } from '../../utils/useResponsiveLayout';
import { AppIcon } from '../common/AppIcon';
import {
  LayoutDashboard,
  Calendar,
  Layers,
  BarChart3,
  ListOrdered,
  Camera,
  Settings,
  Info,
  ChevronRight,
  ShieldCheck,
  Menu,
  X,
  Smartphone,
  Sliders,
  Sparkles,
  Globe,
  Battery,
} from 'lucide-react';

interface AdaptiveNavigationProps {
  activeTab: string;
  onSelectTab: (tabId: string) => void;
  children: React.ReactNode;
}

export const AdaptiveNavigation: React.FC<AdaptiveNavigationProps> = ({
  activeTab,
  onSelectTab,
  children,
}) => {
  const { role, language, currentMode, child } = useApp();
  const t = translations[language];
  const { isCompact, isTablet, isExpanded } = useResponsiveLayout();
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);

  const navItems = [
    { id: 'overview', label: t.dashboard, icon: LayoutDashboard, primary: true },
    { id: 'smart_block', label: t.smartBlockModesTitle || 'Smart Block 2.0', icon: Sparkles, primary: true },
    { id: 'schedule', label: t.schedule, icon: Calendar, primary: true },
    { id: 'apps', label: t.apps, icon: Layers, primary: true },
    { id: 'web_filter', label: 'Web Filtering', icon: Globe, primary: true },
    { id: 'battery', label: 'Battery Monitor', icon: Battery, primary: true },
    { id: 'usage_modes', label: t.usageModes || 'Usage Modes', icon: Sparkles, primary: true },
    { id: 'statistics', label: t.statistics, icon: BarChart3, primary: true },
    { id: 'eventLog', label: t.eventLog, icon: ListOrdered, primary: false },
    { id: 'verification', label: t.verification, icon: Camera, primary: false },
    { id: 'settings', label: t.settings, icon: Settings, primary: true },
    { id: 'about', label: t.aboutMenu, icon: Info, primary: false },
  ];

  // If in Child mode, we just render children directly (Child dashboard is a focused view)
  if (role === 'child') {
    return <div className="w-full">{children}</div>;
  }

  // Tablet & Desktop Layout: Left / Right Navigation Rail or Drawer
  if (isTablet) {
    return (
      <div className="flex flex-row gap-6 w-full items-start">
        {/* Navigation Rail / Drawer on Tablet */}
        <aside
          aria-label="Parent Navigation"
          className={`shrink-0 sticky top-20 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-3 shadow-sm transition-all flex flex-col justify-between ${
            isExpanded ? 'w-64 p-4' : 'w-20 items-center'
          }`}
          style={{ minHeight: 'calc(100vh - 120px)' }}
        >
          {/* Top Brand / Account Header in Drawer */}
          <div className="space-y-4">
            {isExpanded && (
              <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200/80 dark:border-slate-700/60 flex items-center space-x-3 rtl:space-x-reverse mb-2">
                <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300 flex items-center justify-center text-lg font-bold shrink-0 aspect-square">
                  {child.avatar || '👦'}
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-black text-slate-900 dark:text-white truncate">
                    {formatChildName(child.name)}
                  </div>
                  <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">
                    {t.parentAccess}
                  </div>
                </div>
              </div>
            )}

            {/* Navigation Links */}
            <nav className="space-y-1.5 w-full">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onSelectTab(item.id)}
                    title={item.label}
                    className={`w-full flex items-center rounded-2xl transition-all font-bold ${
                      isExpanded
                        ? 'px-3.5 py-3 space-x-3 rtl:space-x-reverse text-xs sm:text-sm'
                        : 'p-3 justify-center'
                    } ${
                      isActive
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <div className="shrink-0 aspect-square flex items-center justify-center">
                      <Icon className="w-5 h-5 shrink-0 aspect-square" />
                    </div>
                    {isExpanded && <span className="truncate">{item.label}</span>}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Footer Info in Drawer */}
          {isExpanded && (
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 font-medium text-center">
              Material 3 Adaptive Tablet
            </div>
          )}
        </aside>

        {/* Content View Pane */}
        <div className="flex-1 min-w-0">{children}</div>
      </div>
    );
  }

  // Smartphone Layout (Compact < 600px):
  // Bottom Navigation Bar only
  return (
    <div className="w-full pb-20">
      {/* Main Content Area on Phone */}
      <div className="w-full">{children}</div>

      {/* Smartphone Bottom Navigation Bar */}
      <div
        role="navigation"
        aria-label="Mobile Navigation"
        className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 px-3 py-2 flex items-center justify-around shadow-lg"
      >
        {[
          { id: 'overview', label: t.dashboard, icon: LayoutDashboard },
          { id: 'apps', label: t.apps, icon: Layers },
          { id: 'schedule', label: t.schedule, icon: Calendar },
          { id: 'statistics', label: t.statistics, icon: BarChart3 },
          { id: 'settings', label: t.settings, icon: Settings },
        ].map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-xl transition-all min-w-[56px] min-h-[44px] ${
                isActive
                  ? 'text-blue-600 font-bold dark:text-blue-400'
                  : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 font-medium'
              }`}
            >
              <div
                className={`p-1 rounded-full aspect-square flex items-center justify-center transition-all ${
                  isActive ? 'bg-blue-50 text-blue-600 dark:bg-blue-900/40' : ''
                }`}
              >
                <Icon className="w-5 h-5 shrink-0 aspect-square" />
              </div>
              <span className="text-[10px] mt-0.5 tracking-tight truncate max-w-[60px]">
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
