import React from 'react';
import {
  LucideIcon,
  PhoneCall,
  MessageSquare,
  Calculator,
  Camera,
  GraduationCap,
  BookOpen,
  Video,
  Film,
  Gamepad2,
  Globe,
  Music,
  MapPin,
  Sparkles,
  Clock,
  Lock,
  ShieldCheck,
  ShieldAlert,
  Layers,
  Settings,
  User,
  Users,
  BarChart3,
  ListOrdered,
  Plus,
  HelpCircle,
  Smartphone,
  Check,
  X,
  Sliders,
  Wrench,
  Calendar,
  Wifi,
  Battery,
  Eye,
  EyeOff,
  Trash2,
  Edit3,
  AlertTriangle,
  Key,
  RefreshCw,
  FileText,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Info,
  Wand2,
  ChevronRight,
  ArrowLeft,
  Sun,
  Moon,
  Copy,
  ExternalLink,
  Code2,
  Mail,
  Folder,
  FolderPlus,
} from 'lucide-react';

const LUCIDE_NAME_MAP: Record<string, LucideIcon> = {
  PhoneCall,
  MessageSquare,
  Calculator,
  Camera,
  GraduationCap,
  BookOpen,
  Video,
  Film,
  Gamepad2,
  Globe,
  Music,
  MapPin,
  Sparkles,
  Clock,
  Lock,
  ShieldCheck,
  ShieldAlert,
  Layers,
  Settings,
  User,
  Users,
  BarChart3,
  ListOrdered,
  Plus,
  HelpCircle,
  Smartphone,
  Check,
  X,
  Sliders,
  Wrench,
  Calendar,
  Wifi,
  Battery,
  Eye,
  EyeOff,
  Trash2,
  Edit3,
  AlertTriangle,
  Key,
  RefreshCw,
  FileText,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Info,
  Wand2,
  ChevronRight,
  ArrowLeft,
  Sun,
  Moon,
  Copy,
  ExternalLink,
  Code2,
  Mail,
  Folder,
  FolderPlus,
};

export type AppIconSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl' | '3xl' | 'custom';
export type AppIconShape = 'rounded' | 'circle' | 'squircle' | 'none';

export interface AppIconProps {
  icon?: LucideIcon | React.ComponentType<{ className?: string; size?: number }> | string;
  text?: string;
  size?: AppIconSize;
  customSizePx?: number;
  shape?: AppIconShape;
  className?: string;
  iconClassName?: string;
  containerClassName?: string;
  colorScheme?: 'blue' | 'indigo' | 'emerald' | 'amber' | 'red' | 'purple' | 'slate' | 'custom';
  contentDescription?: string;
  ariaHidden?: boolean;
}

const SIZE_MAP: Record<AppIconSize, { box: string; iconSize: number; text: string; padding: string }> = {
  xs: { box: 'w-5 h-5 min-w-[20px] min-h-[20px] max-w-[20px] max-h-[20px]', iconSize: 12, text: 'text-[9px]', padding: 'p-0.5' },
  sm: { box: 'w-7 h-7 min-w-[28px] min-h-[28px] max-w-[28px] max-h-[28px]', iconSize: 14, text: 'text-[11px]', padding: 'p-1' },
  md: { box: 'w-8.5 h-8.5 sm:w-9 sm:h-9 min-w-[34px] min-h-[34px] max-w-[36px] max-h-[36px]', iconSize: 17, text: 'text-xs', padding: 'p-1.5' },
  lg: { box: 'w-10 h-10 sm:w-11 sm:h-11 min-w-[40px] min-h-[40px] max-w-[44px] max-h-[44px]', iconSize: 20, text: 'text-sm', padding: 'p-2' },
  xl: { box: 'w-13 h-13 sm:w-14 sm:h-14 min-w-[52px] min-h-[52px] max-w-[56px] max-h-[56px]', iconSize: 26, text: 'text-lg', padding: 'p-2.5' },
  '2xl': { box: 'w-16 h-16 sm:w-18 sm:h-18 min-w-[64px] min-h-[64px] max-w-[72px] max-h-[72px]', iconSize: 32, text: 'text-xl', padding: 'p-3' },
  '3xl': { box: 'w-20 h-20 sm:w-22 sm:h-22 min-w-[80px] min-h-[80px] max-w-[88px] max-h-[88px]', iconSize: 40, text: 'text-2xl', padding: 'p-3.5' },
  custom: { box: '', iconSize: 20, text: 'text-xs', padding: 'p-1.5' },
};

const SHAPE_MAP: Record<AppIconShape, string> = {
  rounded: 'rounded-xl',
  squircle: 'rounded-2xl',
  circle: 'rounded-full',
  none: '',
};

const COLOR_MAP = {
  blue: 'bg-blue-50 text-blue-600 border border-blue-200/80 dark:bg-blue-900/40 dark:text-blue-400 dark:border-blue-700/60',
  indigo: 'bg-indigo-50 text-indigo-600 border border-indigo-200/80 dark:bg-indigo-900/40 dark:text-indigo-400 dark:border-indigo-700/60',
  emerald: 'bg-emerald-50 text-emerald-600 border border-emerald-200/80 dark:bg-emerald-900/40 dark:text-emerald-400 dark:border-emerald-700/60',
  amber: 'bg-amber-50 text-amber-600 border border-amber-200/80 dark:bg-amber-900/40 dark:text-amber-400 dark:border-amber-700/60',
  red: 'bg-red-50 text-red-600 border border-red-200/80 dark:bg-red-900/40 dark:text-red-400 dark:border-red-700/60',
  purple: 'bg-purple-50 text-purple-600 border border-purple-200/80 dark:bg-purple-900/40 dark:text-purple-400 dark:border-purple-700/60',
  slate: 'bg-slate-100 text-slate-700 border border-slate-200/80 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700',
  custom: '',
};

/**
 * AppIcon Component
 * Enforces a strict 1:1 aspect ratio across phones, tablets, and all responsive views.
 * Handles React Lucide component types, string icon names, emojis, and textual avatars gracefully.
 */
export const AppIcon: React.FC<AppIconProps> = ({
  icon,
  text,
  size = 'md',
  customSizePx,
  shape = 'squircle',
  className = '',
  iconClassName = '',
  containerClassName = '',
  colorScheme = 'blue',
  contentDescription,
  ariaHidden = !contentDescription,
}) => {
  const sizeConfig = SIZE_MAP[size];
  const shapeClass = SHAPE_MAP[shape];
  const colorClass = COLOR_MAP[colorScheme];

  const customStyle: React.CSSProperties = customSizePx
    ? {
        width: `${customSizePx}px`,
        height: `${customSizePx}px`,
        minWidth: `${customSizePx}px`,
        minHeight: `${customSizePx}px`,
        maxWidth: `${customSizePx}px`,
        maxHeight: `${customSizePx}px`,
        aspectRatio: '1 / 1',
      }
    : {
        aspectRatio: '1 / 1',
      };

  // Resolve icon component or emoji string
  let ResolvedComponent: React.ComponentType<{ className?: string; size?: number }> | null = null;
  let stringGlyph: string | null = null;

  if (typeof icon === 'string') {
    if (LUCIDE_NAME_MAP[icon]) {
      ResolvedComponent = LUCIDE_NAME_MAP[icon];
    } else {
      stringGlyph = icon;
    }
  } else if (typeof icon === 'function' || (typeof icon === 'object' && icon !== null)) {
    ResolvedComponent = icon as React.ComponentType<{ className?: string; size?: number }>;
  }

  const calculatedSize = customSizePx ? Math.round(customSizePx * 0.55) : sizeConfig.iconSize;

  return (
    <div
      role={contentDescription ? 'img' : undefined}
      aria-label={contentDescription}
      aria-hidden={ariaHidden}
      style={customStyle}
      className={`relative inline-flex items-center justify-center shrink-0 select-none overflow-hidden aspect-square ${
        sizeConfig.box
      } ${shapeClass} ${colorClass} ${containerClassName} ${className}`}
    >
      {ResolvedComponent ? (
        <ResolvedComponent
          size={calculatedSize}
          className={`shrink-0 aspect-square ${iconClassName}`}
        />
      ) : stringGlyph ? (
        <span className={`font-bold leading-none select-none text-center ${sizeConfig.text}`}>
          {stringGlyph}
        </span>
      ) : text ? (
        <span className={`font-black uppercase tracking-tight text-center select-none ${sizeConfig.text}`}>
          {text}
        </span>
      ) : null}
    </div>
  );
};
