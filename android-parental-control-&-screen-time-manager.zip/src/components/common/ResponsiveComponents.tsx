import React from 'react';
import { LucideIcon } from 'lucide-react';
import { AppIcon, AppIconProps } from './AppIcon';
import { formatSecondsToDigital } from '../../utils/time';

/**
 * DashboardCard
 * Responsive container card with consistent border-radius, padding, and elevation
 */
export interface DashboardCardProps {
  title?: string;
  subtitle?: string;
  icon?: LucideIcon;
  badge?: React.ReactNode;
  headerAction?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
}

export const DashboardCard: React.FC<DashboardCardProps> = ({
  title,
  subtitle,
  icon: IconComponent,
  badge,
  headerAction,
  children,
  className = '',
  onClick,
}) => {
  return (
    <div
      onClick={onClick}
      className={`bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl sm:rounded-2xl p-3.5 sm:p-4.5 shadow-xs transition-all flex flex-col justify-between ${
        onClick ? 'cursor-pointer hover:border-slate-300 dark:hover:border-slate-700 hover:shadow-sm' : ''
      } ${className}`}
    >
      {(title || IconComponent || badge || headerAction) && (
        <div className="flex items-start justify-between gap-2 mb-2.5 sm:mb-3">
          <div className="flex items-center space-x-2.5 rtl:space-x-reverse min-w-0">
            {IconComponent && (
              <AppIcon icon={IconComponent} size="sm" colorScheme="blue" shape="rounded" />
            )}
            <div className="min-w-0">
              {title && (
                <h3 className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-white truncate leading-tight">
                  {title}
                </h3>
              )}
              {subtitle && (
                <p className="text-[10px] sm:text-[11px] text-slate-500 dark:text-slate-400 font-medium truncate mt-0.5">
                  {subtitle}
                </p>
              )}
            </div>
          </div>
          <div className="flex items-center space-x-1.5 rtl:space-x-reverse shrink-0">
            {badge}
            {headerAction}
          </div>
        </div>
      )}
      <div className="flex-1">{children}</div>
    </div>
  );
};

/**
 * CountdownTimer
 * Adaptive proportional timer that scales cleanly from 320px phone to 12.9" tablet
 */
export interface CountdownTimerProps {
  seconds: number;
  label?: string;
  sublabel?: string;
  variant?: 'primary' | 'warning' | 'danger' | 'locked';
  size?: 'sm' | 'md' | 'lg' | 'adaptive';
  className?: string;
}

export const CountdownTimer: React.FC<CountdownTimerProps> = ({
  seconds,
  label,
  sublabel,
  variant = 'primary',
  size = 'adaptive',
  className = '',
}) => {
  const formatted = formatSecondsToDigital(seconds);

  const colorStyles = {
    primary: 'text-slate-900 dark:text-white',
    warning: 'text-amber-600 dark:text-amber-400',
    danger: 'text-red-600 dark:text-red-400',
    locked: 'text-slate-400 dark:text-slate-500',
  };

  const fontSizes = {
    sm: 'text-xl sm:text-2xl',
    md: 'text-2xl sm:text-3xl md:text-4xl',
    lg: 'text-3xl sm:text-4xl md:text-5xl',
    adaptive: 'text-2xl xs:text-3xl sm:text-4xl md:text-5xl lg:text-6xl',
  };

  return (
    <div className={`text-center select-none ${className}`}>
      {label && (
        <span className="text-[10px] sm:text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider block mb-0.5 sm:mb-1">
          {label}
        </span>
      )}
      <div
        className={`font-mono font-black tracking-tight leading-none ${fontSizes[size]} ${colorStyles[variant]} transition-all`}
      >
        {formatted}
      </div>
      {sublabel && (
        <p className="text-[11px] sm:text-xs text-slate-500 dark:text-slate-400 font-medium mt-1.5 max-w-sm mx-auto">
          {sublabel}
        </p>
      )}
    </div>
  );
};

/**
 * ActionButton
 * Touch-friendly (>=40dp) button with compact padding and crisp typography
 */
export interface ActionButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'danger' | 'success' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  icon?: LucideIcon;
  iconPosition?: 'left' | 'right';
  fullWidth?: boolean;
}

export const ActionButton: React.FC<ActionButtonProps> = ({
  children,
  variant = 'primary',
  size = 'md',
  icon: IconComponent,
  iconPosition = 'left',
  fullWidth = false,
  className = '',
  disabled,
  ...props
}) => {
  const sizeClasses = {
    sm: 'min-h-[32px] px-2.5 py-1 text-[11px] rounded-lg gap-1.5',
    md: 'min-h-[38px] px-3.5 py-2 text-xs sm:text-sm rounded-xl gap-2',
    lg: 'min-h-[44px] px-4.5 py-2.5 text-xs sm:text-sm rounded-xl gap-2',
  };

  const variantClasses = {
    primary: 'bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white shadow-xs focus:ring-2 focus:ring-blue-500/50',
    secondary: 'bg-slate-100 hover:bg-slate-200 active:bg-slate-300 text-slate-800 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-200',
    outline: 'bg-transparent hover:bg-slate-50 border border-slate-200 text-slate-700 dark:border-slate-700 dark:hover:bg-slate-800 dark:text-slate-200',
    danger: 'bg-red-600 hover:bg-red-700 active:bg-red-800 text-white shadow-xs focus:ring-2 focus:ring-red-500/50',
    success: 'bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white shadow-xs focus:ring-2 focus:ring-emerald-500/50',
    ghost: 'bg-transparent hover:bg-slate-100 text-slate-600 dark:hover:bg-slate-800 dark:text-slate-400',
  };

  return (
    <button
      className={`inline-flex items-center justify-center font-bold transition-all select-none disabled:opacity-50 disabled:pointer-events-none ${
        fullWidth ? 'w-full' : ''
      } ${sizeClasses[size]} ${variantClasses[variant]} ${className}`}
      disabled={disabled}
      {...props}
    >
      {IconComponent && iconPosition === 'left' && (
        <IconComponent className="w-4 h-4 shrink-0 aspect-square" />
      )}
      <span className="truncate">{children}</span>
      {IconComponent && iconPosition === 'right' && (
        <IconComponent className="w-4 h-4 shrink-0 aspect-square" />
      )}
    </button>
  );
};

/**
 * PinKey
 * Uniform square numeric key for the parent PIN pad (never stretched unevenly)
 */
export interface PinKeyProps {
  value: string;
  onClick: () => void;
  icon?: LucideIcon;
  subtext?: string;
  disabled?: boolean;
}

export const PinKey: React.FC<PinKeyProps> = ({
  value,
  onClick,
  icon: IconComponent,
  subtext,
  disabled = false,
}) => {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className="w-full aspect-square min-h-[38px] max-h-[54px] sm:min-h-[52px] sm:max-h-[76px] rounded-xl sm:rounded-2xl bg-slate-50 hover:bg-slate-100 active:bg-blue-50 active:text-blue-600 dark:bg-slate-800/80 dark:hover:bg-slate-800 dark:active:bg-blue-900/40 dark:active:text-blue-400 border border-slate-200/80 dark:border-slate-700/80 text-slate-900 dark:text-slate-100 font-bold flex flex-col items-center justify-center transition-all disabled:opacity-40 disabled:pointer-events-none shadow-xs hover:border-slate-300 dark:hover:border-slate-600"
    >
      {IconComponent ? (
        <IconComponent className="w-4 h-4 sm:w-6 sm:h-6 shrink-0 aspect-square" />
      ) : (
        <>
          <span className="text-sm sm:text-2xl font-black leading-none">{value}</span>
          {subtext && (
            <span className="text-[7px] sm:text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">
              {subtext}
            </span>
          )}
        </>
      )}
    </button>
  );
};
