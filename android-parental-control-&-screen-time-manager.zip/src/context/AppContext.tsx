import React, { createContext, useContext, useEffect, useState, useCallback, useMemo } from 'react';
import { AppInfo, AppSettings, ChildProfile, DayOfWeek, EventType, Language, ParentalControlMode, Role, SessionState, SmartBlockConfig, SmartBlockMode, UsageMode, WeeklySchedule, WebFilterConfig, AppBatteryUsage, BlockedUrlRule, WebCategory } from '../types';
import { isRtlLanguage } from '../data/languages';
import {
  addEventLog,
  addVerificationRecord,
  DEFAULT_SMART_BLOCK_CONFIG,
  DEFAULT_WEB_FILTER_CONFIG,
  DEFAULT_BATTERY_USAGE,
  getStoredApps,
  getStoredChild,
  getStoredChildrenList,
  getStoredActiveChildId,
  getStoredEventLogs,
  getStoredSchedule,
  getStoredSessionState,
  getStoredSettings,
  saveApps,
  saveChild,
  saveChildrenList,
  saveActiveChildId,
  saveSchedule,
  saveSessionState,
  saveSettings,
} from '../utils/storage';
import { getFailedAttemptDelaySeconds, verifyPin } from '../utils/crypto';
import { getNextAllowedPeriod, isCurrentTimeScheduledAllowed } from '../utils/time';
import {
  DEFAULT_SMART_BLOCK_MODES,
  getEffectiveActiveSmartBlock,
  getNextSmartBlockTransition,
  detectScheduleOverlaps,
  evaluateAppAccessInSmartBlock,
  AppAccessSmartBlockDecision,
  SmartBlockTransitionInfo,
  ScheduleOverlap,
} from '../utils/smartBlockEngine';
import { nativeBridge } from '../utils/nativeBridge';
import { evaluateApplicationAccess } from '../utils/ruleEvaluator';

interface NotificationMessage {
  id: string;
  title: string;
  message: string;
  type: 'warning' | 'info' | 'error' | 'success';
  timestamp: number;
}

interface AppContextType {
  role: Role;
  setRole: (role: Role) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  child: ChildProfile;
  childrenList: ChildProfile[];
  activeChildId: string;
  updateChildProfile: (profile: ChildProfile) => void;
  addChildProfile: (newChild: Omit<ChildProfile, 'id'>) => void;
  deleteChildProfile: (id: string) => void;
  selectActiveChild: (id: string) => void;
  schedule: WeeklySchedule;
  updateSchedule: (schedule: WeeklySchedule) => void;
  apps: AppInfo[];
  updateAppStatus: (packageName: string, isAllowed: boolean, allowDuringLock: boolean) => void;
  settings: AppSettings;
  updateSettings: (settings: AppSettings) => void;
  session: SessionState;
  
  // Smart Block 2.0 (Multi-Schedule System)
  smartBlockModes: SmartBlockMode[];
  activeSmartBlockMode: SmartBlockMode | null;
  isSmartBlockActiveNow: boolean;
  nextSmartBlockTransition: SmartBlockTransitionInfo | null;
  overlappingSchedules: ScheduleOverlap[];
  isAppRestrictedBySmartBlock: (app: AppInfo) => boolean;
  getSmartBlockRestrictionDetails: (app: AppInfo) => AppAccessSmartBlockDecision;
  createSmartBlockMode: (mode: Omit<SmartBlockMode, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateSmartBlockMode: (mode: SmartBlockMode) => void;
  deleteSmartBlockMode: (modeId: string) => void;
  duplicateSmartBlockMode: (modeId: string) => void;
  toggleSmartBlockMode: (modeId: string, enabled: boolean) => void;
  // Legacy / backward compatibility
  smartBlockConfig: SmartBlockConfig;
  updateSmartBlockConfig: (config: SmartBlockConfig) => void;

  // Web Filtering
  webFilterConfig: WebFilterConfig;
  updateWebFilterConfig: (config: WebFilterConfig) => void;
  checkUrlAccess: (url: string) => { allowed: boolean; category?: string; reason?: string };

  // Battery Monitor
  batteryUsage: AppBatteryUsage[];
  optimizeBatteryApp: (packageName: string) => void;
  
  // Usage Modes
  setActiveUsageMode: (modeId: string) => void;
  isAppAllowedInCurrentMode: (app: AppInfo) => boolean;
  getActiveUsageMode: () => UsageMode | undefined;
  
  // Real-time calculated values
  currentMode: ParentalControlMode;
  parentSessionActive: boolean;
  remainingDailySeconds: number;
  remainingSessionSeconds: number;
  isLocked: boolean;
  lockReason: string | null;
  
  // Actions
  authenticateParentPin: (pin: string) => Promise<{ success: boolean; delaySeconds?: number }>;
  exitParentSession: () => void;
  touchParentActivity: () => void;
  evaluateCurrentState: () => { mode: ParentalControlMode; isLocked: boolean; lockReason: SessionState['lockReason'] };
  grantExtraTime: (minutes: number, reason?: string) => void;
  consumeAndLockUntilNextSchedule: (reason?: string) => void;
  forceLockDevice: (reason: 'manual_lock' | 'test_mode' | 'schedule_expired' | 'daily_limit_reached') => void;
  unlockDeviceTemp: () => void;
  simulateReboot: () => void;
  simulateTimeChange: () => void;
  logEvent: (type: EventType, description: string) => void;
  addEventLog: (type: EventType, description: string, childName?: string) => void;
  addNotification: (title: string, message: string, type: NotificationMessage['type']) => void;
  notifications: NotificationMessage[];
  dismissNotification: (id: string) => void;
  
  // Modals & UI States
  showPinModal: boolean;
  pinSuccessCallback: (() => void) | null;
  openPinModal: (onSuccess?: () => void, title?: string) => void;
  closePinModal: () => void;
  showExtraTimeModal: boolean;
  setShowExtraTimeModal: (open: boolean) => void;
  showExportModal: boolean;
  setShowExportModal: (open: boolean) => void;
  showSetupWizard: boolean;
  setShowSetupWizard: (open: boolean) => void;
  
  // Camera Verification
  captureVerificationPhoto: (photoUrl: string, reason: string) => void;

  // Account Selection Launch Gate
  accountSelected: boolean;
  setAccountSelected: (selected: boolean) => void;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [role, setRole] = useState<Role>('parent');
  const [language, setLanguage] = useState<Language>('en');
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [childrenList, setChildrenList] = useState<ChildProfile[]>(getStoredChildrenList());
  const [activeChildId, setActiveChildIdState] = useState<string>(getStoredActiveChildId());
  const [child, setChild] = useState<ChildProfile>(getStoredChild());
  const [schedule, setSchedule] = useState<WeeklySchedule>(getStoredSchedule());
  const [apps, setApps] = useState<AppInfo[]>(getStoredApps());
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [session, setSession] = useState<SessionState>(getStoredSessionState(activeChildId));
  const [notifications, setNotifications] = useState<NotificationMessage[]>([]);
  const [accountSelected, setAccountSelected] = useState<boolean>(false);
  
  // Modals
  const [showPinModal, setShowPinModal] = useState(false);
  const [pinSuccessCallback, setPinSuccessCallback] = useState<(() => void) | null>(null);
  const [showExtraTimeModal, setShowExtraTimeModal] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);
  const [showSetupWizard, setShowSetupWizard] = useState(false);
  
  // Parent Session & Activity Tracking
  const [parentSessionActive, setParentSessionActive] = useState(false);
  const [lastParentActivity, setLastParentActivity] = useState(Date.now());
  
  // Timer calculations
  const [remainingDailySeconds, setRemainingDailySeconds] = useState(0);
  const [remainingSessionSeconds, setRemainingSessionSeconds] = useState(0);
  
  // Initial load
  useEffect(() => {
    getStoredSettings().then(st => {
      setSettings(st);
      setLanguage(st.language);
    });
  }, []);

  // Sync html dir attribute for RTL support (Arabic, Urdu, Persian)
  useEffect(() => {
    document.documentElement.dir = isRtlLanguage(language) ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language]);

  const touchParentActivity = useCallback(() => {
    setLastParentActivity(Date.now());
  }, []);

  // Centralized Parental-Control State Evaluator
  const evaluateCurrentState = useCallback(() => {
    const now = Date.now();
    const nowDate = new Date(now);
    const isFreeMode = settings?.controlMode === 'free';

    // Check Extra Time Status
    const extraTimeEnd = session.extraTimeEndTimestamp;
    const isExtraTimeActive = extraTimeEnd !== null && extraTimeEnd > now;
    const remainingExtraSec = isExtraTimeActive ? Math.max(0, Math.floor((extraTimeEnd - now) / 1000)) : 0;

    let remainingDailySec = 0;
    let remainingSessionSec = 0;
    let isScheduleAllowed = true;
    let shouldBeLocked = false;
    let reason: SessionState['lockReason'] = null;

    if (isFreeMode) {
      // FREE MODE: Daily Allowance Bank
      const dailyAllowanceSec = child.dailyFreeTimeAllowanceSeconds || 10800; // default 3 hours
      const usedSec = session.freeModeUsedSecondsToday || 0;
      remainingDailySec = Math.max(0, dailyAllowanceSec - usedSec);
      remainingSessionSec = remainingDailySec;

      if (session.isLocked && session.lockReason === 'manual_lock') {
        shouldBeLocked = true;
        reason = 'manual_lock';
      } else if (isExtraTimeActive) {
        shouldBeLocked = false;
        reason = null;
      } else if (remainingDailySec <= 0) {
        shouldBeLocked = true;
        reason = 'daily_limit_reached';
      }
    } else {
      // SCHEDULED MODE: Predefined Weekly Schedule Windows
      isScheduleAllowed = isCurrentTimeScheduledAllowed(schedule, nowDate);
      const dailyLimitSeconds = child.dailyLimitMinutes * 60;
      const elapsedTodaySec = session.elapsedTodayMinutes * 60;
      remainingDailySec = Math.max(0, dailyLimitSeconds - elapsedTodaySec);

      const sessionLimitSec = child.sessionLimitMinutes * 60;
      const activeSessionElapsedSec = (session.activeSessionDurationMinutes || 0) * 60;
      remainingSessionSec = Math.max(0, sessionLimitSec - activeSessionElapsedSec);

      if (session.isLocked && session.lockReason === 'manual_lock') {
        shouldBeLocked = true;
        reason = 'manual_lock';
      } else if (isExtraTimeActive) {
        shouldBeLocked = false;
        reason = null;
      } else if (!isScheduleAllowed) {
        shouldBeLocked = true;
        reason = 'schedule_expired';
      } else if (remainingDailySec <= 0) {
        shouldBeLocked = true;
        reason = 'daily_limit_reached';
      } else if (remainingSessionSec <= 0) {
        shouldBeLocked = true;
        reason = 'session_limit_reached';
      }
    }

    let mode: ParentalControlMode = 'PLAYING';
    if (parentSessionActive && role === 'parent') {
      mode = 'PARENT_SETTINGS';
    } else if (shouldBeLocked) {
      mode = 'LOCKED';
    } else if (isExtraTimeActive) {
      mode = 'EXTRA_TIME';
    }

    return {
      mode,
      isLocked: shouldBeLocked,
      lockReason: reason,
      isExtraTimeActive,
      remainingExtraSec,
      remainingDailySec,
      remainingSessionSec,
    };
  }, [schedule, child, session, settings?.controlMode, parentSessionActive, role]);

  const currentModeInfo = evaluateCurrentState();
  const currentMode = currentModeInfo.mode;

  const exitParentSession = useCallback(() => {
    setParentSessionActive(false);
    setRole('child');

    const now = Date.now();
    const nowDate = new Date(now);
    const isFreeMode = settings?.controlMode === 'free';
    const isScheduleAllowed = isCurrentTimeScheduledAllowed(schedule, nowDate);

    const extraTimeEnd = session.extraTimeEndTimestamp;
    const isExtraTimeActive = extraTimeEnd !== null && extraTimeEnd > now;

    let shouldBeLocked = false;
    let reason: SessionState['lockReason'] = null;

    if (session.isLocked && session.lockReason === 'manual_lock') {
      shouldBeLocked = true;
      reason = 'manual_lock';
    } else if (isExtraTimeActive) {
      shouldBeLocked = false;
      reason = null;
    } else if (isFreeMode) {
      const dailyAllowanceSec = child.dailyFreeTimeAllowanceSeconds || 10800;
      const usedSec = session.freeModeUsedSecondsToday || 0;
      if (dailyAllowanceSec - usedSec <= 0) {
        shouldBeLocked = true;
        reason = 'daily_limit_reached';
      }
    } else {
      const dailyLimitSeconds = child.dailyLimitMinutes * 60;
      const elapsedTodaySec = session.elapsedTodayMinutes * 60;
      const remainingDailySec = Math.max(0, dailyLimitSeconds - elapsedTodaySec);

      if (!isScheduleAllowed) {
        shouldBeLocked = true;
        reason = 'schedule_expired';
      } else if (remainingDailySec <= 0) {
        shouldBeLocked = true;
        reason = 'daily_limit_reached';
      }
    }

    const updatedSession: SessionState = {
      ...session,
      isLocked: shouldBeLocked,
      lockReason: reason,
      lastHeartbeatTimestamp: Date.now(),
    };

    setSession(updatedSession);
    saveSessionState(updatedSession, child.id);

    const modeLabel = shouldBeLocked ? 'LOCK MODE' : isExtraTimeActive ? 'EXTRA TIME MODE' : 'PLAY MODE';
    addEventLog('parent_settings_closed', `Parent settings closed. Evaluated state: ${modeLabel}`, child.name);
    addNotification(
      'Parent Settings Closed',
      `Switched to Child Usage Mode (${modeLabel}).`,
      shouldBeLocked ? 'warning' : 'success'
    );
  }, [schedule, child, session, settings?.controlMode]);

  // Main real-time engine ticker (runs every 1 second)
  useEffect(() => {
    if (!settings) return;

    const interval = setInterval(() => {
      const now = Date.now();
      const nowDate = new Date(now);
      const todayStr = nowDate.toISOString().split('T')[0];

      // 1. Midnight Reset Check
      let currentSession = session;
      if (currentSession.lastResetDateStr && currentSession.lastResetDateStr !== todayStr) {
        currentSession = {
          ...currentSession,
          freeModeUsedSecondsToday: 0,
          elapsedTodayMinutes: 0,
          activeSessionDurationMinutes: 0,
          extraTimeMinutes: 0,
          extraTimeEndTimestamp: null,
          extraTimeConsumed: false,
          lastResetDateStr: todayStr,
          isLocked: currentSession.lockReason === 'manual_lock' ? true : false,
          lockReason: currentSession.lockReason === 'manual_lock' ? 'manual_lock' : null,
          lastHeartbeatTimestamp: now,
        };
        setSession(currentSession);
        saveSessionState(currentSession, child.id);
        addEventLog('daily_reset', `Daily usage reset for date: ${todayStr}. Allowance refreshed!`, child.name);
        addNotification('Daily Reset', 'New daily screen time allowance is ready for today!', 'success');
      }

      // 2. Check parent session timeout
      if (parentSessionActive && role === 'parent') {
        const timeoutMs = (settings.parentSessionTimeoutMinutes || 5) * 60 * 1000;
        if (now - lastParentActivity > timeoutMs) {
          addEventLog('parent_session_expired', 'Parent administrative session expired due to inactivity.', child.name);
          exitParentSession();
          return;
        }
      }

      // 3. Check Extra Time Expiration
      if (currentSession.extraTimeEndTimestamp !== null && now >= currentSession.extraTimeEndTimestamp) {
        currentSession = {
          ...currentSession,
          extraTimeMinutes: 0,
          extraTimeEndTimestamp: null,
          extraTimeConsumed: true,
          isLocked: true,
          lockReason: 'extra_time_exhausted',
          lastHeartbeatTimestamp: now,
        };
        setSession(currentSession);
        saveSessionState(currentSession, child.id);
        addEventLog('extra_time_expired', 'Extra time session finished. Phone shut down until next scheduled time.', child.name);
        addNotification('Extra Time Ended', 'Extra time is up. Phone shut down until next scheduled time.', 'warning');
      }

      const isFreeMode = settings.controlMode === 'free';
      const isScheduleAllowed = isCurrentTimeScheduledAllowed(schedule, nowDate);
      const extraTimeEnd = currentSession.extraTimeEndTimestamp;
      const isExtraTimeActive = extraTimeEnd !== null && extraTimeEnd > now;
      const remainingExtraSec = isExtraTimeActive ? Math.max(0, Math.floor((extraTimeEnd - now) / 1000)) : 0;

      let remainingDailySec = 0;
      let remainingSessionSec = 0;
      let shouldBeLocked = false;
      let lockReason: SessionState['lockReason'] = null;

      if (isFreeMode) {
        const dailyAllowanceSec = child.dailyFreeTimeAllowanceSeconds || 10800;
        const usedSec = currentSession.freeModeUsedSecondsToday || 0;
        remainingDailySec = Math.max(0, dailyAllowanceSec - usedSec);
        remainingSessionSec = remainingDailySec;

        if (currentSession.isLocked && currentSession.lockReason === 'manual_lock') {
          shouldBeLocked = true;
          lockReason = 'manual_lock';
        } else if (isExtraTimeActive) {
          shouldBeLocked = false;
          lockReason = null;
        } else if (remainingDailySec <= 0) {
          shouldBeLocked = true;
          lockReason = 'daily_limit_reached';
        }
      } else {
        const dailyLimitSeconds = child.dailyLimitMinutes * 60;
        const elapsedTodaySec = currentSession.elapsedTodayMinutes * 60;
        remainingDailySec = Math.max(0, dailyLimitSeconds - elapsedTodaySec);

        const sessionLimitSec = child.sessionLimitMinutes * 60;
        const activeSessionElapsedSec = (currentSession.activeSessionDurationMinutes || 0) * 60;
        remainingSessionSec = Math.max(0, sessionLimitSec - activeSessionElapsedSec);

        if (currentSession.isLocked && currentSession.lockReason === 'manual_lock') {
          shouldBeLocked = true;
          lockReason = 'manual_lock';
        } else if (isExtraTimeActive) {
          shouldBeLocked = false;
          lockReason = null;
        } else if (!isScheduleAllowed) {
          shouldBeLocked = true;
          lockReason = 'schedule_expired';
        } else if (remainingDailySec <= 0) {
          shouldBeLocked = true;
          lockReason = 'daily_limit_reached';
        } else if (remainingSessionSec <= 0) {
          shouldBeLocked = true;
          lockReason = 'session_limit_reached';
        }
      }

      if (isExtraTimeActive) {
        setRemainingDailySeconds(remainingExtraSec);
        setRemainingSessionSeconds(remainingExtraSec);
      } else {
        setRemainingDailySeconds(remainingDailySec);
        setRemainingSessionSeconds(remainingSessionSec);
      }

      // Automatically transition to lock mode if needed
      if (shouldBeLocked !== currentSession.isLocked && !parentSessionActive) {
        const updatedSession: SessionState = {
          ...currentSession,
          isLocked: shouldBeLocked,
          lockReason,
          lastHeartbeatTimestamp: now,
        };
        setSession(updatedSession);
        saveSessionState(updatedSession, child.id);

        if (shouldBeLocked) {
          addEventLog('lock_activated', `Lock Mode automatically activated (${lockReason})`, child.name);
          addNotification('Lock Mode Activated', `Device locked due to: ${lockReason?.replace('_', ' ')}`, 'warning');
        }
      } else if (!shouldBeLocked && role === 'child' && !parentSessionActive) {
        // Tick time spent during active child usage
        const updatedSession: SessionState = {
          ...currentSession,
          freeModeUsedSecondsToday: isFreeMode
            ? (currentSession.freeModeUsedSecondsToday || 0) + 1
            : currentSession.freeModeUsedSecondsToday || 0,
          elapsedTodayMinutes: currentSession.elapsedTodayMinutes + (1 / 60),
          activeSessionDurationMinutes: currentSession.activeSessionDurationMinutes + (1 / 60),
          lastHeartbeatTimestamp: now,
        };
        setSession(updatedSession);
        saveSessionState(updatedSession, child.id);

        const activeSec = isExtraTimeActive ? remainingExtraSec : remainingDailySec;
        if (activeSec === 1800) {
          addNotification('Screen Time Warning', '30 minutes remaining in your allowance!', 'info');
        } else if (activeSec === 900) {
          addNotification('Screen Time Warning', '15 minutes remaining in your allowance!', 'warning');
        } else if (activeSec === 600) {
          addNotification('Screen Time Warning', '10 minutes remaining in your allowance!', 'warning');
        } else if (activeSec === 300) {
          addNotification('Screen Time Warning', '5 minutes remaining! Save your work.', 'warning');
        } else if (activeSec === 60) {
          addNotification('Screen Time Warning', '1 minute remaining! Device will lock soon.', 'error');
        }
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [schedule, child, session, settings, role, parentSessionActive, lastParentActivity, exitParentSession]);

  // Synchronize state with Native Android Layer (services & receivers)
  useEffect(() => {
    if (!settings) return;
    const isExtraTimeActive = session.extraTimeEndTimestamp !== null && session.extraTimeEndTimestamp > Date.now();
    nativeBridge.syncStateToNative({
      smartBlockModes: settings.smartBlockModes || DEFAULT_SMART_BLOCK_MODES,
      hasExtraTime: isExtraTimeActive,
      remainingDailySeconds,
      currentMode
    });
  }, [settings, session.extraTimeEndTimestamp, remainingDailySeconds, currentMode]);

  const addNotification = useCallback((title: string, message: string, type: NotificationMessage['type']) => {
    const now = Date.now();
    
    setNotifications(prev => {
      // Prevent duplicate identical notifications within 5 seconds
      const isDuplicate = prev.some(n => n.title === title && n.message === message && (now - n.timestamp) < 5000);
      if (isDuplicate) return prev;

      const newNotif: NotificationMessage = {
        id: `notif_${now}_${Math.random().toString(36).substring(2, 7)}`,
        title,
        message,
        type,
        timestamp: now,
      };

      // Auto dismiss after 5000ms (5 seconds)
      setTimeout(() => {
        setNotifications(current => current.filter(n => n.id !== newNotif.id));
      }, 5000);

      return [newNotif, ...prev.slice(0, 3)];
    });
  }, []);

  const dismissNotification = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  // Authenticate Parent PIN with brute force protection
  const authenticateParentPin = async (inputPin: string) => {
    if (!settings) return { success: false };

    // Check lockout delay
    if (settings.pinLockoutUntil && Date.now() < settings.pinLockoutUntil) {
      const waitSec = Math.ceil((settings.pinLockoutUntil - Date.now()) / 1000);
      return { success: false, delaySeconds: waitSec };
    }

    const isValid = await verifyPin(inputPin, settings.parentPinHash, settings.parentPinSalt);

    if (isValid) {
      // Reset failed attempts & start parent session
      const updatedSt = { ...settings, failedPinAttempts: 0, pinLockoutUntil: 0 };
      setSettings(updatedSt);
      saveSettings(updatedSt);
      setParentSessionActive(true);
      setLastParentActivity(Date.now());
      setRole('parent');
      addEventLog('pin_success', 'Parent PIN authenticated successfully', child.name);
      addEventLog('parent_session_started', 'Parent administrative session started', child.name);
      addNotification('Parent Authenticated', 'Administrative session active (auto-timeout enabled).', 'success');
      return { success: true };
    } else {
      const newAttempts = settings.failedPinAttempts + 1;
      const delaySec = getFailedAttemptDelaySeconds(newAttempts);
      const lockoutUntil = delaySec > 0 ? Date.now() + delaySec * 1000 : 0;

      const updatedSt = {
        ...settings,
        failedPinAttempts: newAttempts,
        pinLockoutUntil: lockoutUntil,
      };
      setSettings(updatedSt);
      saveSettings(updatedSt);
      addEventLog('pin_failed', `Failed PIN attempt #${newAttempts}`, child.name);
      addNotification('Failed PIN', `Incorrect PIN entered (Attempt ${newAttempts})`, 'error');

      return { success: false, delaySeconds: delaySec };
    }
  };

  const updateChildProfile = (profile: ChildProfile) => {
    setChild(profile);
    saveChild(profile);
    const updatedList = childrenList.map(c => c.id === profile.id ? profile : c);
    setChildrenList(updatedList);
    saveChildrenList(updatedList);
    addEventLog('schedule_modified', `Updated child profile settings for ${profile.name}`, profile.name);
  };

  const addChildProfile = (newChildData: Omit<ChildProfile, 'id'>) => {
    const newId = `child_${Date.now()}`;
    const newProfile: ChildProfile = {
      id: newId,
      ...newChildData,
    };
    const updatedList = [...childrenList, newProfile];
    setChildrenList(updatedList);
    saveChildrenList(updatedList);

    addEventLog('child_account_created', `Added new child profile: ${newProfile.name}`, newProfile.name);
    addNotification('Child Profile Created', `Created customized account for ${newProfile.name}!`, 'success');
  };

  const deleteChildProfile = (id: string) => {
    if (childrenList.length <= 1) {
      addNotification('Cannot Delete', 'You must maintain at least one child profile on the device.', 'warning');
      return;
    }
    const target = childrenList.find((c) => c.id === id);
    const updatedList = childrenList.filter((c) => c.id !== id);
    
    // Immediately persist and update the children list
    setChildrenList(updatedList);
    saveChildrenList(updatedList);

    // Clean up specific child session state from localStorage
    try {
      localStorage.removeItem(`pc_session_v2_${id}`);
      localStorage.removeItem(`pc_child_${id}`);
    } catch (e) {}

    // If active child was deleted, switch to the first remaining child
    if ((id === activeChildId || id === child.id) && updatedList.length > 0) {
      const nextActive = updatedList[0];
      setActiveChildIdState(nextActive.id);
      saveActiveChildId(nextActive.id);
      setChild(nextActive);
      saveChild(nextActive);

      const childSession = getStoredSessionState(nextActive.id);
      setSession(childSession);
      addEventLog('active_child_switched', `Switched active device account to: ${nextActive.name}`, nextActive.name);
    }

    addEventLog('child_account_deleted', `Deleted child profile: ${target?.name || id}`, child.name);
    addNotification('Profile Deleted', `Removed account profile for ${target?.name || 'child'}.`, 'info');
  };

  const selectActiveChild = (id: string) => {
    const selected = childrenList.find(c => c.id === id);
    if (!selected) return;

    setActiveChildIdState(id);
    saveActiveChildId(id);
    setChild(selected);
    saveChild(selected);

    // Load or initialize session state specifically for selected child
    const childSession = getStoredSessionState(id);
    setSession(childSession);

    addEventLog('active_child_switched', `Switched active device account to: ${selected.name}`, selected.name);
    addNotification('Active Account Switched', `Device assigned to ${selected.name}`, 'info');
  };

  const updateSchedule = (newSchedule: WeeklySchedule) => {
    setSchedule(newSchedule);
    saveSchedule(newSchedule);
    addEventLog('schedule_modified', 'Updated weekly usage schedule matrix', child.name);
  };

  const updateAppStatus = (packageName: string, isAllowed: boolean, allowDuringLock: boolean) => {
    const updated = apps.map(a => {
      if (a.packageName === packageName) {
        return { ...a, isAllowed, allowDuringLock };
      }
      return a;
    });
    setApps(updated);
    saveApps(updated);
    addEventLog('app_restriction_changed', `Changed permissions for ${packageName}`, child.name);
  };

  // ==========================================
  // SMART BLOCK 2.0 (MULTI-SCHEDULE SYSTEM)
  // ==========================================
  const smartBlockModes: SmartBlockMode[] = useMemo(() => {
    if (settings?.smartBlockModes && settings.smartBlockModes.length > 0) {
      return settings.smartBlockModes;
    }
    return DEFAULT_SMART_BLOCK_MODES;
  }, [settings?.smartBlockModes]);

  // Current active mode (resolved deterministically by active time & priority)
  const activeSmartBlockMode: SmartBlockMode | null = useMemo(() => {
    return getEffectiveActiveSmartBlock(smartBlockModes);
  }, [smartBlockModes, session.lastHeartbeatTimestamp]);

  const isSmartBlockActiveNow: boolean = activeSmartBlockMode !== null;

  // Next scheduled mode transition / countdown
  const nextSmartBlockTransition: SmartBlockTransitionInfo | null = useMemo(() => {
    return getNextSmartBlockTransition(smartBlockModes);
  }, [smartBlockModes, session.lastHeartbeatTimestamp]);

  // Schedule overlap warnings
  const overlappingSchedules: ScheduleOverlap[] = useMemo(() => {
    return detectScheduleOverlaps(smartBlockModes);
  }, [smartBlockModes]);

  // Application restriction evaluator
  const getSmartBlockRestrictionDetails = useCallback(
    (app: AppInfo): AppAccessSmartBlockDecision => {
      return evaluateAppAccessInSmartBlock(app, activeSmartBlockMode);
    },
    [activeSmartBlockMode]
  );

  const isAppRestrictedBySmartBlock = useCallback(
    (app: AppInfo): boolean => {
      return evaluateAppAccessInSmartBlock(app, activeSmartBlockMode).isBlocked;
    },
    [activeSmartBlockMode]
  );

  // CRUD & Operations for Smart Block Modes
  const createSmartBlockMode = (newModeData: Omit<SmartBlockMode, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (!settings) return;
    const now = Date.now();
    const newMode: SmartBlockMode = {
      ...newModeData,
      id: `smart-mode-${now}-${Math.random().toString(36).substr(2, 6)}`,
      createdAt: now,
      updatedAt: now,
    };
    const updatedModes = [...smartBlockModes, newMode];
    const updatedSettings: AppSettings = {
      ...settings,
      smartBlockModes: updatedModes,
    };
    setSettings(updatedSettings);
    saveSettings(updatedSettings);
    addEventLog('smart_block_updated', `Created Smart Block Mode: "${newMode.name}" (${newMode.startTime} - ${newMode.endTime})`, child.name);
    addNotification('Smart Block Created', `Created schedule rule "${newMode.name}" (${newMode.icon})`, 'success');
  };

  const updateSmartBlockMode = (updatedMode: SmartBlockMode) => {
    if (!settings) return;
    const now = Date.now();
    const modeWithTimestamp: SmartBlockMode = {
      ...updatedMode,
      updatedAt: now,
    };
    const updatedModes = smartBlockModes.map((m) => (m.id === updatedMode.id ? modeWithTimestamp : m));
    const updatedSettings: AppSettings = {
      ...settings,
      smartBlockModes: updatedModes,
    };
    setSettings(updatedSettings);
    saveSettings(updatedSettings);
    addEventLog('smart_block_updated', `Updated Smart Block Mode: "${updatedMode.name}"`, child.name);
    addNotification('Schedule Updated', `Updated "${updatedMode.name}" schedule rule.`, 'info');
  };

  const deleteSmartBlockMode = (modeId: string) => {
    if (!settings) return;
    const target = smartBlockModes.find((m) => m.id === modeId);
    const updatedModes = smartBlockModes.filter((m) => m.id !== modeId);
    const updatedSettings: AppSettings = {
      ...settings,
      smartBlockModes: updatedModes,
    };
    setSettings(updatedSettings);
    saveSettings(updatedSettings);
    addEventLog('smart_block_updated', `Deleted Smart Block Mode: "${target?.name || modeId}"`, child.name);
    addNotification('Schedule Deleted', `Removed "${target?.name || 'mode'}" from Smart Block schedules.`, 'info');
  };

  const duplicateSmartBlockMode = (modeId: string) => {
    if (!settings) return;
    const target = smartBlockModes.find((m) => m.id === modeId);
    if (!target) return;
    const now = Date.now();
    const duplicated: SmartBlockMode = {
      ...target,
      id: `smart-mode-${now}-${Math.random().toString(36).substr(2, 6)}`,
      name: `${target.name} (Copy)`,
      createdAt: now,
      updatedAt: now,
    };
    const updatedModes = [...smartBlockModes, duplicated];
    const updatedSettings: AppSettings = {
      ...settings,
      smartBlockModes: updatedModes,
    };
    setSettings(updatedSettings);
    saveSettings(updatedSettings);
    addEventLog('smart_block_updated', `Duplicated Smart Block Mode: "${target.name}" -> "${duplicated.name}"`, child.name);
    addNotification('Schedule Duplicated', `Created copy of "${target.name}"`, 'success');
  };

  const toggleSmartBlockMode = (modeId: string, enabled: boolean) => {
    if (!settings) return;
    const target = smartBlockModes.find((m) => m.id === modeId);
    const updatedModes = smartBlockModes.map((m) => (m.id === modeId ? { ...m, enabled, updatedAt: Date.now() } : m));
    const updatedSettings: AppSettings = {
      ...settings,
      smartBlockModes: updatedModes,
    };
    setSettings(updatedSettings);
    saveSettings(updatedSettings);
    addEventLog(
      enabled ? 'smart_block_enabled' : 'smart_block_disabled',
      `Smart Block Mode "${target?.name || modeId}" ${enabled ? 'Enabled' : 'Disabled'}`,
      child.name
    );
    addNotification(
      'Schedule Toggled',
      `"${target?.name || 'Mode'}" is now ${enabled ? 'active in schedules' : 'paused'}`,
      'info'
    );
  };

  // Backward compatibility wrapper for single-preset configuration
  const smartBlockConfig: SmartBlockConfig = settings?.smartBlock || DEFAULT_SMART_BLOCK_CONFIG;
  const updateSmartBlockConfig = (newConfig: SmartBlockConfig) => {
    if (!settings) return;
    const updatedSettings: AppSettings = {
      ...settings,
      smartBlock: newConfig,
    };
    setSettings(updatedSettings);
    saveSettings(updatedSettings);
  };

  const webFilterConfig = settings?.webFilter || DEFAULT_WEB_FILTER_CONFIG;
  const batteryUsage = settings?.batteryMonitor || DEFAULT_BATTERY_USAGE;

  const updateWebFilterConfig = (newConfig: WebFilterConfig) => {
    if (!settings) return;
    const updatedSettings: AppSettings = {
      ...settings,
      webFilter: newConfig,
    };
    setSettings(updatedSettings);
    saveSettings(updatedSettings);
    addEventLog('app_restriction_changed', `Web Filtering updated: Enabled=${newConfig.enabled}, Blocked Categories=${newConfig.blockedCategories.join(', ')}`, child.name);
    addNotification('Web Filter Updated', 'Web filtering rules and category blocks have been successfully updated.', 'success');
  };

  const checkUrlAccess = (url: string): { allowed: boolean; category?: string; reason?: string } => {
    const config = settings?.webFilter || DEFAULT_WEB_FILTER_CONFIG;
    if (!config.enabled) return { allowed: true };

    const lowerUrl = url.toLowerCase();

    for (const rule of config.customBlockedUrls) {
      if (rule.isBlocked && lowerUrl.includes(rule.urlPattern.toLowerCase())) {
        addEventLog('blocked_app_attempt', `Blocked website access attempt: ${url} (Matched custom rule: ${rule.urlPattern})`, child.name);
        return { allowed: false, category: rule.category, reason: `Blocked by custom rule: ${rule.urlPattern}` };
      }
    }

    const categoryKeywords: Record<WebCategory, string[]> = {
      adult: ['adult', 'nsfw', 'xxx', 'porn', 'dating', 'mature', 'sex'],
      gambling: ['casino', 'bet', 'poker', 'lottery', 'gambling', 'slot', 'sportsbook'],
      social_media: ['tiktok.com', 'instagram.com', 'x.com', 'twitter.com', 'snapchat', 'facebook.com'],
      violence: ['gore', 'weapon', 'fight', 'shooting', 'violence', 'brawls'],
      phishing: ['login-verify', 'secure-bank-update', 'account-suspended-verify', 'phishing', 'malware'],
      entertainment: ['netflix.com', 'twitch.tv', 'hulu.com', 'primevideo'],
      gaming: ['roblox.com', 'steampowered', 'epicgames', 'minecraft.net'],
      custom: [],
    };

    for (const cat of config.blockedCategories) {
      const keywords = categoryKeywords[cat] || [];
      for (const kw of keywords) {
        if (lowerUrl.includes(kw)) {
          addEventLog('blocked_app_attempt', `Blocked website access attempt: ${url} (Category: ${cat})`, child.name);
          return { allowed: false, category: cat, reason: `Restricted by web filter category: ${cat.toUpperCase()}` };
        }
      }
    }

    return { allowed: true };
  };

  const optimizeBatteryApp = (packageName: string) => {
    if (!settings) return;
    const currentBattery = settings.batteryMonitor || DEFAULT_BATTERY_USAGE;
    const updatedBattery = currentBattery.map(item => {
      if (item.packageName === packageName) {
        return {
          ...item,
          backgroundBatteryPercent: Math.max(0.1, Number((item.backgroundBatteryPercent * 0.2).toFixed(1))),
          totalBatteryPercent: Number((item.foregroundBatteryPercent + (item.backgroundBatteryPercent * 0.2)).toFixed(1)),
          powerConsumptionMah: Math.round(item.powerConsumptionMah * 0.4),
          status: 'normal' as const,
        };
      }
      return item;
    });

    const updatedSettings: AppSettings = {
      ...settings,
      batteryMonitor: updatedBattery,
    };
    setSettings(updatedSettings);
    saveSettings(updatedSettings);

    const targetApp = updatedBattery.find(a => a.packageName === packageName);
    addEventLog('app_restriction_changed', `Optimized power consumption for ${targetApp?.appName || packageName} (Restricted background drain)`, child.name);
    addNotification('Battery Optimized', `Background power usage for ${targetApp?.appName || packageName} has been successfully restricted!`, 'success');
  };

  const updateSettings = (newSettings: AppSettings) => {
    setSettings(newSettings);
    saveSettings(newSettings);
  };

  const grantExtraTime = (minutes: number, reason: string = 'Parent granted extra time') => {
    const now = Date.now();
    const durationMs = minutes * 60 * 1000;
    const currentEnd = session.extraTimeEndTimestamp;

    // Extend existing extra time session if active, otherwise start from now
    const newEndTimestamp = (currentEnd && currentEnd > now) ? currentEnd + durationMs : now + durationMs;
    const totalExtraMinutes = Math.round((newEndTimestamp - now) / 60000);

    const updatedSession: SessionState = {
      ...session,
      extraTimeMinutes: totalExtraMinutes,
      extraTimeGrantedAt: now,
      extraTimeEndTimestamp: newEndTimestamp,
      extraTimeConsumed: true,
      isLocked: false,
      lockReason: null,
      lastHeartbeatTimestamp: now,
    };

    setSession(updatedSession);
    saveSessionState(updatedSession, child.id);

    // CRITICAL: Immediately exit administrative parent session & switch to Child Usage Mode!
    setParentSessionActive(false);
    setRole('child');
    setShowExtraTimeModal(false);

    const endTimeStr = new Date(newEndTimestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    addEventLog(
      'extra_time_granted',
      `Granted +${minutes}m Extra Time until ${endTimeStr} (${reason}). Parent settings automatically closed -> Switched to Child Usage Mode.`,
      child.name
    );
    addNotification(
      'Extra Time Granted',
      `+${minutes} minutes granted! Device returned to Child Usage Mode until ${endTimeStr}.`,
      'success'
    );
  };

  const consumeAndLockUntilNextSchedule = (reason: string = 'Playtime finished') => {
    const updatedSession: SessionState = {
      ...session,
      extraTimeMinutes: 0,
      extraTimeEndTimestamp: null,
      extraTimeConsumed: true,
      isLocked: true,
      lockReason: 'extra_time_exhausted',
      lastHeartbeatTimestamp: Date.now(),
    };
    setSession(updatedSession);
    saveSessionState(updatedSession, child.id);
    setParentSessionActive(false);
    setRole('child');
    setShowExtraTimeModal(false);
    addEventLog('lock_activated', `Device shut down until next scheduled time (${reason}).`, child.name);
    addNotification('Phone Shut Down', 'Device is locked until the next scheduled session.', 'info');
  };

  const forceLockDevice = (reason: 'manual_lock' | 'test_mode' | 'schedule_expired' | 'daily_limit_reached') => {
    const updatedSession: SessionState = {
      ...session,
      isLocked: true,
      lockReason: reason,
      extraTimeEndTimestamp: null, // Clear extra time on manual lock
      extraTimeMinutes: 0,
    };
    setSession(updatedSession);
    saveSessionState(updatedSession, child.id);
    setParentSessionActive(false);
    setRole('child');
    addEventLog('lock_activated', `Device forced into Lock Mode (${reason})`, child.name);
  };

  const unlockDeviceTemp = () => {
    const updatedSession: SessionState = {
      ...session,
      isLocked: false,
      lockReason: null,
      lastHeartbeatTimestamp: Date.now(),
    };
    setSession(updatedSession);
    saveSessionState(updatedSession, child.id);
    setParentSessionActive(false);
    setRole('child');
    addEventLog('lock_unlocked', 'Parent manually unlocked device. Returned to Child Usage Mode.', child.name);
    addNotification('Device Unlocked', 'Temporary unlock applied. Returned to Child Usage Mode.', 'info');
  };

  // Usage Modes
  const getActiveUsageMode = useCallback(() => {
    const modes = settings?.usageModes || [];
    return modes.find(m => m.id === session.activeUsageModeId) || modes.find(m => m.id === 'normal');
  }, [settings?.usageModes, session.activeUsageModeId]);

  const setActiveUsageMode = useCallback((modeId: string) => {
    const updatedSession: SessionState = {
      ...session,
      activeUsageModeId: modeId,
    };
    setSession(updatedSession);
    saveSessionState(updatedSession, child.id);
    
    const mode = settings?.usageModes?.find(m => m.id === modeId);
    if (mode) {
      addEventLog('mode_changed', `Usage Mode changed to: ${mode.name}`, child.name);
      addNotification('Usage Mode Changed', `Switched to ${mode.name}`, 'info');
    }
  }, [session, settings?.usageModes, child.name]);

  const isAppAllowedInCurrentMode = useCallback((app: AppInfo) => {
    const activeMode = getActiveUsageMode();
    
    // Normal mode uses default app allows
    if (!activeMode || activeMode.id === 'normal') {
      return app.isAllowed;
    }

    // Other modes check their explicit allowed list
    return activeMode.allowedApps.includes(app.packageName);
  }, [getActiveUsageMode]);

  // Simulate device reboot & verify state restoration
  const simulateReboot = () => {
    addEventLog('device_reboot', 'Device reboot initiated. Restoring state from persistent storage...', child.name);
    const stored = getStoredSessionState();
    // Maintain lock state or session elapsed time
    setSession(stored);
    addNotification('Reboot Recovery', 'All parental control restrictions & lock states restored after reboot!', 'info');
  };

  // Simulate system time change attempt
  const simulateTimeChange = () => {
    addEventLog('time_manipulation_detected', 'Suspicious system time change detected! Locking device for anti-tamper security.', child.name);
    forceLockDevice('manual_lock');
    addNotification('Security Alert', 'System time manipulation detected! Anti-tamper enforcement engaged.', 'error');
  };

  const openPinModal = (onSuccess?: () => void, title?: string) => {
    if (onSuccess) {
      setPinSuccessCallback(() => onSuccess);
    } else {
      setPinSuccessCallback(() => () => {
        setRole('parent');
        setActiveTab('settings');
      });
    }
    setShowPinModal(true);
  };

  const closePinModal = () => {
    setShowPinModal(false);
    setPinSuccessCallback(null);
  };

  const captureVerificationPhoto = (photoUrl: string, reason: string) => {
    addVerificationRecord(photoUrl, reason, child.name);
    addNotification('Photo Verification', 'Verification photo saved securely', 'success');
  };

  const logEvent = (type: EventType, description: string) => {
    addEventLog(type, description, child.name);
  };

  if (!settings) {
    return <div className="min-h-screen bg-slate-900 flex items-center justify-center text-white">Loading Parental Control System...</div>;
  }

  return (
    <AppContext.Provider
      value={{
        role,
        setRole,
        language,
        setLanguage,
        activeTab,
        setActiveTab,
        child,
        childrenList,
        activeChildId,
        updateChildProfile,
        addChildProfile,
        deleteChildProfile,
        selectActiveChild,
        schedule,
        updateSchedule,
        apps,
        updateAppStatus,
        settings,
        updateSettings,
        session,
        // Smart Block 2.0
        smartBlockModes,
        activeSmartBlockMode,
        isSmartBlockActiveNow,
        nextSmartBlockTransition,
        overlappingSchedules,
        isAppRestrictedBySmartBlock,
        getSmartBlockRestrictionDetails,
        createSmartBlockMode,
        updateSmartBlockMode,
        deleteSmartBlockMode,
        duplicateSmartBlockMode,
        toggleSmartBlockMode,
        smartBlockConfig,
        updateSmartBlockConfig,
        webFilterConfig,
        updateWebFilterConfig,
        checkUrlAccess,
        batteryUsage,
        optimizeBatteryApp,
        setActiveUsageMode,
        isAppAllowedInCurrentMode,
        getActiveUsageMode,
        currentMode,
        parentSessionActive,
        remainingDailySeconds,
        remainingSessionSeconds,
        isLocked: session.isLocked,
        lockReason: session.lockReason,
        authenticateParentPin,
        exitParentSession,
        touchParentActivity,
        evaluateCurrentState,
        grantExtraTime,
        consumeAndLockUntilNextSchedule,
        forceLockDevice,
        unlockDeviceTemp,
        simulateReboot,
        simulateTimeChange,
        logEvent,
        addEventLog: (type, desc, cName) => addEventLog(type, desc, cName || child.name),
        addNotification,
        notifications,
        dismissNotification,
        showPinModal,
        pinSuccessCallback,
        openPinModal,
        closePinModal,
        showExtraTimeModal,
        setShowExtraTimeModal,
        showExportModal,
        setShowExportModal,
        showSetupWizard,
        setShowSetupWizard,
        captureVerificationPhoto,
        accountSelected,
        setAccountSelected,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
