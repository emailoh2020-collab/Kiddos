import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { TestModeBar } from './components/TestModeBar';
import { ParentOverview } from './components/ParentDashboard/ParentOverview';
import { ScheduleManager } from './components/ParentDashboard/ScheduleManager';
import { AppManager } from './components/ParentDashboard/AppManager';
import { StatisticsDashboard } from './components/ParentDashboard/StatisticsDashboard';
import { EventLogView } from './components/ParentDashboard/EventLogView';
import { VerificationView } from './components/ParentDashboard/VerificationView';
import { SettingsView } from './components/ParentDashboard/SettingsView';
import { SmartBlockManager } from './components/ParentDashboard/SmartBlockManager';
import { UsageModeManager } from './components/ParentDashboard/UsageModeManager';
import { WebFilterManager } from './components/ParentDashboard/WebFilterManager';
import { BatteryMonitorView } from './components/ParentDashboard/BatteryMonitorView';
import { AboutScreen } from './components/AboutScreen';
import { SplashScreen } from './components/SplashScreen';
import { ChildDashboard } from './components/ChildDashboard/ChildDashboard';
import { LockScreen } from './components/LockScreen/LockScreen';
import { PinModal } from './components/PinModal';
import { ExtraTimeModal } from './components/ExtraTimeModal';
import { AndroidExporterModal } from './components/AndroidExporter/AndroidExporterModal';
import { SetupWizard } from './components/SetupWizard';
import { NotificationToast } from './components/NotificationToast';
import { MainLoginScreen } from './components/MainLoginScreen';
import { AdaptiveNavigation } from './components/navigation/AdaptiveNavigation';
import { translations } from './data/translations';

const MainContent: React.FC = () => {
  const { role, language, activeTab, setActiveTab, accountSelected } = useApp();
  const t = translations[language];
  const [showSplash, setShowSplash] = useState(true);

  return (
    <div className="min-h-screen bg-[#F1F5F9] dark:bg-slate-950 text-slate-800 dark:text-slate-100 flex flex-col font-sans">
      {/* Professional Launch Splash Screen */}
      {showSplash && <SplashScreen onFinish={() => setShowSplash(false)} />}

      {/* Main Login / Role Selection Launch Gate */}
      {!showSplash && !accountSelected && <MainLoginScreen />}

      <Navbar />
      <TestModeBar />

      <main className="flex-1 w-full px-3 sm:px-6 lg:px-8 py-4 sm:py-6">
        {activeTab === 'about' ? (
          <AboutScreen
            onBack={() => setActiveTab('overview')}
            onPreviewSplash={() => setShowSplash(true)}
          />
        ) : role === 'parent' ? (
          <AdaptiveNavigation activeTab={activeTab} onSelectTab={setActiveTab}>
            {activeTab === 'overview' && <ParentOverview onNavigate={setActiveTab} />}
            {activeTab === 'smart_block' && <SmartBlockManager onNavigate={setActiveTab} />}
            {activeTab === 'schedule' && <ScheduleManager />}
            {activeTab === 'apps' && <AppManager />}
            {activeTab === 'web_filter' && <WebFilterManager />}
            {activeTab === 'battery' && <BatteryMonitorView />}
            {activeTab === 'usage_modes' && <UsageModeManager />}
            {activeTab === 'statistics' && <StatisticsDashboard />}
            {activeTab === 'eventLog' && <EventLogView />}
            {activeTab === 'verification' && <VerificationView />}
            {activeTab === 'settings' && <SettingsView />}
          </AdaptiveNavigation>
        ) : (
          <ChildDashboard />
        )}
      </main>

      {/* Mandatory Lock Screen Overlay */}
      <LockScreen />

      {/* Modals & Toasts */}
      <PinModal />
      <ExtraTimeModal />
      <AndroidExporterModal />
      <SetupWizard />
      <NotificationToast />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
