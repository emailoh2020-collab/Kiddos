import { Language } from '../../types';
import { TranslationSchema } from './types';
import { en } from './en';
import { ar } from './ar';
import { es } from './es';
import { fr } from './fr';
import { de } from './de';
import { pt } from './pt';
import { it } from './it';
import { ru } from './ru';
import { zh } from './zh';
import { ja } from './ja';
import { ko } from './ko';
import { hi } from './hi';
import { tr } from './tr';
import { nl } from './nl';
import { pl } from './pl';
import { id } from './id';
import { vi } from './vi';
import { bn } from './bn';
import { ur } from './ur';
import { fa } from './fa';

export * from './types';

export const translations: Record<Language, TranslationSchema> = {
  en,
  ar,
  es,
  fr,
  de,
  pt,
  it,
  ru,
  zh,
  ja,
  ko,
  hi,
  tr,
  nl,
  pl,
  id,
  vi,
  bn,
  ur,
  fa,
};
