export const APP_CONFIG = {
  appName: 'SafeShield',
  tagline: 'Parental Control & Screen Time',
  packageId: 'com.safeshield.parentalcontrol',
  versionName: '1.0.0',
  versionCode: 1,
  releaseDate: '2026-08-15',
  developerName: 'Kamal Al-Hori',
  developerEmail: 'kamal736735@gmail.com',
  copyrightYear: new Date().getFullYear(),
  websiteUrl: 'https://safeshield.example.com',
  supportUrl: 'https://safeshield.example.com/support',
  
  description: {
    en: 'SafeShield is a real Android parental-control application designed to help parents manage children\'s screen time, schedules, applications, and device usage with real-time app blocking, Smart Block engine, and anti-bypass protection.',
    ar: 'سيف شيلد (SafeShield) هو تطبيق أندرويد حقيقي للرقابة الأبوية صُمم لمساعدة الوالدين في إدارة وقت شاشة الأطفال والجدول الزمني وحظر التطبيقات ومنع التجاوز.'
  },

  minAndroidVersion: 'Android 8.0 (API 26)',
  targetAndroidVersion: 'Android 15.0 (API 35)',
  
  openSourceLicenses: [
    { name: 'React', version: '19.0.1', license: 'MIT License', url: 'https://github.com/facebook/react' },
    { name: 'Lucide React Icons', version: '0.546.0', license: 'ISC License', url: 'https://github.com/lucide-icons/lucide' },
    { name: 'Tailwind CSS', version: '4.1.14', license: 'MIT License', url: 'https://github.com/tailwindlabs/tailwindcss' },
    { name: 'Recharts', version: '3.10.1', license: 'MIT License', url: 'https://github.com/recharts/recharts' },
    { name: 'Motion', version: '12.23.24', license: 'MIT License', url: 'https://github.com/motiondivision/motion' },
    { name: 'AndroidX Core SplashScreen', version: '1.0.1', license: 'Apache License 2.0', url: 'https://developer.android.com/develop/ui/views/launch/splash-screen' },
    { name: 'AndroidX DevicePolicyManager', version: '1.7.0', license: 'Apache License 2.0', url: 'https://developer.android.com/reference/android/app/admin/DevicePolicyManager' },
    { name: 'AndroidX Biometric', version: '1.2.0-alpha05', license: 'Apache License 2.0', url: 'https://developer.android.com/jetpack/androidx/releases/biometric' }
  ],

  privacyPolicy: {
    en: `PRIVACY POLICY - SafeShield

Last updated: August 15, 2026

1. DATA COLLECTION & STORAGE
SafeShield is designed with privacy as a foundational principle. All screen time metrics, application usage statistics, and parental schedules are processed and saved LOCALLY on your child's device using hardware-backed encrypted storage. No personal metrics or private data are uploaded to external tracking servers.

2. PARENTAL PIN & SECURITY
Parental control authentication is secured using PBKDF2 with SHA-256 password hashing and unique salt generation. Passwords are never stored in plain text.

3. CAMERA & BIOMETRIC PRIVACY
SafeShield does not secretly photograph the child or use covert identification. Any optional biometric authentication is strictly used by Android BiometricPrompt for Parent Access verification.

4. ANDROID SYSTEM PERMISSIONS
SafeShield utilizes official Android system APIs including UsageStatsManager, DevicePolicyManager (Device Owner / Device Admin), and AccessibilityServices to enforce time limits, block unauthorized apps, and prevent uninstallation by unauthorized users.

5. CONTACT US
For privacy queries or support, please contact:
Kamal Al-Hori
Email: kamal736735@gmail.com`,

    ar: `سياسة الخصوصية - SafeShield

آخر تحديث: 15 أغسطس 2026

1. جمع البيانات والتخزين
تم تصميم SafeShield مع جعل الخصوصية مبدأً أساسياً. يتم معالجة وحفظ جميع مقاييس وقت الشاشة، وإحصائيات استخدام التطبيقات، والجداول الأبوية محلياً على جهاز طفلك باستخدام تخزين مشفر مدعوم بالعتاد. لا يتم تحميل أي مقاييس شخصية إلى خوادم تتبع خارجية.

2. الرمز السري للوالدين والأمان
يتم تأمين المصادقة الأبوية باستخدام PBKDF2 مع تشفير SHA-256 وتوليد عشوائي للملح (Salt). لا يتم تخزين كلمات المرور كنصوص صريحة إطلاقاً.

3. خصوصية الكاميرا والمصادقة الحيوية
لا يقوم SafeShield بالتصوير الخفي للطفل إطلاقاً. تُستخدم المصادقة الحيوية الاختيارية فقط للوالد عبر واجهة BiometricPrompt الرسمية.

4. أذونات نظام أندرويد
يستخدم SafeShield واجهات برمجية رسمية لنظام أندرويد تشمل UsageStatsManager و DevicePolicyManager و AccessibilityServices لفرض حدود الوقت، وحظر التطبيقات غير المصرح بها، ومنع التجاوز.

5. اتصل بنا
لأي استفسارات بخصوص الخصوصية أو الدعم، يرجى التواصل مع:
كمال الحوري (Kamal Al-Hori)
البريد الإلكتروني: kamal736735@gmail.com`
  },

  termsOfUse: {
    en: `TERMS OF USE - SafeShield

1. ACCEPTANCE OF TERMS
By installing and configuring SafeShield, you agree to these Terms of Use in full. This software is provided as a parental protection and digital wellness tool.

2. AUTHORIZED PARENTAL USE
You affirm that you are the lawful legal guardian or owner of the device on which this application is deployed. You are responsible for maintaining the confidentiality of your Parent PIN.

3. DEVICE OWNER ENFORCEMENT
When activated via Android ADB Device Policy Manager, SafeShield engages Kiosk / LockTask mode to prevent system bypass. Ensure you retain your Parent PIN to adjust or remove controls.

4. DISCLAIMER OF WARRANTY
SafeShield is provided "as is" without warranty of any kind. While engineered for maximum stability and anti-bypass protection, the developer is not liable for system-level modifications made on managed devices.

5. CONTACT & COPYRIGHT
© 2026 Kamal Al-Hori. All rights reserved.
Email: kamal736735@gmail.com`,

    ar: `شروط الاستخدام - SafeShield

1. القبول بالشروط
بتثبيت وإعداد SafeShield، فإنك توافق على شروط الاستخدام هذه بالكامل. يُقدم هذا البرنامج كأداة للحماية الأبوية والرفاهية الرقمية.

2. الاستخدام الأبوي المصرح به
تقر بأنك الولي الشرعي أو المالك القانوني للجهاز الذي تم تثبيت هذا التطبيق عليه. أنت مسؤول عن الحفاظ على سرية رمز PIN الخاص بالوالد.

3. تطبيق وضع مالك الجهاز
عند التفعيل عبر إدارة سياسات أندرويد (ADB Device Owner)، يفعل التطبيق وضع القفل الحصري لمنع التجاوز. يرجى التأكد من الاحتفاظ بالرمز السري لتعديل أو إلغاء عناصر التحكم.

4. إخلاء المسؤولية
يتم تقديم SafeShield "كما هو" دون أي ضمانات من أي نوع. مع تصميمه لأقصى درجات الاستقرار والمنع من التجاوز، لا يتحمل المطور أي مسؤولية عن التعديلات على مستوى النظام.

5. الاتصال وحقوق النشر
© 2026 كمال الحوري (Kamal Al-Hori). جميع الحقوق محفوظة.
البريد الإلكتروني: kamal736735@gmail.com`
  }
};

