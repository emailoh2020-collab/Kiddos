export type Role = 'parent' | 'child';

export type Language =
  | 'en' // English
  | 'ar' // Arabic
  | 'es' // Spanish
  | 'fr' // French
  | 'de' // German
  | 'pt' // Portuguese
  | 'it' // Italian
  | 'ru' // Russian
  | 'zh' // Chinese Simplified
  | 'ja' // Japanese
  | 'ko' // Korean
  | 'hi' // Hindi
  | 'tr' // Turkish
  | 'nl' // Dutch
  | 'pl' // Polish
  | 'id' // Indonesian
  | 'vi' // Vietnamese
  | 'bn' // Bengali
  | 'ur' // Urdu
  | 'fa'; // Persian (Farsi)

export type ControlMode = 'scheduled' | 'free';

export type DeviceStatus = 'allowed' | 'limited' | 'locked';

export type ParentalControlMode =
  | 'LOCKED'
  | 'PLAYING'
  | 'PARENT_AUTHENTICATED'
  | 'PARENT_SETTINGS'
  | 'EXTRA_TIME'
  | 'PAUSED';

export interface ChildProfile {
  id: string;
  name: string;
  avatar: string;
  age?: number;
  dailyLimitMinutes: number; // e.g. 120 minutes (2 hrs)
  dailyFreeTimeAllowanceSeconds: number; // e.g. 10800 seconds (3 hrs) for Free Mode
  sessionLimitMinutes: number; // e.g. 45 minutes
}

export interface UsagePeriod {
  id: string;
  startTime: string; // "08:00"
  endTime: string;   // "09:00"
  enabled: boolean;
}

export type DayOfWeek = 'monday' | 'tuesday' | 'wednesday' | 'thursday' | 'friday' | 'saturday' | 'sunday';

export type WeeklySchedule = Record<DayOfWeek, UsagePeriod[]>;

export type AppCategory = 'educational' | 'games' | 'social' | 'utilities' | 'entertainment' | 'system';

export interface AppInfo {
  packageName: string;
  appName: string;
  icon: string;
  category: AppCategory;
  isAllowed: boolean; // Keep this as fallback or normal mode default
  allowDuringLock: boolean;
  totalUsageMinutes: number;
  launchCount: number;
  lastUsedTimestamp?: number;
}

export interface UsageMode {
  id: string;
  name: string;
  description: string;
  icon: string;
  isBuiltIn: boolean;
  allowedApps: string[]; // Array of packageNames allowed in this mode
}


export type WebCategory = 'adult' | 'gambling' | 'social_media' | 'violence' | 'phishing' | 'entertainment' | 'gaming' | 'custom';

export interface BlockedUrlRule {
  id: string;
  urlPattern: string;
  category: WebCategory;
  isBlocked: boolean;
  notes?: string;
}

export interface WebFilterConfig {
  enabled: boolean;
  blockedCategories: WebCategory[];
  customBlockedUrls: BlockedUrlRule[];
  safeSearchEnabled: boolean;
}

export interface AppBatteryUsage {
  packageName: string;
  appName: string;
  icon: string;
  foregroundBatteryPercent: number;
  backgroundBatteryPercent: number;
  totalBatteryPercent: number;
  powerConsumptionMah: number;
  status: 'normal' | 'high_background' | 'excessive';
}

export type SmartBlockPreset = 'school_hours' | 'study_focus' | 'custom';

export interface SmartBlockConfig {
  enabled: boolean;
  preset: SmartBlockPreset;
  startTime: string; // e.g. "08:00"
  endTime: string;   // e.g. "15:00"
  activeDays: DayOfWeek[]; // ['monday', 'tuesday', 'wednesday', 'thursday', 'friday']
  restrictedCategories: AppCategory[]; // ['games', 'social', 'entertainment']
  exemptEducational: boolean; // Always allow educational apps regardless of block window
}

export interface SmartBlockMode {
  id: string;
  name: string; // e.g. "School Time", "Study Time", "Bedtime", "Family Time", "Play Time"
  description: string;
  icon: string; // emoji, e.g. '🏫', '📚', '🌙', '🎮', '🍽', '😴', '🚌', '🛌', '⚙'
  enabled: boolean;
  startTime: string; // "HH:MM", e.g. "07:00", "14:00", "20:30"
  endTime: string;   // "HH:MM", e.g. "14:00", "16:00", "07:00"
  activeDays: DayOfWeek[]; // ['monday', 'tuesday', 'wednesday', 'thursday', 'friday']
  allowedApps: string[]; // explicit packageNames allowed
  blockedApps: string[]; // explicit packageNames blocked
  blockedCategories: AppCategory[]; // categories blocked e.g. ['games', 'social', 'entertainment']
  allowedCategories: AppCategory[]; // categories allowed e.g. ['educational', 'utilities']
  exceptions: string[]; // specific packageNames exempted from category blocks (e.g. Chess allowed even if Games is blocked)
  priority: number; // integer (1-10), higher number = higher priority when schedules overlap
  createdAt: number;
  updatedAt: number;
}

export type EventType =
  | 'session_started'
  | 'session_ended'
  | 'lock_activated'
  | 'lock_unlocked'
  | 'pin_success'
  | 'pin_failed'
  | 'extra_time_granted'
  | 'extra_time_expired'
  | 'extra_time_consumed'
  | 'blocked_app_attempt'
  | 'device_reboot'
  | 'schedule_modified'
  | 'pin_changed'
  | 'app_restriction_changed'
  | 'permission_changed'
  | 'time_manipulation_detected'
  | 'verification_photo_taken'
  | 'parent_session_started'
  | 'parent_session_ended'
  | 'parent_session_expired'
  | 'parent_settings_opened'
  | 'parent_settings_closed'
  | 'mode_evaluated'
  | 'free_mode_enabled'
  | 'child_account_created'
  | 'child_account_updated'
  | 'child_account_deleted'
  | 'active_child_switched'
  | 'smart_block_enabled'
  | 'smart_block_disabled'
  | 'smart_block_updated'
  | 'daily_allowance_changed'
  | 'mode_changed'
  | 'daily_reset';

export interface EventLogItem {
  id: string;
  timestamp: number;
  type: EventType;
  description: string;
  childId?: string;
  childName?: string;
  details?: Record<string, any>;
}

export interface VerificationRecord {
  id: string;
  timestamp: number;
  childId: string;
  childName: string;
  photoUrl: string;
  reason: string; // e.g., 'Extra Time Request', 'Periodic Verification'
}

export interface EmergencyContact {
  id: string;
  name: string;
  phone: string;
  relation: string;
  icon?: string;
}

export interface AppSettings {
  language: Language;
  controlMode: ControlMode; // 'scheduled' | 'free'
  parentPinHash: string;
  parentPinSalt: string;
  failedPinAttempts: number;
  pinLockoutUntil: number; // timestamp
  parentSessionTimeoutMinutes: number; // e.g. 5 minutes
  flagSecureEnabled: boolean; // anti screen-recording protection
  requireVerificationForExtraTime: boolean;
  timeManipulationProtection: boolean;
  deviceOwnerEnabled: boolean;
  accessibilityEnabled: boolean;
  usageAccessEnabled: boolean;
  emergencyContacts: EmergencyContact[];
  verificationRetentionDays: number;
  smartBlock?: SmartBlockConfig;
  smartBlockModes?: SmartBlockMode[];
  webFilter?: WebFilterConfig;
  batteryMonitor?: AppBatteryUsage[];
  usageModes: UsageMode[];
}

export interface SessionState {
  isActive: boolean;
  sessionStartTime: number | null; // epoch timestamp
  elapsedTodayMinutes: number;
  freeModeUsedSecondsToday: number; // Precise seconds counter for Free Mode
  lastResetDateStr: string; // "YYYY-MM-DD" for local midnight reset
  activeSessionDurationMinutes: number;
  extraTimeMinutes: number;
  extraTimeGrantedAt: number | null;
  extraTimeEndTimestamp: number | null; // epoch timestamp in ms when extra time expires
  extraTimeConsumed?: boolean; // When true, extra time has been consumed and finished for this cycle
  isLocked: boolean;
  lockReason: 'schedule_expired' | 'daily_limit_reached' | 'session_limit_reached' | 'manual_lock' | 'test_mode' | 'extra_time_exhausted' | null;
  lastHeartbeatTimestamp: number;
  activeUsageModeId: string; // "normal", "study", "gaming", "video", or custom ID
}

export interface ExtraTimeRequest {
  id: string;
  childId: string;
  childName: string;
  requestedMinutes: number;
  reason: string;
  timestamp: number;
  status: 'pending' | 'approved' | 'rejected';
}
