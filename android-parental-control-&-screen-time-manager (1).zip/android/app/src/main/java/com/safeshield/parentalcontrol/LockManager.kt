package com.safeshield.parentalcontrol

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.UserManager
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import java.security.MessageDigest

class LockManager(private val context: Context) {

    companion object {
        private const val PREFS_FILE = "safeshield_secure_prefs"
        private const val KEY_IS_LOCKED = "is_device_locked"
        private const val KEY_LOCK_REASON = "lock_reason"
        private const val KEY_PIN_HASH = "parent_pin_hash"
        private const val KEY_PIN_SALT = "parent_pin_salt"
        private const val DEFAULT_PIN_SALT = "safeshield_default_salt"
    }

    private val securePrefs by lazy {
        try {
            val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
            EncryptedSharedPreferences.create(
                PREFS_FILE,
                masterKeyAlias,
                context,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            context.getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE)
        }
    }

    fun isLocked(): Boolean {
        return securePrefs.getBoolean(KEY_IS_LOCKED, false)
    }

    fun getLockReason(): String {
        return securePrefs.getString(KEY_LOCK_REASON, "daily_limit_reached") ?: "daily_limit_reached"
    }

    fun lockDevice(reason: String = "daily_limit_reached") {
        securePrefs.edit()
            .putBoolean(KEY_IS_LOCKED, true)
            .putString(KEY_LOCK_REASON, reason)
            .apply()

        // Launch Lock Screen Activity
        val intent = Intent(context, LockScreenActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("EXTRA_REASON", reason)
        }
        context.startActivity(intent)

        NotificationHelper(context).showNotification(
            "Device Locked",
            "Screen-time limit or restriction rule active ($reason)",
            "lock"
        )
    }

    fun unlockDevice(inputPin: String): Boolean {
        if (verifyPin(inputPin)) {
            securePrefs.edit()
                .putBoolean(KEY_IS_LOCKED, false)
                .putString(KEY_LOCK_REASON, null)
                .apply()
            return true
        }
        return false
    }

    fun setParentPin(pin: String) {
        val salt = DEFAULT_PIN_SALT
        val hash = hashPin(pin, salt)
        securePrefs.edit()
            .putString(KEY_PIN_HASH, hash)
            .putString(KEY_PIN_SALT, salt)
            .apply()
    }

    fun verifyPin(inputPin: String): Boolean {
        val storedHash = securePrefs.getString(KEY_PIN_HASH, null)
        val storedSalt = securePrefs.getString(KEY_PIN_SALT, DEFAULT_PIN_SALT) ?: DEFAULT_PIN_SALT

        // If no PIN set yet, default to "1234"
        if (storedHash == null) {
            return inputPin == "1234"
        }

        val computedHash = hashPin(inputPin, storedSalt)
        return computedHash == storedHash
    }

    private fun hashPin(pin: String, salt: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val combined = "$pin:$salt".toByteArray(Charsets.UTF_8)
        val digest = md.digest(combined)
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun enableKioskMode(activity: Activity) {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val adminComponent = ComponentName(context, DeviceAdminReceiver::class.java)

        if (dpm.isDeviceOwnerApp(context.packageName)) {
            try {
                dpm.setLockTaskPackages(adminComponent, arrayOf(context.packageName))
                activity.startLockTask()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun disableKioskMode(activity: Activity) {
        try {
            activity.stopLockTask()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
