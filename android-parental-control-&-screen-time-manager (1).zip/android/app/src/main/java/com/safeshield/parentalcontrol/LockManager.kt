package com.safeshield.parentalcontrol

import android.app.Activity
import android.app.ActivityManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.UserManager
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom

class LockManager(private val context: Context) {

    companion object {
        private const val TAG = "SafeShieldLockManager"
        private const val PREFS_FILE = "safeshield_secure_prefs"
        private const val KEY_IS_LOCKED = "is_device_locked"
        private const val KEY_LOCK_REASON = "lock_reason"
        private const val KEY_PIN_HASH = "parent_pin_hash"
        private const val KEY_PIN_SALT = "parent_pin_salt"
        private const val KEY_IS_KIOSK_ENABLED = "is_kiosk_enabled"
        private const val DEFAULT_PIN_SALT = "safeshield_secure_salt_v1"
        const val DEVICE_OWNER_ADB_COMMAND =
            "adb shell dpm set-device-owner com.safeshield.parentalcontrol/.DeviceAdminReceiver"
    }

    private val securePrefs by lazy {
        try {
            val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
            EncryptedSharedPreferences.create(
                PREFS_FILE,
                masterKeyAlias,
                context,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            Log.w(TAG, "EncryptedSharedPreferences fallback: ${e.message}")
            context.getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE)
        }
    }

    private val dpm: DevicePolicyManager by lazy {
        context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    }

    private val adminComponent: ComponentName by lazy {
        ComponentName(context, DeviceAdminReceiver::class.java)
    }

    // ==========================================
    // DEVICE OWNER & ADMIN STATUS
    // ==========================================

    fun isDeviceOwner(): Boolean {
        return try {
            dpm.isDeviceOwnerApp(context.packageName)
        } catch (e: Exception) {
            Log.e(TAG, "Error checking isDeviceOwner: ${e.message}")
            false
        }
    }

    fun isDeviceAdmin(): Boolean {
        return try {
            dpm.isAdminActive(adminComponent)
        } catch (e: Exception) {
            Log.e(TAG, "Error checking isDeviceAdmin: ${e.message}")
            false
        }
    }

    fun isLockTaskPermitted(): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                dpm.isLockTaskPermitted(context.packageName)
            } else {
                isDeviceOwner()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error checking isLockTaskPermitted: ${e.message}")
            false
        }
    }

    fun getDeviceOwnerSetupInstructions(): String {
        return if (isDeviceOwner()) {
            "Provisioned: SafeShield is the active Device Owner on this system."
        } else {
            "SafeShield requires Device Owner / dedicated-device setup for full kiosk protection.\n\n" +
                    "Run via computer terminal (ADB):\n" +
                    DEVICE_OWNER_ADB_COMMAND
        }
    }

    fun getKioskDiagnostics(activity: Activity? = null): String {
        val isDO = isDeviceOwner()
        val isDA = isDeviceAdmin()
        val isPermitted = isLockTaskPermitted()
        val inLockTask = if (activity != null) isInLockTaskMode(activity) else isKioskEnabled() && isDO
        val isKiosk = isKioskEnabled() && isDO

        val json = JSONObject().apply {
            put("deviceOwner", if (isDO) "YES" else "NO")
            put("isDeviceOwner", isDO)
            put("deviceAdmin", if (isDA) "YES" else "NO")
            put("isDeviceAdmin", isDA)
            put("lockTaskPermitted", if (isPermitted) "YES" else "NO")
            put("isLockTaskPermitted", isPermitted)
            put("lockTaskMode", if (inLockTask) "ACTIVE" else "INACTIVE")
            put("isInLockTaskMode", inLockTask)
            put("kioskMode", if (isKiosk) "ACTIVE" else "INACTIVE")
            put("isKioskActive", isKiosk)
            put("hasCustomPin", hasCustomPin())
            put("packageName", context.packageName)
            put("adbCommand", DEVICE_OWNER_ADB_COMMAND)
            put("statusExplanation", when {
                isDO && inLockTask -> "Full Kiosk Active: Device Owner Lock Task Mode is enforcing complete system lockdown."
                isDO && !inLockTask -> "Device Owner Provisioned: Full kiosk mode is ready to activate."
                !isDO && isDA -> "Device Admin Enabled: Basic admin active, but Device Owner provisioning is required for unbreakable kiosk lock."
                else -> "Standard Mode: SafeShield requires Device Owner setup via ADB for full kiosk protection."
            })
        }
        return json.toString()
    }

    // ==========================================
    // KIOSK / LOCK TASK POLICIES (OFFICIAL ANDROID API)
    // ==========================================

    fun isKioskEnabled(): Boolean {
        // Full kiosk is only genuinely enabled when Device Owner is present
        val saved = securePrefs.getBoolean(KEY_IS_KIOSK_ENABLED, false)
        return saved && isDeviceOwner()
    }

    fun setKioskEnabled(enabled: Boolean) {
        securePrefs.edit().putBoolean(KEY_IS_KIOSK_ENABLED, enabled).apply()
    }

    fun isInLockTaskMode(activity: Activity): Boolean {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.lockTaskModeState != ActivityManager.LOCK_TASK_MODE_NONE
            } else {
                am.isInLockTaskMode
            }
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Configures dedicated-device / kiosk restrictions using official DevicePolicyManager APIs.
     * Prevents Recent Apps escape, Home button exit, notification shade pull-down, safe-mode boot.
     */
    fun configureDeviceOwnerKioskPolicies(): Boolean {
        if (!isDeviceOwner()) {
            Log.w(TAG, "Cannot configure kiosk policies: App is not Device Owner.")
            return false
        }

        return try {
            // 1. Allowlist SafeShield for Lock Task mode
            dpm.setLockTaskPackages(adminComponent, arrayOf(context.packageName))

            // 2. Disable system UI escape vectors (Recent Apps / Home / Notifications)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                dpm.setLockTaskFeatures(
                    adminComponent,
                    DevicePolicyManager.LOCK_TASK_FEATURE_NONE
                )
            }

            // 3. Set Device Owner anti-bypass user restrictions
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                dpm.addUserRestriction(adminComponent, UserManager.DISALLOW_SAFE_BOOT)
                dpm.addUserRestriction(adminComponent, UserManager.DISALLOW_ADD_USER)
                dpm.addUserRestriction(adminComponent, UserManager.DISALLOW_FACTORY_RESET)
                dpm.addUserRestriction(adminComponent, UserManager.DISALLOW_SYSTEM_ERROR_DIALOGS)
            }

            Log.i(TAG, "Device Owner dedicated kiosk policies configured successfully.")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error setting Device Owner kiosk policies: ${e.message}", e)
            false
        }
    }

    /**
     * Enters official Android Lock Task Mode.
     * When Device Owner: configures kiosk allowlist and enters without user prompt.
     * When NOT Device Owner: refuses to enter and returns false to prevent false kiosk state.
     */
    fun startLockTaskMode(activity: Activity): Boolean {
        if (!isDeviceOwner()) {
            Log.w(TAG, "Cannot enter Kiosk Mode: Device Owner is not provisioned.")
            setKioskEnabled(false)
            return false
        }

        return try {
            configureDeviceOwnerKioskPolicies()
            activity.startLockTask()
            setKioskEnabled(true)
            Log.i(TAG, "Official Device Owner Lock Task Mode activated successfully.")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start Lock Task Mode: ${e.message}", e)
            setKioskEnabled(false)
            false
        }
    }

    /**
     * Exits official Android Lock Task Mode upon parent PIN verification.
     */
    fun stopLockTaskMode(activity: Activity, pin: String): Boolean {
        if (!verifyPin(pin)) {
            Log.w(TAG, "Cannot exit Lock Task Mode: Invalid parent PIN.")
            return false
        }

        return try {
            activity.stopLockTask()
            setKioskEnabled(false)
            unlockDevice(pin)
            Log.i(TAG, "Lock Task Mode exited successfully by verified parent.")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to stop Lock Task Mode: ${e.message}", e)
            false
        }
    }

    // ==========================================
    // DEVICE LOCK OVERLAY & STATE
    // ==========================================

    fun isLocked(): Boolean {
        return securePrefs.getBoolean(KEY_IS_LOCKED, false)
    }

    fun getLockReason(): String {
        return securePrefs.getString(KEY_LOCK_REASON, "daily_limit_reached") ?: "daily_limit_reached"
    }

    fun lockDevice(reason: String = "daily_limit_reached") {
        securePrefs.edit()
            .putBoolean(KEY_IS_LOCKED, true)
            .putString(KEY_LOCK_REASON, reason)
            .apply()

        // Launch Lock Screen Activity
        val intent = Intent(context, LockScreenActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("EXTRA_REASON", reason)
        }
        context.startActivity(intent)

        NotificationHelper(context).showNotification(
            "Device Locked",
            "Screen-time limit or restriction rule active ($reason)",
            "lock"
        )
    }

    fun unlockDevice(inputPin: String): Boolean {
        if (verifyPin(inputPin)) {
            securePrefs.edit()
                .putBoolean(KEY_IS_LOCKED, false)
                .putString(KEY_LOCK_REASON, null)
                .apply()
            return true
        }
        return false
    }

    // ==========================================
    // SECURE PARENT PIN MANAGEMENT
    // ==========================================

    fun setParentPin(pin: String): Boolean {
        if (pin.length < 4) return false
        val salt = generateSalt()
        val hash = hashPin(pin, salt)
        securePrefs.edit()
            .putString(KEY_PIN_HASH, hash)
            .putString(KEY_PIN_SALT, salt)
            .apply()
        Log.i(TAG, "Parent PIN updated securely.")
        return true
    }

    fun changeParentPin(oldPin: String, newPin: String): Boolean {
        if (!verifyPin(oldPin)) {
            return false
        }
        return setParentPin(newPin)
    }

    fun verifyPin(inputPin: String): Boolean {
        val storedHash = securePrefs.getString(KEY_PIN_HASH, null)
        val storedSalt = securePrefs.getString(KEY_PIN_SALT, DEFAULT_PIN_SALT) ?: DEFAULT_PIN_SALT

        // If no custom PIN set yet, default to "1234"
        if (storedHash == null) {
            return inputPin == "1234"
        }

        val computedHash = hashPin(inputPin, storedSalt)
        return computedHash == storedHash
    }

    fun hasCustomPin(): Boolean {
        return securePrefs.getString(KEY_PIN_HASH, null) != null
    }

    private fun generateSalt(): String {
        val random = SecureRandom()
        val saltBytes = ByteArray(16)
        random.nextBytes(saltBytes)
        return saltBytes.joinToString("") { "%02x".format(it) }
    }

    private fun hashPin(pin: String, salt: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val combined = "$pin:$salt".toByteArray(Charsets.UTF_8)
        val digest = md.digest(combined)
        return digest.joinToString("") { "%02x".format(it) }
    }
}

