import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { NATIVE_ANDROID_FILES } from '../../data/nativeAndroidCode';
import { Download, Copy, Check, X, FileCode, ShieldCheck, Terminal, Smartphone, Sparkles } from 'lucide-react';

export const AndroidExporterModal: React.FC = () => {
  const { showExportModal, setShowExportModal } = useApp();
  const [selectedFileIdx, setSelectedFileIdx] = useState(0);
  const [copied, setCopied] = useState(false);

  if (!showExportModal) return null;

  const currentFile = NATIVE_ANDROID_FILES[selectedFileIdx];

  const handleCopyCode = () => {
    navigator.clipboard.writeText(currentFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = () => {
    // Generate a downloadable JSON/source file bundle
    const bundleStr = JSON.stringify(NATIVE_ANDROID_FILES, null, 2);
    const blob = new Blob([bundleStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'ParentalControlV2_Android_Native_Project.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-5xl h-[85vh] flex flex-col shadow-xl text-slate-900 overflow-hidden relative">
        {/* Header */}
        <div className="p-5 bg-slate-50 border-b border-slate-200 flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-3 rtl:space-x-reverse">
            <div className="p-2.5 bg-emerald-50 text-emerald-600 rounded-xl border border-emerald-200">
              <Smartphone className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold flex items-center gap-2 text-slate-900">
                Export Native Android Kotlin Project
                <span className="text-xs bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded-full font-bold">
                  Device Owner Ready
                </span>
              </h2>
              <p className="text-xs text-slate-500 font-medium">
                Official Android APIs: DevicePolicyManager, LockTaskMode, UsageStats, BootReceiver
              </p>
            </div>
          </div>
          <button
            onClick={() => setShowExportModal(false)}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Split: Sidebar file explorer + Code viewer */}
        <div className="flex-1 flex overflow-hidden">
          {/* File Explorer Sidebar */}
          <div className="w-64 bg-slate-50/50 border-r border-slate-200 p-4 shrink-0 overflow-y-auto">
            <h3 className="text-xs font-bold uppercase text-slate-500 tracking-wider mb-3 flex items-center gap-1.5">
              <FileCode className="w-4 h-4 text-blue-600" />
              Source Structure
            </h3>
            <div className="space-y-1">
              {NATIVE_ANDROID_FILES.map((file, idx) => (
                <button
                  key={file.filename}
                  onClick={() => setSelectedFileIdx(idx)}
                  className={`w-full text-left rtl:text-right px-3 py-2 rounded-xl text-xs font-bold transition flex items-center space-x-2 rtl:space-x-reverse ${
                    selectedFileIdx === idx
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <FileCode className="w-3.5 h-3.5 shrink-0" />
                  <span className="truncate">{file.filename}</span>
                </button>
              ))}
            </div>

            {/* ADB Device Owner Command Box */}
            <div className="mt-6 p-3 bg-white border border-slate-200 rounded-xl shadow-xs">
              <h4 className="text-[11px] font-bold text-amber-700 flex items-center gap-1 mb-1">
                <Terminal className="w-3.5 h-3.5" />
                ADB Activation
              </h4>
              <p className="text-[10px] text-slate-500 font-medium mb-2">
                Run via ADB on child's device for Anti-Bypass Device Owner mode:
              </p>
              <pre className="bg-slate-900 p-2 rounded text-[10px] text-emerald-400 overflow-x-auto font-mono select-all">
                adb shell dpm set-device-owner com.parentalcontrol.v2/.receiver.DeviceAdminReceiver
              </pre>
            </div>
          </div>

          {/* Main Code Viewer */}
          <div className="flex-1 flex flex-col bg-slate-900 overflow-hidden">
            {/* Toolbar */}
            <div className="p-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between shrink-0">
              <span className="text-xs font-mono text-blue-300 font-bold">{currentFile.path}</span>
              <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <button
                  onClick={handleCopyCode}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-lg border border-slate-700 transition flex items-center space-x-1.5 rtl:space-x-reverse"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied!' : 'Copy Code'}</span>
                </button>
                <button
                  onClick={handleDownloadZip}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-xs transition flex items-center space-x-1.5 rtl:space-x-reverse"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Bundle</span>
                </button>
              </div>
            </div>

            {/* Code Content */}
            <div className="flex-1 p-4 overflow-auto bg-slate-950 font-mono text-xs text-slate-200 leading-relaxed">
              <pre>{currentFile.content}</pre>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0 text-xs text-slate-500 font-medium">
          <span className="flex items-center gap-1.5 font-bold text-slate-700">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            100% Official Android APIs — Zero Root / Malware / Exploits
          </span>
          <button
            onClick={() => setShowExportModal(false)}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded-xl transition text-xs"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
