import React from 'react';
import { useApp } from '../context/AppContext';
import { translations } from '../data/translations';
import { nativeBridge } from '../utils/nativeBridge';
import { FlaskConical, RefreshCw, Clock, AlertOctagon, Bell, Shield, Sparkles } from 'lucide-react';

export const TestModeBar: React.FC = () => {
  const {
    forceLockDevice,
    simulateReboot,
    simulateTimeChange,
    language,
    addNotification,
    setActiveUsageMode
  } = useApp();

  const t = translations[language];

  const handleTestNotification = () => {
    nativeBridge.showNativeNotification(
      'Screen Time Alert',
      'Child Adam has 15 minutes remaining today.',
      'info'
    );
    addNotification('Native Notification Triggered', 'SafeShield alert sent to notification shade.', 'info');
  };

  const handleSimulateSmartBlock = () => {
    setActiveUsageMode('study');
    addNotification('Smart Block Simulated', 'Switched to Study Mode: games and social apps restricted.', 'warning');
  };

  return (
    <div className="bg-slate-900 border-b border-slate-800 text-slate-200 px-3 sm:px-6 lg:px-8 py-2 text-xs w-full">
      <div className="w-full flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center space-x-2 rtl:space-x-reverse font-medium">
          <FlaskConical className="w-4 h-4 text-blue-400 shrink-0 aspect-square" />
          <span className="font-semibold text-white">{t.testSimulationTitle}:</span>
          <span className="text-slate-400 hidden md:inline">
            Native Android protection &amp; anti-bypass simulation suite
          </span>
        </div>

        <div className="flex items-center space-x-2 rtl:space-x-reverse flex-wrap gap-y-1">
          {/* Quick 1m Test Lock */}
          <button
            onClick={() => forceLockDevice('test_mode')}
            className="px-2.5 py-1 bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/30 rounded-lg transition font-bold flex items-center space-x-1.5 rtl:space-x-reverse min-h-[32px]"
          >
            <AlertOctagon className="w-3.5 h-3.5 text-red-400 shrink-0 aspect-square" />
            <span>{t.testOneMinLock}</span>
          </button>

          {/* Simulate Reboot */}
          <button
            onClick={simulateReboot}
            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg transition font-bold flex items-center space-x-1.5 rtl:space-x-reverse min-h-[32px]"
          >
            <RefreshCw className="w-3.5 h-3.5 text-blue-400 shrink-0 aspect-square" />
            <span>{t.simulateReboot}</span>
          </button>

          {/* Simulate Time Change */}
          <button
            onClick={simulateTimeChange}
            className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 rounded-lg transition font-bold flex items-center space-x-1.5 rtl:space-x-reverse min-h-[32px]"
          >
            <Clock className="w-3.5 h-3.5 text-amber-400 shrink-0 aspect-square" />
            <span>{t.simulateTimeDrift}</span>
          </button>

          {/* Test Smart Block */}
          <button
            onClick={handleSimulateSmartBlock}
            className="px-2.5 py-1 bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/30 rounded-lg transition font-bold flex items-center space-x-1.5 rtl:space-x-reverse min-h-[32px]"
          >
            <Shield className="w-3.5 h-3.5 text-purple-400 shrink-0 aspect-square" />
            <span>Simulate Smart Block</span>
          </button>

          {/* Test Notification */}
          <button
            onClick={handleTestNotification}
            className="px-2.5 py-1 bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 border border-blue-500/30 rounded-lg transition font-bold flex items-center space-x-1.5 rtl:space-x-reverse min-h-[32px]"
          >
            <Bell className="w-3.5 h-3.5 text-blue-400 shrink-0 aspect-square" />
            <span>Test Notification</span>
          </button>
        </div>
      </div>
    </div>
  );
};
