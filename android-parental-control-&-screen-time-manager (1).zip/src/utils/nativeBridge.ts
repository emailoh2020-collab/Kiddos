// SafeShield JavaScript <-> Kotlin Native Bridge
// Provides seamless two-way communication with Android Native Layer

import { AppInfo, AppBatteryUsage } from '../types';
import { RuleEvaluationResult } from './ruleEvaluator';

export interface NativePermissionStatus {
  usageAccessGranted: boolean;
  overlayGranted: boolean;
  accessibilityEnabled: boolean;
  deviceAdminActive: boolean;
  deviceOwnerActive: boolean;
  monitoringServiceRunning: boolean;
  bootProtectionActive: boolean;
  smartBlockEngineRunning: boolean;
}

export interface NativeBatteryState {
  batteryLevelPercent: number;
  isCharging: boolean;
  powerSaveMode: boolean;
  apps: AppBatteryUsage[];
}

export interface NativeLogEntry {
  id: string;
  type: string;
  title: string;
  details: string;
  timestamp: number;
  packageName?: string;
}

// Window declaration for Kotlin Android JavaScriptInterface
declare global {
  interface Window {
    NativeBridge?: {
      getInstalledApplications: () => string;
      getForegroundApplication: () => string;
      getApplicationUsage: (packageName: string) => string;
      getTodayUsage: () => string;
      getWeeklyUsage: () => string;
      getBatteryStatus: () => string;
      isUsageAccessGranted: () => boolean;
      requestUsageAccess: () => void;
      isOverlayPermissionGranted: () => boolean;
      requestOverlayPermission: () => void;
      isAccessibilityServiceEnabled: () => boolean;
      openAccessibilitySettings: () => void;
      isDeviceAdminEnabled: () => boolean;
      requestDeviceAdmin: () => void;
      isDeviceOwner: () => boolean;
      getDeviceOwnerStatus: () => string;
      isIgnoringBatteryOptimizations: () => boolean;
      requestIgnoreBatteryOptimizations: () => void;
      lockDevice: (reason: string) => boolean;
      unlockDevice: (pin: string) => boolean;
      blockApplication: (packageName: string) => void;
      allowApplication: (packageName: string) => void;
      startMonitoring: () => void;
      stopMonitoring: () => void;
      applySchedule: (scheduleJson: string) => void;
      getCurrentMode: () => string;
      setCurrentMode: (mode: string) => void;
      getNativePermissions: () => string;
      showNativeNotification: (title: string, message: string, type: string) => void;
      requestExtraTime: (minutes: number) => void;
      restartMonitoringService: () => void;
      authenticateBiometric: (title: string, subtitle: string) => boolean;
      syncStateToNative: (stateJson: string) => void;
      getNativeEventLogs: () => string;
      clearNativeEventLogs: () => void;
      evaluateAppAccess: (packageName: string, category: string) => string;
    };
  }
}

class NativeAndroidBridgeClient {
  public isNativeEnvironment(): boolean {
    return typeof window !== 'undefined' && !!window.NativeBridge;
  }

  // Permissions Check & Request
  public isUsageAccessGranted(): boolean {
    if (this.isNativeEnvironment()) {
      return !!window.NativeBridge?.isUsageAccessGranted();
    }
    return true; // Web preview fallback
  }

  public requestUsageAccess(): void {
    if (this.isNativeEnvironment()) {
      window.NativeBridge?.requestUsageAccess();
    } else {
      console.info('[NativeBridge] Requesting Android Usage Access settings.');
    }
  }

  public isOverlayPermissionGranted(): boolean {
    if (this.isNativeEnvironment()) {
      return !!window.NativeBridge?.isOverlayPermissionGranted();
    }
    return true;
  }

  public requestOverlayPermission(): void {
    if (this.isNativeEnvironment()) {
      window.NativeBridge?.requestOverlayPermission();
    } else {
      console.info('[NativeBridge] Requesting Android System Alert Window (Overlay) permission.');
    }
  }

  public isAccessibilityServiceEnabled(): boolean {
    if (this.isNativeEnvironment()) {
      return !!window.NativeBridge?.isAccessibilityServiceEnabled();
    }
    return true;
  }

  public openAccessibilitySettings(): void {
    if (this.isNativeEnvironment()) {
      window.NativeBridge?.openAccessibilitySettings();
    } else {
      console.info('[NativeBridge] Opening Android Accessibility Settings.');
    }
  }

  public isDeviceAdminEnabled(): boolean {
    if (this.isNativeEnvironment()) {
      return !!window.NativeBridge?.isDeviceAdminEnabled();
    }
    return true;
  }

  public requestDeviceAdmin(): void {
    if (this.isNativeEnvironment()) {
      window.NativeBridge?.requestDeviceAdmin();
    } else {
      console.info('[NativeBridge] Prompting Device Administrator activation.');
    }
  }

  public isDeviceOwner(): boolean {
    if (this.isNativeEnvironment()) {
      return !!window.NativeBridge?.isDeviceOwner();
    }
    return false;
  }

  public getDeviceOwnerStatus(): { isProvisioned: boolean; details: string } {
    if (this.isNativeEnvironment()) {
      try {
        const raw = window.NativeBridge?.getDeviceOwnerStatus();
        return raw ? { isProvisioned: raw.includes('Provisioned:'), details: raw } : { isProvisioned: false, details: 'Unknown' };
      } catch (e) {
        return { isProvisioned: false, details: 'Error reading device owner status' };
      }
    }
    return {
      isProvisioned: false,
      details: 'Device Owner must be provisioned during device setup via ADB:\nadb shell dpm set-device-owner com.safeshield.parentalcontrol/.DeviceAdminReceiver'
    };
  }

  public isIgnoringBatteryOptimizations(): boolean {
    if (this.isNativeEnvironment()) {
      return !!window.NativeBridge?.isIgnoringBatteryOptimizations();
    }
    return true;
  }

  public requestIgnoreBatteryOptimizations(): void {
    if (this.isNativeEnvironment()) {
      window.NativeBridge?.requestIgnoreBatteryOptimizations();
    } else {
      console.info('[NativeBridge] Requesting battery optimization exemption.');
    }
  }

  public getNativePermissions(): NativePermissionStatus {
    if (this.isNativeEnvironment()) {
      try {
        const raw = window.NativeBridge?.getNativePermissions();
        if (raw) return JSON.parse(raw);
      } catch (e) {
        console.error('[NativeBridge] Failed to parse permissions', e);
      }
    }
    // Realistic status for web preview environment
    return {
      usageAccessGranted: true,
      overlayGranted: true,
      accessibilityEnabled: true,
      deviceAdminActive: true,
      deviceOwnerActive: false,
      monitoringServiceRunning: true,
      bootProtectionActive: true,
      smartBlockEngineRunning: true
    };
  }

  // Applications & Usage
  public getInstalledApplications(): AppInfo[] {
    if (this.isNativeEnvironment()) {
      try {
        const raw = window.NativeBridge?.getInstalledApplications();
        if (raw) return JSON.parse(raw);
      } catch (e) {
        console.error('[NativeBridge] Failed to get installed apps', e);
      }
    }
    return [];
  }

  public getForegroundApplication(): string {
    if (this.isNativeEnvironment()) {
      return window.NativeBridge?.getForegroundApplication() || 'com.safeshield.parentalcontrol';
    }
    return 'com.safeshield.parentalcontrol';
  }

  public getTodayUsage(): Record<string, number> {
    if (this.isNativeEnvironment()) {
      try {
        const raw = window.NativeBridge?.getTodayUsage();
        if (raw) return JSON.parse(raw);
      } catch (e) {
        console.error('[NativeBridge] Error reading today usage', e);
      }
    }
    return {};
  }

  public getBatteryStatus(): NativeBatteryState {
    if (this.isNativeEnvironment()) {
      try {
        const raw = window.NativeBridge?.getBatteryStatus();
        if (raw) return JSON.parse(raw);
      } catch (e) {
        console.error('[NativeBridge] Error reading battery status', e);
      }
    }
    return {
      batteryLevelPercent: 88,
      isCharging: false,
      powerSaveMode: false,
      apps: []
    };
  }

  // Device Lock & Enforcement
  public lockDevice(reason: string = 'daily_limit_reached'): boolean {
    if (this.isNativeEnvironment()) {
      return !!window.NativeBridge?.lockDevice(reason);
    }
    console.info(`[NativeBridge] Device locked via NativeBridge (Reason: ${reason})`);
    return true;
  }

  public unlockDevice(pin: string): boolean {
    if (this.isNativeEnvironment()) {
      return !!window.NativeBridge?.unlockDevice(pin);
    }
    console.info('[NativeBridge] Device unlocked via NativeBridge');
    return true;
  }

  public blockApplication(packageName: string): void {
    if (this.isNativeEnvironment()) {
      window.NativeBridge?.blockApplication(packageName);
    } else {
      console.info(`[NativeBridge] Blocked application: ${packageName}`);
    }
  }

  public allowApplication(packageName: string): void {
    if (this.isNativeEnvironment()) {
      window.NativeBridge?.allowApplication(packageName);
    } else {
      console.info(`[NativeBridge] Allowed application: ${packageName}`);
    }
  }

  public startMonitoring(): void {
    if (this.isNativeEnvironment()) {
      window.NativeBridge?.startMonitoring();
    }
  }

  public stopMonitoring(): void {
    if (this.isNativeEnvironment()) {
      window.NativeBridge?.stopMonitoring();
    }
  }

  public restartMonitoringService(): void {
    if (this.isNativeEnvironment()) {
      window.NativeBridge?.restartMonitoringService();
    } else {
      console.info('[NativeBridge] Restarting native UsageMonitorService & AppBlockingService');
    }
  }

  public applySchedule(schedule: any): void {
    if (this.isNativeEnvironment()) {
      window.NativeBridge?.applySchedule(JSON.stringify(schedule));
    }
  }

  public setCurrentMode(mode: string): void {
    if (this.isNativeEnvironment()) {
      window.NativeBridge?.setCurrentMode(mode);
    }
  }

  public showNativeNotification(title: string, message: string, type: 'info' | 'warning' | 'lock' | 'success' = 'info'): void {
    if (this.isNativeEnvironment()) {
      window.NativeBridge?.showNativeNotification(title, message, type);
    }
  }

  public requestExtraTime(minutes: number): void {
    if (this.isNativeEnvironment()) {
      window.NativeBridge?.requestExtraTime(minutes);
    }
  }

  public authenticateBiometric(title: string, subtitle: string): Promise<boolean> {
    if (this.isNativeEnvironment() && window.NativeBridge?.authenticateBiometric) {
      return Promise.resolve(window.NativeBridge.authenticateBiometric(title, subtitle));
    }
    return Promise.resolve(true);
  }

  public syncStateToNative(fullState: any): void {
    if (this.isNativeEnvironment()) {
      try {
        window.NativeBridge?.syncStateToNative(JSON.stringify(fullState));
      } catch (e) {
        console.error('[NativeBridge] Failed to sync state to native', e);
      }
    }
  }

  public getNativeEventLogs(): NativeLogEntry[] {
    if (this.isNativeEnvironment() && window.NativeBridge?.getNativeEventLogs) {
      try {
        const raw = window.NativeBridge.getNativeEventLogs();
        if (raw) return JSON.parse(raw);
      } catch (e) {
        console.error('[NativeBridge] Failed to parse event logs', e);
      }
    }
    return [];
  }

  public clearNativeEventLogs(): void {
    if (this.isNativeEnvironment() && window.NativeBridge?.clearNativeEventLogs) {
      window.NativeBridge.clearNativeEventLogs();
    }
  }

  public evaluateAppAccess(packageName: string, category: string = 'other'): RuleEvaluationResult | null {
    if (this.isNativeEnvironment() && window.NativeBridge?.evaluateAppAccess) {
      try {
        const raw = window.NativeBridge.evaluateAppAccess(packageName, category);
        if (raw) return JSON.parse(raw);
      } catch (e) {
        console.error('[NativeBridge] Failed to evaluate app access natively', e);
      }
    }
    return null;
  }
}

export const nativeBridge = new NativeAndroidBridgeClient();

