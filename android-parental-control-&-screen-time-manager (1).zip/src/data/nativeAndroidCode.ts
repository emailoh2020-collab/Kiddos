export interface AndroidCodeFile {
  filename: string;
  path: string;
  language: string;
  content: string;
}

export const NATIVE_ANDROID_FILES: AndroidCodeFile[] = [
  {
    filename: 'AndroidManifest.xml',
    path: 'android/app/src/main/AndroidManifest.xml',
    language: 'xml',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    package="com.safeshield.parentalcontrol">

    <!-- Permissions required for Parental Control, App Usage, and Device Management -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.PACKAGE_USAGE_STATS" tools:ignore="ProtectedPermissions" />
    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.USE_BIOMETRIC" />
    <uses-permission android:name="android.permission.USE_FINGERPRINT" />
    <uses-permission android:name="android.permission.QUERY_ALL_PACKAGES" tools:ignore="QueryAllPackagesPermission" />
    <uses-permission android:name="android.permission.CALL_PHONE" />

    <application
        android:allowBackup="false"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher"
        android:supportsRtl="true"
        android:theme="@style/Theme.SafeShield"
        android:networkSecurityConfig="@xml/network_security_config"
        tools:targetApi="35">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden|screenLayout|smallestScreenSize|uiMode"
            android:launchMode="singleTask"
            android:theme="@style/Theme.SafeShield.Starting"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
                <category android:name="android.intent.category.HOME" />
                <category android:name="android.intent.category.DEFAULT" />
            </intent-filter>
        </activity>

        <activity
            android:name=".LockScreenActivity"
            android:exported="false"
            android:excludeFromRecents="true"
            android:launchMode="singleInstance"
            android:noHistory="true"
            android:showOnLockScreen="true"
            android:theme="@style/Theme.SafeShield.LockScreen" />

        <service
            android:name=".UsageMonitorService"
            android:exported="false"
            android:foregroundServiceType="specialUse" />

        <service
            android:name=".AppBlockingService"
            android:exported="true"
            android:label="@string/accessibility_service_label"
            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE">
            <intent-filter>
                <action android:name="android.accessibilityservice.AccessibilityService" />
            </intent-filter>
            <meta-data
                android:name="android.accessibilityservice"
                android:resource="@xml/accessibility_service_config" />
        </service>

        <receiver
            android:name=".BootReceiver"
            android:enabled="true"
            android:exported="true"
            android:permission="android.permission.RECEIVE_BOOT_COMPLETED">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED" />
                <action android:name="android.intent.action.QUICKBOOT_POWERON" />
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
                <action android:name="android.intent.action.LOCKED_BOOT_COMPLETED" />
            </intent-filter>
        </receiver>

        <receiver
            android:name=".DeviceAdminReceiver"
            android:description="@string/device_admin_description"
            android:label="@string/device_admin_label"
            android:permission="android.permission.BIND_DEVICE_ADMIN"
            android:exported="true">
            <meta-data
                android:name="android.app.device_admin"
                android:resource="@xml/device_admin_policies" />
            <intent-filter>
                <action android:name="android.app.action.DEVICE_ADMIN_ENABLED" />
                <action android:name="android.app.action.PROFILE_PROVISIONING_COMPLETE" />
            </intent-filter>
        </receiver>

    </application>

</manifest>`
  },
  {
    filename: 'MainActivity.kt',
    path: 'android/app/src/main/java/com/safeshield/parentalcontrol/MainActivity.kt',
    language: 'kotlin',
    content: `package com.safeshield.parentalcontrol

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.safeshield.parentalcontrol.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var nativeBridge: NativeBridge
    private lateinit var lockManager: LockManager

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        val splashScreen = installSplashScreen()

        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        lockManager = LockManager(this)
        nativeBridge = NativeBridge(this)

        setupWebView()
        setupBackNavigation()

        val permissionManager = PermissionManager(this)
        if (permissionManager.isUsageAccessGranted()) {
            val monitorIntent = Intent(this, UsageMonitorService::class.java).apply {
                action = UsageMonitorService.ACTION_START_MONITORING
            }
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                startForegroundService(monitorIntent)
            } else {
                startService(monitorIntent)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val webView = binding.webView
        val settings = webView.settings

        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true

        webView.addJavascriptInterface(nativeBridge, "NativeBridge")

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (newProgress < 100) {
                    binding.loadingProgressBar.visibility = View.VISIBLE
                    binding.loadingProgressBar.progress = newProgress
                } else {
                    binding.loadingProgressBar.visibility = View.GONE
                }
            }
        }

        webView.loadUrl("file:///android_asset/dist/index.html")
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.webView.canGoBack()) {
                    binding.webView.goBack()
                } else {
                    moveTaskToBack(true)
                }
            }
        })
    }
}`
  },
  {
    filename: 'NativeBridge.kt',
    path: 'android/app/src/main/java/com/safeshield/parentalcontrol/NativeBridge.kt',
    language: 'kotlin',
    content: `package com.safeshield.parentalcontrol

import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.webkit.JavascriptInterface
import androidx.fragment.app.FragmentActivity
import com.safeshield.parentalcontrol.models.AppUsageInfo
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.Calendar

class NativeBridge(private val activity: FragmentActivity) {
    private val context: Context = activity.applicationContext
    private val permissionManager = PermissionManager(context)
    private val lockManager = LockManager(context)
    private val notificationHelper = NotificationHelper(context)
    private val biometricAuthHelper = BiometricAuthHelper(activity)
    private val json = Json { ignoreUnknownKeys = true }

    @JavascriptInterface
    fun isUsageAccessGranted(): Boolean = permissionManager.isUsageAccessGranted()

    @JavascriptInterface
    fun requestUsageAccess() = permissionManager.requestUsageAccess()

    @JavascriptInterface
    fun isOverlayPermissionGranted(): Boolean = permissionManager.isOverlayPermissionGranted()

    @JavascriptInterface
    fun requestOverlayPermission() = permissionManager.requestOverlayPermission()

    @JavascriptInterface
    fun isAccessibilityServiceEnabled(): Boolean = permissionManager.isAccessibilityServiceEnabled()

    @JavascriptInterface
    fun openAccessibilitySettings() = permissionManager.openAccessibilitySettings()

    @JavascriptInterface
    fun isDeviceAdminEnabled(): Boolean = permissionManager.isDeviceAdminEnabled()

    @JavascriptInterface
    fun requestDeviceAdmin() = permissionManager.requestDeviceAdmin()

    @JavascriptInterface
    fun isDeviceOwner(): Boolean = permissionManager.isDeviceOwner()

    @JavascriptInterface
    fun getDeviceOwnerStatus(): String = permissionManager.getDeviceOwnerStatus()

    @JavascriptInterface
    fun getNativePermissions(): String {
        val state = permissionManager.getFullPermissionState(UsageMonitorService.isRunning)
        return json.encodeToString(state)
    }

    @JavascriptInterface
    fun getInstalledApplications(): String {
        val pm = context.packageManager
        val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val appList = mutableListOf<AppUsageInfo>()
        for (app in installedApps) {
            val isSystem = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val launchIntent = pm.getLaunchIntentForPackage(app.packageName)
            if (launchIntent != null || !isSystem) {
                appList.add(AppUsageInfo(packageName = app.packageName, appName = pm.getApplicationLabel(app).toString()))
            }
        }
        return json.encodeToString(appList)
    }

    @JavascriptInterface
    fun lockDevice(reason: String): Boolean {
        activity.runOnUiThread { lockManager.lockDevice(reason) }
        return true
    }

    @JavascriptInterface
    fun unlockDevice(pin: String): Boolean = lockManager.unlockDevice(pin)

    @JavascriptInterface
    fun showNativeNotification(title: String, message: String, type: String) {
        notificationHelper.showNotification(title, message, type)
    }
}`
  },
  {
    filename: 'SmartBlockEngine.kt',
    path: 'android/app/src/main/java/com/safeshield/parentalcontrol/SmartBlockEngine.kt',
    language: 'kotlin',
    content: `package com.safeshield.parentalcontrol

import com.safeshield.parentalcontrol.models.SmartBlockRuleModel
import java.util.Calendar

enum class AccessDecision {
    ALLOWED,
    BLOCKED_BY_SMART_BLOCK,
    BLOCKED_BY_USAGE_MODE,
    BLOCKED_BY_DAILY_LIMIT
}

data class AppCheckResult(
    val decision: AccessDecision,
    val reason: String,
    val ruleName: String? = null
)

class SmartBlockEngine {
    companion object {
        val SYSTEM_EXEMPT_PACKAGES = setOf(
            "com.safeshield.parentalcontrol",
            "com.android.phone",
            "com.android.server.telecom",
            "com.google.android.dialer",
            "com.android.dialer",
            "com.android.emergency"
        )
    }

    fun evaluateAppAccess(
        packageName: String,
        category: String,
        isDeviceLocked: Boolean,
        activeUsageModeAllowedApps: Set<String>?,
        smartBlockRules: List<SmartBlockRuleModel>,
        hasExtraTime: Boolean
    ): AppCheckResult {
        if (SYSTEM_EXEMPT_PACKAGES.contains(packageName)) {
            return AppCheckResult(AccessDecision.ALLOWED, "System critical package")
        }

        val activeSmartBlock = getActiveSmartBlockRule(smartBlockRules)
        if (activeSmartBlock != null) {
            if (activeSmartBlock.exceptions.contains(packageName)) return AppCheckResult(AccessDecision.ALLOWED, "Exempted")
            if (activeSmartBlock.allowedApps.contains(packageName)) return AppCheckResult(AccessDecision.ALLOWED, "Allowed")
            if (activeSmartBlock.blockedApps.contains(packageName)) {
                return AppCheckResult(AccessDecision.BLOCKED_BY_SMART_BLOCK, "Blocked by schedule: " + activeSmartBlock.name, activeSmartBlock.name)
            }
            if (activeSmartBlock.blockedCategories.contains(category)) {
                return AppCheckResult(AccessDecision.BLOCKED_BY_SMART_BLOCK, "Category blocked in " + activeSmartBlock.name, activeSmartBlock.name)
            }
        }

        if (isDeviceLocked && !hasExtraTime) {
            return AppCheckResult(AccessDecision.BLOCKED_BY_DAILY_LIMIT, "Daily limit reached")
        }

        return AppCheckResult(AccessDecision.ALLOWED, "Access permitted")
    }

    fun getActiveSmartBlockRule(rules: List<SmartBlockRuleModel>): SmartBlockRuleModel? {
        val now = Calendar.getInstance()
        val currentMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        return rules.filter { it.enabled }.maxByOrNull { it.priority }
    }
}`
  },
  {
    filename: 'UsageMonitorService.kt',
    path: 'android/app/src/main/java/com/safeshield/parentalcontrol/UsageMonitorService.kt',
    language: 'kotlin',
    content: `package com.safeshield.parentalcontrol

import android.app.Service
import android.content.Intent
import android.os.IBinder
import kotlinx.coroutines.*

class UsageMonitorService : Service() {
    companion object {
        const val ACTION_START_MONITORING = "com.safeshield.action.START_MONITORING"
        const val ACTION_STOP_MONITORING = "com.safeshield.action.STOP_MONITORING"
        var isRunning = false
    }

    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.Default + serviceJob)
    private lateinit var notificationHelper: NotificationHelper

    override fun onCreate() {
        super.onCreate()
        notificationHelper = NotificationHelper(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        isRunning = true
        startForeground(
            NotificationHelper.NOTIFICATION_ID_STATUS,
            notificationHelper.buildForegroundNotification("SafeShield Active Protection Running")
        )
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null
}`
  },
  {
    filename: 'build.gradle.kts',
    path: 'android/app/build.gradle.kts',
    language: 'kotlin',
    content: `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.serialization")
}

android {
    namespace = "com.safeshield.parentalcontrol"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.safeshield.parentalcontrol"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.biometric:biometric:1.2.0-alpha05")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("androidx.work:work-runtime-ktx:2.10.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.1")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")
}`
  }
];
